import { useEffect, useState } from 'react';
import { PenLine, Plus, X } from 'lucide-react';
import { Product, ProductCategory } from '../types/product';
import {
  hasDisplayColor,
  inferBrandFromText,
  inferCategoryFromText,
  inferColorHexClient,
  inferVisualKind,
  isProductUrl,
} from '../utils/search';

const CUSTOM_CATEGORIES: ProductCategory[] = [
  'Arredamento',
  'Elettrodomestici',
  'Domotica & Rete',
  'Casa & Gaming',
  'Smartphone',
  'Tablet',
  'Computer',
  'Audio',
  'Wearable',
  'Fotografia',
  'Strumenti Musicali',
  'Sport & Tempo Libero',
  'Fai da te',
];

const HOME_BRAND_SUGGESTIONS = [
  'IKEA',
  'Federici Sofà',
  'Veneta Cucine',
  'Maisons du Monde',
  'TCL',
  'Samsung',
  'Apple',
  'WindTre',
  'BTicino',
  'Febal Casa',
  'Electrolux',
];

interface CustomImportPanelProps {
  isOpen: boolean;
  rooms: string[];
  defaultRoom: string;
  initialModelName?: string;
  onOpenChange: (open: boolean) => void;
  onAddCustomProduct: (product: Product, room: string, paidPrice?: number) => void;
}

export function CustomImportPanel({
  isOpen,
  rooms,
  defaultRoom,
  initialModelName,
  onOpenChange,
  onAddCustomProduct,
}: CustomImportPanelProps) {
  const [selectedRoom, setSelectedRoom] = useState<string>(defaultRoom);

  const [modelName, setModelName] = useState('');
  const [brand, setBrand] = useState('');
  const [category, setCategory] = useState<ProductCategory>('Arredamento');
  const [priceInput, setPriceInput] = useState('');
  const [paidPriceInput, setPaidPriceInput] = useState('');
  const [variantLabel, setVariantLabel] = useState('');
  const [skuOrLink, setSkuOrLink] = useState('');
  const [notes, setNotes] = useState('');
  const [manualError, setManualError] = useState<string | null>(null);

  useEffect(() => {
    if (initialModelName && initialModelName.trim()) {
      const clean = initialModelName.trim();
      setModelName(clean);
      const inferredBrand = inferBrandFromText(clean);
      if (inferredBrand) setBrand(inferredBrand);
      const inferredCat = inferCategoryFromText(`${inferredBrand || ''} ${clean}`);
      if (inferredCat) setCategory(inferredCat);
    }
  }, [initialModelName]);

  function handleSubmitManual(e: React.FormEvent) {
    e.preventDefault();
    setManualError(null);

    const cleanName = modelName.trim();
    const inferredBrand = inferBrandFromText(cleanName);
    const cleanBrand = brand.trim() || inferredBrand || 'Personale';
    const inferredCat = inferCategoryFromText(`${cleanBrand} ${cleanName}`);
    const resolvedCategory = category === 'Arredamento' && inferredCat ? inferredCat : category;
    if (cleanName.length < 2) {
      setManualError('Inserisci il nome del modello o articolo (almeno 2 caratteri).');
      return;
    }

    const parsedPrice = priceInput.trim()
      ? Number(priceInput.replace(',', '.').replace(/[^0-9.]/g, ''))
      : 0;
    const safePrice = Number.isFinite(parsedPrice) && parsedPrice >= 0 ? parsedPrice : 0;

    const cleanPaidRaw = paidPriceInput.trim();
    const parsedPaidPrice = cleanPaidRaw
      ? Number(cleanPaidRaw.replace(',', '.').replace(/[^0-9.]/g, ''))
      : NaN;
    const safePaidPrice =
      cleanPaidRaw && Number.isFinite(parsedPaidPrice) && parsedPaidPrice >= 0
        ? Number(parsedPaidPrice.toFixed(2))
        : undefined;

    const cleanSku = skuOrLink.trim();
    const isRefUrl = isProductUrl(cleanSku);
    const skuCode =
      !isRefUrl && cleanSku
        ? cleanSku
        : `MOD-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

    const rawVariant = variantLabel.trim();
    const cleanVariant = rawVariant || 'Modello specifico';
    const hasColor = hasDisplayColor(rawVariant);
    const cleanNotes =
      notes.trim() || `${cleanName} (${cleanBrand}) inserito manualmente nella tua pagina.`;

    const specs: Array<{ label: string; value: string }> = [
      { label: 'Marca', value: cleanBrand },
      { label: 'Categoria', value: resolvedCategory },
      { label: 'Codice / Modello', value: skuCode },
    ];
    if (rawVariant) {
      specs.push({ label: 'Finitura / Versione', value: rawVariant });
    }
    if (isRefUrl) {
      specs.push({ label: 'Collegamento', value: cleanSku });
    }

    const inferredColorHex = hasColor ? inferColorHexClient(rawVariant) : '';

    const product: Product = {
      id: `manual-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      sku: skuCode,
      name: cleanName,
      brand: cleanBrand,
      category: resolvedCategory,
      searchPriority: 90,
      price: safePrice,
      rating: 5.0,
      reviewCount: 1,
      availability: 'Modello inserito manualmente',
      deliveryText: 'Scheda personalizzata salvata nella tua pagina',
      warranty: 'Garanzia del produttore',
      sourceUrl: isRefUrl ? cleanSku : undefined,
      visualKind: inferVisualKind(resolvedCategory, `${cleanBrand} ${cleanName}`),
      shortSummary: cleanNotes,
      highlights: [
        cleanNotes,
        `Marca: ${cleanBrand} · Categoria: ${resolvedCategory}`,
        `Codice modello: ${skuCode}`,
      ],
      specs,
      boxContents: [cleanName],
      variants: [
        {
          id: 'custom-std',
          label: cleanVariant,
          colorName: hasColor ? rawVariant : '',
          colorHex: inferredColorHex,
          priceDelta: 0,
        },
      ],
      keywords: [cleanName.toLowerCase(), cleanBrand.toLowerCase(), resolvedCategory.toLowerCase()],
    };

    onAddCustomProduct(product, selectedRoom, safePaidPrice);
    setModelName('');
    setBrand('');
    setPriceInput('');
    setPaidPriceInput('');
    setVariantLabel('');
    setSkuOrLink('');
    setNotes('');
  }

  return (
    <div className="mt-4 pt-4 border-t border-[#EAEAE5]">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-medium text-[#5E5E59] mr-1">
            Non hai il link del negozio?
          </span>
          <button
            type="button"
            onClick={() => onOpenChange(!isOpen)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md border flex items-center gap-1.5 transition-colors cursor-pointer ${
              isOpen
                ? 'bg-[#141413] text-white border-[#141413]'
                : 'bg-[#FAFAF8] text-[#141413] border-[#D4D4CE] hover:bg-[#F3F3F0]'
            }`}
          >
            <PenLine className="w-3.5 h-3.5" aria-hidden="true" />
            Inserisci modello manuale
          </button>
        </div>

        {isOpen && (
          <button
            type="button"
            onClick={() => onOpenChange(false)}
            className="text-xs text-[#5E5E59] hover:text-[#141413] flex items-center gap-1 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" aria-hidden="true" />
            Chiudi pannello
          </button>
        )}
      </div>

      {isOpen && (
        <form
          onSubmit={handleSubmitManual}
          className="mt-3 p-4 sm:p-5 bg-[#FAFAF8] border border-[#D4D4CE] rounded-lg space-y-4"
        >
          <div>
            <h2 className="text-sm font-bold text-[#141413]">
              Inserisci manualmente il tuo modello specifico
            </h2>
            <p className="text-xs text-[#5E5E59] mt-0.5">
              Compila i campi essenziali (anche senza prezzo se vuoi annotarlo dopo) per salvare
              l’articolo direttamente ne «La mia pagina».
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <label className="block sm:col-span-2">
              <span className="block text-xs font-medium text-[#141413] mb-1">
                Nome modello / articolo *
              </span>
              <input
                type="text"
                required
                value={modelName}
                onChange={(e) => setModelName(e.target.value)}
                placeholder="es. Divano Milano 3 posti con penisola"
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413]"
              />
            </label>

            <label className="block">
              <span className="block text-xs font-medium text-[#141413] mb-1">Marca</span>
              <input
                type="text"
                list="home-brands-datalist"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="es. Federici Sofà"
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413]"
              />
              <datalist id="home-brands-datalist">
                {HOME_BRAND_SUGGESTIONS.map((b) => (
                  <option key={b} value={b} />
                ))}
              </datalist>
            </label>

            <label className="block">
              <span className="block text-xs font-medium text-[#141413] mb-1">Categoria</span>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ProductCategory)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413]"
              >
                {CUSTOM_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </label>

            <label className="block">
              <span className="block text-xs font-medium text-[#141413] mb-1">
                Prezzo (€, opzionale)
              </span>
              <input
                type="text"
                inputMode="decimal"
                value={priceInput}
                onChange={(e) => setPriceInput(e.target.value)}
                placeholder="es. 149,00"
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413] tabular-nums"
              />
            </label>

            <label className="block">
              <span className="block text-xs font-medium text-[#141413] mb-1">
                Prezzo pagato (€, opzionale)
              </span>
              <input
                type="text"
                inputMode="decimal"
                value={paidPriceInput}
                onChange={(e) => setPaidPriceInput(e.target.value)}
                placeholder="es. 119,00"
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413] tabular-nums"
              />
            </label>

            <label className="block">
              <span className="block text-xs font-medium text-[#141413] mb-1">
                Finitura / Colore
              </span>
              <input
                type="text"
                value={variantLabel}
                onChange={(e) => setVariantLabel(e.target.value)}
                placeholder="es. Tessuto Tortora"
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413]"
              />
            </label>

            <label className="block">
              <span className="block text-xs font-medium text-[#141413] mb-1">
                Codice SKU o link (opzionale)
              </span>
              <input
                type="text"
                value={skuOrLink}
                onChange={(e) => setSkuOrLink(e.target.value)}
                placeholder="es. 905.859.50 o https://..."
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413]"
              />
            </label>

            <label className="block">
              <span className="block text-xs font-medium text-[#141413] mb-1">
                Note / Misure (opzionale)
              </span>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="es. Larghezza 240 cm, salotto"
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413]"
              />
            </label>

            <label className="block">
              <span className="block text-xs font-medium text-[#141413] mb-1">Stanza</span>
              <select
                value={selectedRoom}
                onChange={(e) => setSelectedRoom(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413] cursor-pointer"
              >
                {rooms.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </label>
          </div>

          {manualError && (
            <p className="text-xs text-[#991B1B] font-medium">{manualError}</p>
          )}

          <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
            <button
              type="submit"
              className="px-4 py-2 text-xs sm:text-sm font-semibold bg-[#F59E0B] hover:bg-[#D97706] text-[#141413] hover:text-white rounded-md transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              Aggiungi alla mia pagina
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
