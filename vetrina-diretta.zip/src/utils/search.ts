import { Product, ProductCategory, VisualKind } from '../types/product';

export interface SearchMatch {
  product: Product;
  score: number;
  matchedField: 'name' | 'brand' | 'category' | 'keyword' | 'spec';
}

const QUERY_ALIASES: Array<[RegExp, string]> = [
  [/\bmaosn\b/g, 'maisons'],
  [/\bmason\b/g, 'maisons'],
  [/\bdue\s+monde\b/g, 'du monde'],
  [/\bb\s+ticino\b/g, 'bticino'],
  [/\bticino\b/g, 'bticino'],
  [/\bwind\s+tre\b/g, 'windtre'],
  [/\bwind3\b/g, 'windtre'],
  [/\blampadari\b/g, 'lampadario'],
  [/\bdivani\b/g, 'divano'],
  [/\bplacche\b/g, 'placca'],
  [/\btelevisori\b/g, 'tv'],
  [/\btelevisore\b/g, 'tv'],
  [/\bsmart\s*tv\b/g, 'tv'],
];

function normalize(str: string): string {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

function applyAliases(normQuery: string): string {
  let result = normQuery;
  for (const [pattern, replacement] of QUERY_ALIASES) {
    result = result.replace(pattern, replacement);
  }
  return result;
}

export function searchCatalog(
  catalog: Product[],
  rawQuery: string,
  categoryFilter: ProductCategory | 'Tutte' = 'Tutte'
): SearchMatch[] {
  const query = applyAliases(normalize(rawQuery));
  const filteredByCategory =
    categoryFilter === 'Tutte'
      ? catalog
      : catalog.filter((p) => p.category === categoryFilter);

  if (!query) {
    return filteredByCategory
      .slice()
      .sort((a, b) => b.searchPriority - a.searchPriority)
      .map((product) => ({
        product,
        score: product.searchPriority,
        matchedField: 'name',
      }));
  }

  const tokens = query.split(/\s+/).filter(Boolean);
  const matches: SearchMatch[] = [];

  for (const product of filteredByCategory) {
    const nameNorm = normalize(product.name);
    const brandNorm = normalize(product.brand);
    const catNorm = normalize(product.category);
    const keywordsNorm = product.keywords.map(normalize);
    const summaryNorm = normalize(product.shortSummary);
    const specsNorm = normalize(product.specs.map((s) => `${s.label} ${s.value}`).join(' '));

    const searchableText = `${nameNorm} ${brandNorm} ${catNorm} ${keywordsNorm.join(' ')} ${summaryNorm} ${specsNorm}`;
    const allTokensPresent = tokens.every((t) => searchableText.includes(t));

    if (!allTokensPresent) continue;

    let score = product.searchPriority * 0.2;
    let matchedField: SearchMatch['matchedField'] = 'spec';

    if (nameNorm.startsWith(query)) {
      score += 1000;
      matchedField = 'name';
    } else if (nameNorm.split(/[\s"()-]+/).some((word) => word.startsWith(query))) {
      score += 750;
      matchedField = 'name';
    } else if (tokens.every((t) => nameNorm.includes(t) || brandNorm.includes(t))) {
      score += 650;
      matchedField = 'name';
    } else if (nameNorm.includes(query)) {
      score += 500;
      matchedField = 'name';
    } else if (brandNorm.startsWith(query) || tokens.some((t) => brandNorm.startsWith(t))) {
      score += 420;
      matchedField = 'brand';
    } else if (keywordsNorm.some((k) => k.startsWith(query))) {
      score += 320;
      matchedField = 'keyword';
    } else if (catNorm.startsWith(query) || catNorm.includes(query)) {
      score += 220;
      matchedField = 'category';
    } else {
      score += 100;
    }

    matches.push({ product, score, matchedField });
  }

  return matches.sort((a, b) => b.score - a.score);
}

export interface TextSegment {
  text: string;
  highlighted: boolean;
}

export function splitHighlight(text: string, query: string): TextSegment[] {
  const cleanQuery = query.trim();
  if (!cleanQuery) {
    return [{ text, highlighted: false }];
  }

  const lowerText = text.toLowerCase();
  const lowerQuery = cleanQuery.toLowerCase();
  const index = lowerText.indexOf(lowerQuery);

  if (index === -1) {
    return [{ text, highlighted: false }];
  }

  const segments: TextSegment[] = [];
  if (index > 0) {
    segments.push({ text: text.slice(0, index), highlighted: false });
  }
  segments.push({
    text: text.slice(index, index + cleanQuery.length),
    highlighted: true,
  });
  if (index + cleanQuery.length < text.length) {
    segments.push({
      text: text.slice(index + cleanQuery.length),
      highlighted: false,
    });
  }
  return segments;
}

export function formatEuro(amount: number): string {
  return new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
  }).format(amount);
}

export function isProductUrl(value: string): boolean {
  const trimmed = value.trim();
  if (!/^https?:\/\/\S+$/i.test(trimmed)) return false;
  try {
    const parsed = new URL(trimmed);
    return (parsed.protocol === 'http:' || parsed.protocol === 'https:') && parsed.hostname.includes('.');
  } catch {
    return false;
  }
}

export function inferVisualKind(category: string, text: string): VisualKind {
  const combined = `${category} ${text}`.toLowerCase();
  if (
    combined.includes('lampad') ||
    combined.includes('sospensione') ||
    combined.includes('plafoniera') ||
    combined.includes('abat-jour') ||
    combined.includes('illuminazione')
  ) {
    return 'lighting';
  }
  if (combined.includes('divan') || combined.includes('sofa') || combined.includes('sofà') || combined.includes('poltrona')) {
    return 'sofa';
  }
  if (combined.includes('cucin') && !combined.includes('forno') && !combined.includes('piano cottura')) {
    return 'kitchen';
  }
  if (combined.includes('tv') || combined.includes('oled') || combined.includes('qled') || combined.includes('televisore')) {
    return 'tv';
  }
  if (combined.includes('router') || combined.includes('modem') || combined.includes('mesh') || combined.includes('wifi')) {
    return 'router';
  }
  if (combined.includes('bticino') || combined.includes('termostato') || combined.includes('placca') || combined.includes('videocitofono')) {
    return 'smarthome';
  }
  if (category === 'Smartphone' || combined.includes('iphone') || combined.includes('galaxy')) {
    return 'phone-pro';
  }
  if (category === 'Tablet' || combined.includes('ipad') || combined.includes('tablet')) {
    return 'tablet-pro';
  }
  if (category === 'Computer' || combined.includes('macbook') || combined.includes('laptop')) {
    return 'laptop-pro';
  }
  if (category === 'Audio' || combined.includes('cuffie') || combined.includes('soundbar')) {
    return 'headphones';
  }
  if (category === 'Wearable' || combined.includes('watch') || combined.includes('orologio')) {
    return 'watch-series';
  }
  if (category === 'Fotografia' || combined.includes('fotocamera')) {
    return 'camera';
  }
  if (category === 'Elettrodomestici' || combined.includes('lavatrice') || combined.includes('frigo') || combined.includes('forno')) {
    return 'appliance';
  }
  if (category === 'Arredamento' || combined.includes('mobile') || combined.includes('tavolo') || combined.includes('sedia') || combined.includes('armadio')) {
    return 'furniture';
  }
  if (category === 'Strumenti Musicali' || combined.includes('chitarra') || combined.includes('basso')) {
    return 'guitar';
  }
  if (category === 'Domotica & Rete') {
    return 'smarthome';
  }
  return 'generic-product';
}

export function inferBrandFromText(text: string): string | undefined {
  const t = text.toLowerCase();
  const known: Array<[RegExp, string]> = [
    [/\b(iphone|ipad|macbook|apple|airpods|imac)\b/, 'Apple'],
    [/\b(galaxy|samsung)\b/, 'Samsung'],
    [/\btcl\b/, 'TCL'],
    [/\belectrolux\b/, 'Electrolux'],
    [/\bbticino\b/, 'BTicino'],
    [/\bwind\s*tre\b|\bwindtre\b/, 'WindTre'],
    [/\bfederici\b/, 'Federici Sofà'],
    [/\bveneta cucine\b/, 'Veneta Cucine'],
    [/\bfebal\b/, 'Febal Casa'],
    [/\bmaisons du monde\b/, 'Maisons du Monde'],
    [/\bikea\b/, 'IKEA'],
    [/\bibanez\b/, 'Ibanez'],
    [/\bsony\b/, 'Sony'],
    [/\bdyson\b/, 'Dyson'],
  ];
  for (const [re, brand] of known) {
    if (re.test(t)) return brand;
  }
  return undefined;
}

export function inferCategoryFromText(text: string): ProductCategory | undefined {
  const t = text.toLowerCase();
  if (/\b(iphone|smartphone|galaxy\s*s|pixel)\b/.test(t)) return 'Smartphone';
  if (/\b(ipad|tablet)\b/.test(t)) return 'Tablet';
  if (/\b(macbook|laptop|notebook|imac)\b/.test(t)) return 'Computer';
  if (/\b(cuffie|airpods|soundbar|cassa|speaker)\b/.test(t)) return 'Audio';
  if (/\b(tv|oled|qled|televisore|console|playstation|xbox|switch)\b/.test(t)) return 'Casa & Gaming';
  if (/\b(lavatrice|asciugatrice|lavastoviglie|frigo|forno|induzione|microonde|electrolux)\b/.test(t))
    return 'Elettrodomestici';
  if (/\b(bticino|router|modem|termostato|placca|videocitofono|windtre)\b/.test(t))
    return 'Domotica & Rete';
  if (/\b(divano|lampadario|lampada|cucina|armadio|tavolo|sedia|statuetta|specchio|libreria|ikea|federici|veneta|febal|maisons)\b/.test(t))
    return 'Arredamento';
  if (/\b(chitarra|basso|amplificatore|ibanez)\b/.test(t)) return 'Strumenti Musicali';
  return undefined;
}

const COLOR_PALETTE_RULES: Array<[RegExp, string]> = [
  // Multi-word & specific shades first
  [/\b(arancione\s*cosmico|cosmic\s*orange)\b/, '#D96B27'],
  [/\b(oro\s*rosa|rose\s*gold|pink\s*gold)\b/, '#C99588'],
  [/\b(blu\s*(?:notte|mezzanotte)|midnight(?:\s*blue)?|mezzanotte)\b/, '#1A2438'],
  [/\b(blu\s*(?:profondo|marino|scuro)|deep\s*blue|dark\s*blue|navy)\b/, '#1F2F4C'],
  [/\b(blu\s*(?:cobalto|elettrico|zaffiro)|cobalto|cobalt|zaffiro|sapphire|ultramarino|oltremare)\b/, '#1E4D9B'],
  [/\b(carta\s*da\s*zucchero|avio|denim|jeans)\b/, '#52728F'],
  [/\b(verde\s*petrolio|petrolio|ottanio|teal|pavone)\b/, '#1C5D68'],
  [/\b(verde\s*(?:bosco|abete|pino|scuro)|forest\s*green|dark\s*green)\b/, '#244C38'],
  [/\b(verde\s*militare|militare|oliva|olive|muschio|moss|kaki|khaki|cachi)\b/, '#55613C'],
  [/\b(verde\s*smeraldo|smeraldo|emerald|giada|jade)\b/, '#257A57'],
  [/\b(verde\s*salvia|salvia|sage|eucalipto)\b/, '#7A9482'],
  [/\b(verde\s*menta|menta|mint|pistacchio|pistachio|acquamarina|tiffany)\b/, '#74B89E'],
  [/\b(verde\s*acqua)\b/, '#5FA395'],
  [/\b(rosa\s*(?:antico|cipria)|cipria|dusty\s*rose|blush)\b/, '#CFA1A6'],
  [/\b(titanio\s*naturale|natural\s*titanium)\b/, '#A8A59E'],
  [/\b(titanio\s*nero|black\s*titanium|canna\s*di\s*fucile|gunmetal)\b/, '#525458'],
  [/\b(grigio\s*(?:siderale|scuro)|space\s*gr[ae]y|dark\s*gr[ae]y|piombo|fumo)\b/, '#5A5D64'],
  [/\b(bianco\s*caldo|off\s*white)\b/, '#EDE8DC'],

  // Reds / Burgundy / Wine
  [/\b(borgogna|burgundy|bordeaux|vinaccia|sangria|chianti|barolo|amarone)\b/, '#7A1C2E'],
  [/\b(granata|garnet)\b/, '#7B1E26'],
  [/\b(amaranto|crimson|cremisi|carminio|rubino|ruby|ciliegia|cherry)\b/, '#9E1B32'],
  [/\b(melanzana|aubergine|eggplant)\b/, '#4E2340'],
  [/\b(prugna|plum)\b/, '#5E2B4E'],
  [/\b(lampone|raspberry|fragola|strawberry)\b/, '#B8294B'],
  [/\b(terracotta|mattone|brick|coccio)\b/, '#B55239'],
  [/\b(ruggine|rust)\b/, '#9E472A'],
  [/\b(corallo|coral)\b/, '#E06553'],
  [/\b(salmone|salmon)\b/, '#E58975'],

  // Oranges / Yellows / Golds
  [/\b(pesca|peach|albicocca|apricot)\b/, '#F0A678'],
  [/\b(ambra|amber|miele|honey|caramello|caramel)\b/, '#C97A2B'],
  [/\b(senape|mustard|ocra|ochre|curcuma|zafferano)\b/, '#C79326'],
  [/\b(champagne|starlight|galassia)\b/, '#DFD3BE'],
  [/\b(ottone|brass|ottonato)\b/, '#C5A059'],
  [/\b(lime|cedro|chartreuse)\b/, '#9AB83B'],

  // Blues / Purples / Pinks
  [/\b(turchese|turquoise|ciano|cyan)\b/, '#249EA8'],
  [/\b(azzurro|celeste|sky\s*blue|light\s*blue|ghiaccio)\b/, '#6AA7D9'],
  [/\b(fucsia|fuchsia|magenta)\b/, '#B8296B'],
  [/\b(indaco|indigo|mora)\b/, '#4B2E6E'],
  [/\b(lavanda|lavender|lilla|lilac|glicine|pervinca|malva|mauve|orchidea)\b/, '#A38DB8'],

  // Browns / Woods / Metals
  [/\b(wenge|ebano|ebony|palissandro)\b/, '#3D2B22'],
  [/\b(caffe|coffee|espresso|cioccolato|chocolate|cacao)\b/, '#4E3529'],
  [/\b(mogano|mahogany|castagno|chestnut)\b/, '#6E3B2B'],
  [/\b(cuoio|cognac|tabacco|leather|saddle|nocciola|noce|walnut)\b/, '#855436'],
  [/\b(teak|rovere|quercia|oak|legno|wood|faggio|frassino|betulla|bambu)\b/, '#B58F63'],
  [/\b(cammello|camel|taupe|tortora|talpa|visone|marrone|brown)\b/, '#7F614A'],
  [/\b(sabbia|sand|beige|canapa|lino|ecru|crema|cream)\b/, '#CFC1AA'],
  [/\b(rame|copper)\b/, '#B86B43'],
  [/\b(bronzo|bronze)\b/, '#7D5C3E'],
  [/\b(titanio|titanium)\b/, '#7A7C80'],
  [/\b(antracite|anthracite|grafite|graphite|carbone|charcoal|ossidiana|onice|ardesia)\b/, '#36383E'],
  [/\b(argento|silver|inox|acciaio|steel|cromo|cromato|chrome|platino|platinum|alluminio)\b/, '#C5C8CE'],
  [/\b(avorio|ivory|panna|perla|pearl)\b/, '#EDE8DC'],

  // Base color families (catch-all for compound phrases like "Blu Egeo", "Rosso Corsa", etc.)
  [/\b(arancione|arancio|orange|mandarino|tangerine|zucca|cosmico)\b/, '#E06D22'],
  [/\b(rosso|red|scarlatto|vermiglio)\b/, '#B82828'],
  [/\b(oro|gold|dorato)\b/, '#D4AF37'],
  [/\b(giallo|yellow|limone|lemon|canarino)\b/, '#E2B729'],
  [/\b(verde|green|acqua)\b/, '#38764B'],
  [/\b(blu|blue|marino)\b/, '#25539B'],
  [/\b(viola|violetto|violet|purple)\b/, '#764B9E'],
  [/\b(rosa|pink)\b/, '#D9829B'],
  [/\b(grigio|gr[ae]y|cemento|concrete|cenere|pietra)\b/, '#8D9096'],
  [/\b(bianco|white|neve|snow|latte)\b/, '#F2F2EE'],
  [/\b(nero|black|corvino)\b/, '#1C1D20'],
];

export function inferColorHexClient(colorName: string): string {
  const normalized = colorName
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
  if (!normalized) return '#2B2C30';
  for (const [pattern, hex] of COLOR_PALETTE_RULES) {
    if (pattern.test(normalized)) return hex;
  }
  return '#2B2C30';
}

const PLACEHOLDER_COLORS = new Set([
  'originale',
  'come da pagina prodotto',
  'modello specifico',
  'non specificato',
  'nessuno',
  'nessuna',
  'n/a',
  'standard',
]);

export function hasDisplayColor(colorName?: string): boolean {
  if (!colorName) return false;
  const cleaned = colorName.trim().toLowerCase();
  if (!cleaned) return false;
  return !PLACEHOLDER_COLORS.has(cleaned);
}

const EXPLICIT_COLOR_PATTERNS_CLIENT: Array<[RegExp, string]> = [
  [/\b(grigio\s*siderale|space\s*gr[ae]y)\b/i, 'Grigio Siderale'],
  [/\b(titanio\s*naturale|natural\s*titanium)\b/i, 'Titanio Naturale'],
  [/\b(titanio\s*nero|black\s*titanium)\b/i, 'Titanio Nero'],
  [/\b(titanio\s*blu|blue\s*titanium)\b/i, 'Titanio Blu'],
  [/\b(titanio\s*sabbia|desert\s*titanium)\b/i, 'Titanio Sabbia'],
  [/\b(titanio\s*bianco|white\s*titanium)\b/i, 'Titanio Bianco'],
  [/\b(oro\s*rosa|rose\s*gold|pink\s*gold)\b/i, 'Oro Rosa'],
  [/\b(blu\s*mezzanotte|midnight(?:\s*blue)?)\b/i, 'Blu Mezzanotte'],
  [/\b(blu\s*notte)\b/i, 'Blu Notte'],
  [/\b(blu\s*profondo|deep\s*blue)\b/i, 'Blu Profondo'],
  [/\b(blu\s*marino|navy\s*blue|navy)\b/i, 'Blu Marino'],
  [/\b(blu\s*cobalto|cobalt\s*blue)\b/i, 'Blu Cobalto'],
  [/\b(verde\s*petrolio|ottanio|teal)\b/i, 'Verde Petrolio'],
  [/\b(verde\s*bosco|forest\s*green)\b/i, 'Verde Bosco'],
  [/\b(verde\s*militare|olive\s*green|oliva)\b/i, 'Verde Militare'],
  [/\b(verde\s*salvia|sage\s*green|salvia)\b/i, 'Verde Salvia'],
  [/\b(verde\s*smeraldo|emerald)\b/i, 'Verde Smeraldo'],
  [/\b(verde\s*menta|mint\s*green)\b/i, 'Verde Menta'],
  [/\b(verde\s*acqua)\b/i, 'Verde Acqua'],
  [/\b(rosa\s*cipria|dusty\s*rose)\b/i, 'Rosa Cipria'],
  [/\b(rosa\s*antico)\b/i, 'Rosa Antico'],
  [/\b(bianco\s*caldo|off\s*white)\b/i, 'Bianco Caldo'],
  [/\b(arancione\s*cosmico|cosmic\s*orange)\b/i, 'Arancione Cosmico'],
  [/\b(grigio\s*scuro|dark\s*gr[ae]y)\b/i, 'Grigio Scuro'],
  [/\b(grigio\s*chiaro|light\s*gr[ae]y)\b/i, 'Grigio Chiaro'],
  [/\b(antracite|anthracite)\b/i, 'Antracite'],
  [/\b(grafite|graphite)\b/i, 'Grafite'],
  [/\b(argento|silver)\b/i, 'Argento'],
  [/\b(champagne|starlight|galassia)\b/i, 'Champagne'],
  [/\b(bordeaux|borgogna|burgundy)\b/i, 'Bordeaux'],
  [/\b(turchese|turquoise)\b/i, 'Turchese'],
  [/\b(azzurro|celeste|sky\s*blue)\b/i, 'Azzurro'],
  [/\b(tortora|taupe)\b/i, 'Tortora'],
  [/\b(beige|sabbia)\b/i, 'Beige'],
  [/\b(avorio|panna)\b/i, 'Avorio'],
  [/\b(marrone|brown)\b/i, 'Marrone'],
  [/\b(bronzo|bronze)\b/i, 'Bronzo'],
  [/\b(rosso|red)\b/i, 'Rosso'],
  [/\b(blu|blue)\b/i, 'Blu'],
  [/\b(verde|green)\b/i, 'Verde'],
  [/\b(giallo|yellow)\b/i, 'Giallo'],
  [/\b(arancione|orange)\b/i, 'Arancione'],
  [/\b(viola|purple|violet)\b/i, 'Viola'],
  [/\b(rosa|pink)\b/i, 'Rosa'],
  [/\b(grigio|gr[ae]y)\b/i, 'Grigio'],
  [/\b(bianco|white)\b/i, 'Bianco'],
  [/\b(nero|black)\b/i, 'Nero'],
];

export function extractExplicitColorFromTextClient(rawText?: string): string {
  if (!rawText) return '';
  const cleaned = rawText
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, ' ')
    .trim();
  if (!cleaned) return '';
  for (const [pattern, label] of EXPLICIT_COLOR_PATTERNS_CLIENT) {
    if (pattern.test(cleaned)) return label;
  }
  return '';
}

const TRACKING_QUERY_PARAMS = new Set([
  'utm_source',
  'utm_medium',
  'utm_campaign',
  'utm_term',
  'utm_content',
  'fbclid',
  'gclid',
  'ref',
  'ref_',
  'qid',
  'sr',
  'keywords',
  'dib',
  'dib_tag',
  'sp_csd',
  'pd_rd_r',
  'pd_rd_w',
  'pd_rd_wg',
  'pf_rd_p',
  'pf_rd_r',
  '_encoding',
  'tag',
  'linkcode',
  'camp',
  'creative',
  'creativeasin',
  'crid',
  'sprefix',
]);

export function normalizeProductUrl(rawUrl?: string): string | null {
  if (!rawUrl) return null;
  try {
    const parsed = new URL(rawUrl.trim());
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
    const host = parsed.hostname.toLowerCase().replace(/^www\./, '');
    const path = parsed.pathname.replace(/\/+$/, '') || '/';

    if (host.includes('amazon.')) {
      const asin = path.match(/\/(?:dp|gp\/(?:product|aw\/d))\/([A-Z0-9]{10})/i)?.[1];
      if (asin) {
        return `${host}/dp/${asin.toUpperCase()}`;
      }
    }

    const keptParams = new URLSearchParams();
    for (const [k, v] of parsed.searchParams.entries()) {
      if (!TRACKING_QUERY_PARAMS.has(k.toLowerCase())) {
        keptParams.append(k, v);
      }
    }
    keptParams.sort();
    const qs = keptParams.toString();
    return `${host}${path}${qs ? `?${qs}` : ''}`.toLowerCase();
  } catch {
    return null;
  }
}

export function extractSourceUrlFromProduct(product: Product): string | undefined {
  if (product.sourceUrl && isProductUrl(product.sourceUrl)) {
    return product.sourceUrl;
  }
  const specMatch = product.specs.find(
    (s) =>
      (s.label.toLowerCase().includes('collegamento') || s.label.toLowerCase().includes('link')) &&
      isProductUrl(s.value)
  );
  return specMatch?.value;
}

export function extractOfficialUrlFromProduct(product: Product): string | undefined {
  const sourceUrl = extractSourceUrlFromProduct(product);
  const candidate =
    (product.officialUrl && isProductUrl(product.officialUrl) ? product.officialUrl : undefined) ||
    product.specs.find(
      (s) => s.label.toLowerCase().includes('produttore') && isProductUrl(s.value)
    )?.value;
  if (!candidate) return undefined;
  if (sourceUrl && getDomainLabel(candidate).toLowerCase() === getDomainLabel(sourceUrl).toLowerCase()) {
    return undefined;
  }
  return candidate;
}

export function getDomainLabel(rawUrl: string): string {
  try {
    const parsed = new URL(rawUrl);
    return parsed.hostname.replace(/^www\./i, '');
  } catch {
    return 'sito';
  }
}

export function normalizeVariantSizeText(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  const storageMatch = trimmed.match(/^(\d+(?:[.,]\d+)?)\s*(giga(?:byte)?s?|gb|tera(?:byte)?s?|tb|mega(?:byte)?s?|mb)$/i);
  if (storageMatch) {
    const num = storageMatch[1].replace(',', '.');
    const unitRaw = storageMatch[2].toLowerCase();
    const unit = unitRaw.startsWith('t') ? 'TB' : unitRaw.startsWith('g') ? 'GB' : 'MB';
    return `${num} ${unit}`;
  }
  return trimmed;
}

export function isSameSizeLabel(a?: string, b?: string): boolean {
  if (!a || !b) return false;
  const na = normalizeVariantSizeText(a).replace(/\s+/g, '').toLowerCase();
  const nb = normalizeVariantSizeText(b).replace(/\s+/g, '').toLowerCase();
  return Boolean(na && nb && na === nb);
}

function escapeRegExp(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function replaceSizeInProductName(
  productName: string,
  oldSize: string,
  newSize: string
): string {
  const cleanName = productName.trim();
  const normalizedNew = normalizeVariantSizeText(newSize);
  const normalizedOld = normalizeVariantSizeText(oldSize);
  if (!cleanName || !normalizedNew || !normalizedOld) return cleanName;
  if (isSameSizeLabel(normalizedOld, normalizedNew)) return cleanName;

  const oldVariants = Array.from(
    new Set([oldSize.trim(), normalizedOld, normalizedOld.replace(/\s+/g, '')].filter(Boolean))
  ).sort((a, b) => b.length - a.length);

  for (const candidate of oldVariants) {
    const pattern = new RegExp(`(?<![A-Za-z0-9])${escapeRegExp(candidate)}(?![A-Za-z0-9])`, 'i');
    if (pattern.test(cleanName)) {
      return cleanName.replace(pattern, normalizedNew);
    }
  }

  // Fallback for storage units anywhere in title (e.g. "1TB" or "512GB") if old was storage
  if (/^\d+(?:\.\d+)?\s*(?:GB|TB|MB)$/i.test(normalizedOld) && /^\d+(?:\.\d+)?\s*(?:GB|TB|MB)$/i.test(normalizedNew)) {
    const storageRegex = /\b\d+(?:[.,]\d+)?\s*(?:GB|TB)\b/i;
    if (storageRegex.test(cleanName)) {
      return cleanName.replace(storageRegex, normalizedNew);
    }
  }

  return cleanName;
}

export function stripDuplicateColorFromTitleClient(rawTitle: string, colorName?: string): string {
  const title = rawTitle.trim();
  const color = colorName?.trim();
  if (!title || !color) return title;

  const titleExplicitColor = extractExplicitColorFromTextClient(title);
  const targetColor =
    titleExplicitColor &&
    titleExplicitColor.toLowerCase() !== color.toLowerCase() &&
    titleExplicitColor.toLowerCase().includes(color.toLowerCase())
      ? titleExplicitColor
      : color;

  const escapedColor = escapeRegExp(targetColor).replace(/\s+/g, '\\s+');
  const result = title
    .replace(new RegExp(`\\s*\\(\\s*(?:colore\\s*[:\\-]?\\s*)?${escapedColor}\\s*\\)`, 'gi'), '')
    .replace(
      new RegExp(
        `\\s*(?:[-–—|/;,:\\u00b7]+\\s*)?(?:colore\\s*[:\\-]?\\s*)?(?<![A-Za-zÀ-ÿ0-9])${escapedColor}(?![A-Za-zÀ-ÿ0-9])`,
        'gi'
      ),
      ''
    )
    .replace(/\(\s*\)/g, '')
    .replace(/\s*,\s*(?=[(\[])/g, ' ')
    .replace(/,\s*,+/g, ',')
    .replace(/\s{2,}/g, ' ')
    .replace(/^[\s,\-–—|/;:,]+|[\s,\-–—|/;:,]+$/g, '')
    .trim();

  return result.length >= 4 ? result : title;
}

