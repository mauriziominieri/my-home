function rgbToHex(r: number, g: number, b: number): string {
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  return (
    '#' +
    [clamp(r), clamp(g), clamp(b)]
      .map((c) => c.toString(16).padStart(2, '0').toUpperCase())
      .join('')
  );
}

function colorDistSq(r1: number, g1: number, b1: number, r2: number, g2: number, b2: number): number {
  const dr = r1 - r2;
  const dg = g1 - g2;
  const db = b1 - b2;
  return dr * dr + dg * dg + db * db;
}

function loadProxyImage(src: string, timeoutMs = 3500): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    let settled = false;

    const timer = window.setTimeout(() => {
      if (!settled) {
        settled = true;
        resolve(null);
      }
    }, timeoutMs);

    img.onload = () => {
      if (!settled) {
        settled = true;
        window.clearTimeout(timer);
        resolve(img);
      }
    };

    img.onerror = () => {
      if (!settled) {
        settled = true;
        window.clearTimeout(timer);
        resolve(null);
      }
    };

    img.src = src;
  });
}

/**
 * Computes a representative non-background HEX color from a product photo URL.
 * Uses /api/image-proxy so cross-origin store images (Amazon, IKEA, etc.) can be sampled on canvas.
 */
export async function extractDominantColorHexFromImage(
  imageUrl?: string
): Promise<string | null> {
  if (!imageUrl || typeof window === 'undefined' || typeof document === 'undefined') {
    return null;
  }

  const trimmed = imageUrl.trim();
  if (!/^https?:\/\//i.test(trimmed)) return null;

  const proxiedSrc = `/api/image-proxy?url=${encodeURIComponent(trimmed)}`;
  const img = await loadProxyImage(proxiedSrc);
  if (!img || !img.naturalWidth || !img.naturalHeight) return null;

  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return null;

  ctx.drawImage(img, 0, 0, size, size);
  let data: Uint8ClampedArray;
  try {
    data = ctx.getImageData(0, 0, size, size).data;
  } catch {
    return null;
  }

  // Estimate studio background color from corner pixels
  const cornerCoords = [
    [1, 1],
    [size - 2, 1],
    [1, size - 2],
    [size - 2, size - 2],
  ];
  let bgR = 0;
  let bgG = 0;
  let bgB = 0;
  let bgCount = 0;

  for (const [cx, cy] of cornerCoords) {
    const idx = (cy * size + cx) * 4;
    if (data[idx + 3] >= 180) {
      bgR += data[idx];
      bgG += data[idx + 1];
      bgB += data[idx + 2];
      bgCount++;
    }
  }
  const hasCornerBg = bgCount > 0;
  if (hasCornerBg) {
    bgR /= bgCount;
    bgG /= bgCount;
    bgB /= bgCount;
  }

  interface Bucket {
    weight: number;
    sumR: number;
    sumG: number;
    sumB: number;
    avgR: number;
    avgG: number;
    avgB: number;
  }

  const buckets = new Map<string, Bucket>();
  let totalWeight = 0;

  for (let y = 2; y < size - 2; y++) {
    for (let x = 2; x < size - 2; x++) {
      const idx = (y * size + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const a = data[idx + 3];

      if (a < 180) continue;
      // Ignore studio near-white background
      if (r > 236 && g > 236 && b > 236) continue;
      // Ignore pixels matching the detected corner background
      if (hasCornerBg && colorDistSq(r, g, b, bgR, bgG, bgB) < 32 * 32) continue;

      const inCenter = x >= 10 && x <= size - 11 && y >= 10 && y <= size - 11;
      const maxC = Math.max(r, g, b);
      const minC = Math.min(r, g, b);
      const saturationBoost = maxC - minC > 24 ? 1.25 : 1;
      const w = (inCenter ? 2 : 1) * saturationBoost;

      const qr = Math.floor(r / 18);
      const qg = Math.floor(g / 18);
      const qb = Math.floor(b / 18);
      const key = `${qr}:${qg}:${qb}`;

      const existing = buckets.get(key);
      if (existing) {
        existing.weight += w;
        existing.sumR += r * w;
        existing.sumG += g * w;
        existing.sumB += b * w;
        existing.avgR = existing.sumR / existing.weight;
        existing.avgG = existing.sumG / existing.weight;
        existing.avgB = existing.sumB / existing.weight;
      } else {
        buckets.set(key, {
          weight: w,
          sumR: r * w,
          sumG: g * w,
          sumB: b * w,
          avgR: r,
          avgG: g,
          avgB: b,
        });
      }
      totalWeight += w;
    }
  }

  if (buckets.size === 0 || totalWeight === 0) return null;

  const sorted = Array.from(buckets.values()).sort((a, b) => b.weight - a.weight);

  // If the top bucket is near-black shadow/bezel while a clear secondary product tone exists (>=16% weight),
  // prefer the representative product body tone.
  let chosen = sorted[0];
  const isNearBlack = (b: Bucket) => b.avgR < 24 && b.avgG < 24 && b.avgB < 24;
  if (isNearBlack(chosen)) {
    const alternative = sorted.find(
      (b) => !isNearBlack(b) && b.weight / totalWeight >= 0.16
    );
    if (alternative) {
      chosen = alternative;
    }
  }

  // Average with immediate neighbor buckets for a smooth representative hex
  let finalW = 0;
  let finalR = 0;
  let finalG = 0;
  let finalB = 0;
  for (const b of sorted) {
    if (colorDistSq(b.avgR, b.avgG, b.avgB, chosen.avgR, chosen.avgG, chosen.avgB) <= 28 * 28) {
      finalW += b.weight;
      finalR += b.sumR;
      finalG += b.sumG;
      finalB += b.sumB;
    }
  }

  if (finalW <= 0) return rgbToHex(chosen.avgR, chosen.avgG, chosen.avgB);
  return rgbToHex(finalR / finalW, finalG / finalW, finalB / finalW);
}
