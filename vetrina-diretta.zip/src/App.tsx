import { useEffect, useMemo, useRef, useState } from 'react';
import { Check, X } from 'lucide-react';
import {
  DEFAULT_HOME_ROOMS,
  Product,
  ProductAttachment,
  ProductVariant,
  SavedPageItem,
} from './types/product';
import {
  extractExplicitColorFromTextClient,
  extractOfficialUrlFromProduct,
  extractSourceUrlFromProduct,
  hasDisplayColor,
  inferColorHexClient,
  isSameSizeLabel,
  normalizeProductUrl,
  stripDuplicateColorFromTitleClient,
} from './utils/search';
import { extractDominantColorHexFromImage } from './utils/imageColor';
import {
  deleteAttachmentBlob,
  deleteAttachmentBlobs,
  saveAttachmentBlob,
} from './utils/attachmentsDb';
import { TopBar } from './components/TopBar';
import { SearchBar } from './components/SearchBar';
import { SearchResults } from './components/SearchResults';
import { ItemDetailsUpdate, UserPageSection } from './components/UserPageSection';
import { CustomImportPanel } from './components/CustomImportPanel';

const STORAGE_KEY = 'vetrina_diretta_page_items_v2';
const ROOMS_STORAGE_KEY = 'vetrina_diretta_rooms_v1';

function loadSavedItems(): SavedPageItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Array<{
      entryId: string;
      product: Product;
      variant: ProductVariant;
      quantity: number;
      room?: string;
      attachments?: ProductAttachment[];
      addedAt: number;
    }>;
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((row) => row && row.product && row.variant)
      .map((row) => {
        const cleanColorName = hasDisplayColor(row.variant.colorName)
          ? row.variant.colorName!.trim()
          : extractExplicitColorFromTextClient(row.product.name);
        const rawHex = cleanColorName ? row.variant.colorHex || '#2B2C30' : '';
        const resolvedHex =
          cleanColorName && (!rawHex || rawHex.toUpperCase() === '#2B2C30')
            ? inferColorHexClient(cleanColorName)
            : rawHex;
        const fixedColorOptions = row.product.colorOptions?.map((c) => ({
          ...c,
          hex: c.hex.toUpperCase() === '#2B2C30' ? inferColorHexClient(c.name) : c.hex,
        }));
        const resolvedSourceUrl = extractSourceUrlFromProduct(row.product);
        const resolvedOfficialUrl = extractOfficialUrlFromProduct(row.product);
        const safeAttachments = Array.isArray(row.attachments)
          ? row.attachments.filter(
              (att) => att && typeof att.id === 'string' && typeof att.name === 'string'
            )
          : [];
        const isCustomTitle = Boolean((row as SavedPageItem).customTitle);
        const cleanedTitle =
          cleanColorName && !isCustomTitle
            ? stripDuplicateColorFromTitleClient(row.product.name, cleanColorName)
            : row.product.name;
        const rawPaidPrice = (row as SavedPageItem).paidPrice;
        const cleanPaidPrice =
          typeof rawPaidPrice === 'number' && Number.isFinite(rawPaidPrice) && rawPaidPrice >= 0
            ? Number(rawPaidPrice.toFixed(2))
            : undefined;
        return {
          entryId: String(row.entryId),
          product: {
            ...row.product,
            name: cleanedTitle,
            ...(fixedColorOptions ? { colorOptions: fixedColorOptions } : {}),
            ...(resolvedSourceUrl ? { sourceUrl: resolvedSourceUrl } : {}),
            ...(resolvedOfficialUrl ? { officialUrl: resolvedOfficialUrl } : {}),
          },
          variant: {
            ...row.variant,
            colorName: cleanColorName,
            colorHex: resolvedHex,
          },
          quantity: Math.max(1, Number(row.quantity) || 1),
          room:
            typeof row.room === 'string' && row.room.trim()
              ? row.room
              : 'Non assegnata',
          ...(cleanPaidPrice !== undefined ? { paidPrice: cleanPaidPrice } : {}),
          attachments: safeAttachments,
          customizedVariant: Boolean((row as SavedPageItem).customizedVariant),
          customTitle: isCustomTitle,
          addedAt: Number(row.addedAt) || Date.now(),
        };
      });
  } catch {
    return [];
  }
}

function findMatchingSavedItem(
  items: SavedPageItem[],
  params: {
    entryKey?: string;
    sourceUrl?: string;
    room: string;
    variantLabel?: string;
    colorName?: string;
    strictVariant?: boolean;
  }
): SavedPageItem | undefined {
  if (params.entryKey) {
    const byId = items.find((item) => item.entryId === params.entryKey);
    if (byId) return byId;
  }

  const targetNormUrl = normalizeProductUrl(params.sourceUrl);
  if (!targetNormUrl) return undefined;

  const cleanRoom = params.room.trim() || 'Non assegnata';
  const targetColor = hasDisplayColor(params.colorName)
    ? params.colorName!.trim().toLowerCase()
    : '';
  const targetVariant = (params.variantLabel || '').trim().toLowerCase();

  const urlCandidates = items.filter((item) => {
    const itemUrl = extractSourceUrlFromProduct(item.product);
    const itemNormUrl = normalizeProductUrl(itemUrl);
    if (!itemNormUrl || itemNormUrl !== targetNormUrl) return false;

    const itemRoom = (item.room || 'Non assegnata').trim() || 'Non assegnata';
    if (cleanRoom !== 'Non assegnata' && itemRoom !== cleanRoom) {
      return false;
    }

    if (params.strictVariant) {
      const itemColor = hasDisplayColor(item.variant.colorName)
        ? item.variant.colorName!.trim().toLowerCase()
        : '';
      if (itemColor !== targetColor) return false;
      if (
        targetVariant &&
        item.variant.label &&
        !isSameSizeLabel(item.variant.label, targetVariant)
      ) {
        return false;
      }
    } else if (item.customizedVariant) {
      return false;
    }

    return true;
  });

  return urlCandidates[0];
}

function loadRooms(initialItems: SavedPageItem[]): string[] {
  const merged = new Set<string>(DEFAULT_HOME_ROOMS);
  try {
    const raw = localStorage.getItem(ROOMS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as unknown;
      if (Array.isArray(parsed)) {
        for (const r of parsed) {
          if (typeof r === 'string' && r.trim()) merged.add(r.trim());
        }
      }
    }
  } catch {
    // Ignore storage errors
  }
  for (const item of initialItems) {
    if (item.room && item.room.trim()) merged.add(item.room.trim());
  }
  return Array.from(merged);
}

export default function App() {
  const [query, setQuery] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [previewProducts, setPreviewProducts] = useState<Product[]>([]);
  const [pageItems, setPageItems] = useState<SavedPageItem[]>(() => loadSavedItems());
  const [rooms, setRooms] = useState<string[]>(() => loadRooms(loadSavedItems()));
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [manualPanelOpen, setManualPanelOpen] = useState(false);
  const [prefillManualName, setPrefillManualName] = useState('');
  const [isImportingUrl, setIsImportingUrl] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [importWarning, setImportWarning] = useState<string | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);
  const resultsAnchorRef = useRef<HTMLDivElement>(null);
  const toastTimerRef = useRef<number | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(pageItems));
    } catch {
      // Ignore storage quota errors
    }
  }, [pageItems]);

  useEffect(() => {
    try {
      localStorage.setItem(ROOMS_STORAGE_KEY, JSON.stringify(rooms));
    } catch {
      // Ignore storage quota errors
    }
  }, [rooms]);

  const totalPageCount = useMemo(
    () => pageItems.reduce((sum, item) => sum + item.quantity, 0),
    [pageItems]
  );

  function notifyAdded(message: string) {
    setToastMessage(message);
    if (toastTimerRef.current) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 2400);
  }

  function handleAddRoom(roomName: string) {
    const clean = roomName.trim();
    if (!clean) return;
    setRooms((prev) => (prev.includes(clean) ? prev : [...prev, clean]));
    notifyAdded(`Stanza «${clean}» aggiunta`);
  }

  function handleAddToPage(
    product: Product,
    variant: ProductVariant = product.variants[0],
    room = 'Non assegnata',
    paidPrice?: number
  ) {
    const cleanRoom = room.trim() || 'Non assegnata';
    const entryKey = `${product.id}::${variant.id}::${cleanRoom}`;
    const resolvedSourceUrl = extractSourceUrlFromProduct(product);
    const normalizedProduct: Product = resolvedSourceUrl
      ? { ...product, sourceUrl: resolvedSourceUrl }
      : product;
    const normalizedVariant: ProductVariant = hasDisplayColor(variant.colorName)
      ? variant
      : { ...variant, colorName: '', colorHex: '' };

    const currentMatch = findMatchingSavedItem(pageItems, {
      entryKey,
      sourceUrl: resolvedSourceUrl,
      room: cleanRoom,
      variantLabel: normalizedVariant.label,
      colorName: normalizedVariant.colorName,
      strictVariant: true,
    });

    setPageItems((prev) => {
      const existing = findMatchingSavedItem(prev, {
        entryKey,
        sourceUrl: resolvedSourceUrl,
        room: cleanRoom,
        variantLabel: normalizedVariant.label,
        colorName: normalizedVariant.colorName,
        strictVariant: true,
      });
      if (existing) {
        return prev.map((item) =>
          item.entryId === existing.entryId
            ? {
                ...item,
                quantity: item.quantity + 1,
                ...(paidPrice !== undefined ? { paidPrice } : {}),
              }
            : item
        );
      }
      return [
        {
          entryId: entryKey,
          product: normalizedProduct,
          variant: normalizedVariant,
          quantity: 1,
          room: cleanRoom,
          ...(paidPrice !== undefined ? { paidPrice } : {}),
          attachments: [],
          addedAt: Date.now(),
        },
        ...prev,
      ];
    });

    if (currentMatch) {
      notifyAdded(
        `Quantità aggiornata a ${currentMatch.quantity + 1} per «${currentMatch.product.name}»`
      );
    } else {
      const roomNote = cleanRoom !== 'Non assegnata' ? ` in ${cleanRoom}` : '';
      notifyAdded(
        `«${normalizedProduct.name}» (${normalizedVariant.label})${roomNote} aggiunto alla tua pagina`
      );
    }
  }

  function handleUpdateQuantity(entryId: string, delta: number) {
    const target = pageItems.find((i) => i.entryId === entryId);
    if (target && target.quantity + delta <= 0 && target.attachments?.length) {
      void deleteAttachmentBlobs(target.attachments.map((a) => a.id));
    }
    setPageItems((prev) =>
      prev
        .map((item) =>
          item.entryId === entryId
            ? { ...item, quantity: item.quantity + delta }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  }

  function handleRemoveItem(entryId: string) {
    const target = pageItems.find((i) => i.entryId === entryId);
    if (target?.attachments?.length) {
      void deleteAttachmentBlobs(target.attachments.map((a) => a.id));
    }
    setPageItems((prev) => prev.filter((item) => item.entryId !== entryId));
  }

  function handleClearPage() {
    const allIds = pageItems.flatMap((item) => (item.attachments || []).map((a) => a.id));
    if (allIds.length > 0) {
      void deleteAttachmentBlobs(allIds);
    }
    setPageItems([]);
  }

  function handleMoveItem(entryId: string, direction: 'up' | 'down') {
    setPageItems((prev) => {
      const index = prev.findIndex((i) => i.entryId === entryId);
      if (index === -1) return prev;
      const targetIndex = direction === 'up' ? index - 1 : index + 1;
      if (targetIndex < 0 || targetIndex >= prev.length) return prev;
      const next = prev.slice();
      const [moved] = next.splice(index, 1);
      next.splice(targetIndex, 0, moved);
      return next;
    });
  }

  function handleUpdatePrice(entryId: string, newUnitPrice: number) {
    setPageItems((prev) =>
      prev.map((item) =>
        item.entryId === entryId
          ? {
              ...item,
              product: { ...item.product, price: newUnitPrice },
              variant: { ...item.variant, priceDelta: 0 },
            }
          : item
      )
    );
  }

  function handleUpdatePaidPrice(entryId: string, newPaidPrice?: number) {
    const normalized =
      typeof newPaidPrice === 'number' && Number.isFinite(newPaidPrice) && newPaidPrice >= 0
        ? Number(newPaidPrice.toFixed(2))
        : undefined;
    setPageItems((prev) =>
      prev.map((item) =>
        item.entryId === entryId
          ? {
              ...item,
              paidPrice: normalized,
            }
          : item
      )
    );
    notifyAdded(
      normalized !== undefined ? 'Prezzo pagato salvato' : 'Prezzo pagato rimosso'
    );
  }

  function handleUpdateImage(entryId: string, newImageUrl: string) {
    setPageItems((prev) =>
      prev.map((item) =>
        item.entryId === entryId
          ? {
              ...item,
              product: {
                ...item.product,
                imageUrl: newImageUrl ? newImageUrl : undefined,
              },
            }
          : item
      )
    );
  }

  function handleUpdateTitle(entryId: string, newTitle: string) {
    const cleanTitle = newTitle.trim();
    if (!cleanTitle) return;
    setPageItems((prev) =>
      prev.map((item) =>
        item.entryId === entryId
          ? {
              ...item,
              customTitle: true,
              product: { ...item.product, name: cleanTitle },
            }
          : item
      )
    );
    notifyAdded(`Titolo aggiornato in «${cleanTitle}»`);
  }

  function handleUpdateRoom(entryId: string, room: string) {
    const cleanRoom = room.trim() || 'Non assegnata';
    setPageItems((prev) =>
      prev.map((item) => (item.entryId === entryId ? { ...item, room: cleanRoom } : item))
    );
  }

  function handleUpdateItemDetails(entryId: string, updates: ItemDetailsUpdate) {
    const cleanColorName = hasDisplayColor(updates.colorName)
      ? updates.colorName.trim()
      : '';
    const cleanColorHex = cleanColorName ? updates.colorHex : '';
    const cleanSourceUrl = updates.sourceUrl?.trim() || undefined;
    const cleanOfficialUrl = updates.officialUrl?.trim() || undefined;

    setPageItems((prev) =>
      prev.map((item) => {
        if (item.entryId !== entryId) return item;
        const filteredSpecs = item.product.specs
          .filter(
            (s) =>
              !s.label.toLowerCase().includes('collegamento') &&
              !s.label.toLowerCase().includes('link sorgente') &&
              !s.label.toLowerCase().includes('produttore')
          )
          .map((s) => {
            const lbl = s.label.toLowerCase();
            if (lbl === 'memoria / taglia') {
              return { ...s, value: updates.variantLabel };
            }
            if (lbl === 'asin / codice' || lbl === 'codice / sku') {
              return { ...s, value: updates.sku };
            }
            return s;
          });
        const nextSpecs = [
          ...filteredSpecs,
          ...(cleanSourceUrl
            ? [{ label: 'Collegamento originale', value: cleanSourceUrl }]
            : []),
          ...(cleanOfficialUrl
            ? [{ label: 'Sito ufficiale produttore', value: cleanOfficialUrl }]
            : []),
        ];

        return {
          ...item,
          room: updates.room || 'Non assegnata',
          paidPrice: updates.paidPrice,
          customizedVariant: updates.customizedVariant ?? item.customizedVariant,
          customTitle:
            item.customTitle ||
            updates.name.trim() !== item.product.name.trim(),
          product: {
            ...item.product,
            name: updates.name,
            brand: updates.brand,
            category: updates.category,
            sku: updates.sku,
            shortSummary: updates.shortSummary,
            price: updates.unitPrice,
            imageUrl: updates.imageUrl,
            sourceUrl: cleanSourceUrl,
            officialUrl: cleanOfficialUrl,
            specs: nextSpecs,
          },
          variant: {
            ...item.variant,
            label: updates.variantLabel,
            colorName: cleanColorName,
            colorHex: cleanColorHex,
            priceDelta: 0,
          },
        };
      })
    );
    notifyAdded(
      updates.variantLinkResolved
        ? `Link e dettagli aggiornati per «${updates.name}»`
        : `Dettagli aggiornati per «${updates.name}»`
    );
  }

  async function handleAddAttachments(entryId: string, files: FileList | File[]) {
    const fileList = Array.from(files);
    if (fileList.length === 0) return;

    const newAttachments: ProductAttachment[] = [];
    for (const file of fileList) {
      const id = `att-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      await saveAttachmentBlob(id, file);
      newAttachments.push({
        id,
        name: file.name,
        mimeType: file.type || 'application/octet-stream',
        size: file.size,
        addedAt: Date.now(),
      });
    }

    setPageItems((prev) =>
      prev.map((item) =>
        item.entryId === entryId
          ? { ...item, attachments: [...(item.attachments || []), ...newAttachments] }
          : item
      )
    );

    notifyAdded(
      newAttachments.length === 1
        ? `Allegato «${newAttachments[0].name}» aggiunto`
        : `${newAttachments.length} allegati aggiunti`
    );
  }

  async function handleRemoveAttachment(entryId: string, attachmentId: string) {
    await deleteAttachmentBlob(attachmentId);
    setPageItems((prev) =>
      prev.map((item) =>
        item.entryId === entryId
          ? {
              ...item,
              attachments: (item.attachments || []).filter((a) => a.id !== attachmentId),
            }
          : item
      )
    );
    notifyAdded('Allegato rimosso');
  }

  async function handleImportFromUrl(
    url: string,
    addDirectly: boolean,
    room = 'Non assegnata'
  ): Promise<boolean> {
    const cleanRoom = room.trim() || 'Non assegnata';
    setImportError(null);
    setImportWarning(null);

    if (addDirectly) {
      const existing = findMatchingSavedItem(pageItems, {
        sourceUrl: url,
        room: cleanRoom,
        strictVariant: false,
      });
      if (existing) {
        const nextQty = existing.quantity + 1;
        const recoveredColor = hasDisplayColor(existing.variant.colorName)
          ? existing.variant.colorName!
          : extractExplicitColorFromTextClient(existing.product.name);
        let recoveredHex = existing.variant.colorHex || '';
        if (
          recoveredColor &&
          (!recoveredHex || recoveredHex.toUpperCase() === '#2B2C30')
        ) {
          const imgHex = existing.product.imageUrl
            ? await extractDominantColorHexFromImage(existing.product.imageUrl)
            : null;
          recoveredHex = imgHex || inferColorHexClient(recoveredColor);
        }
        setPageItems((prev) =>
          prev.map((item) =>
            item.entryId === existing.entryId
              ? {
                  ...item,
                  quantity: item.quantity + 1,
                  variant: recoveredColor
                    ? { ...item.variant, colorName: recoveredColor, colorHex: recoveredHex }
                    : item.variant,
                }
              : item
          )
        );
        notifyAdded(`Quantità aggiornata a ${nextQty} per «${existing.product.name}»`);
        window.setTimeout(() => {
          document.getElementById('riepilogo-pagina')?.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
        }, 80);
        return true;
      }
    }

    setIsImportingUrl(true);

    try {
      const res = await fetch('/api/catalog/import-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });

      const data = (await res.json()) as {
        product?: Product;
        partial?: boolean;
        warning?: string;
        error?: string;
      };

      if (!res.ok || !data.product) {
        throw new Error(data.error || 'Impossibile leggere questo collegamento.');
      }

      let importedProduct: Product = {
        ...data.product,
        sourceUrl: data.product.sourceUrl || url.trim(),
      };

      const firstVariant = importedProduct.variants[0];
      if (
        importedProduct.imageUrl &&
        firstVariant &&
        hasDisplayColor(firstVariant.colorName)
      ) {
        const imageHex = await extractDominantColorHexFromImage(importedProduct.imageUrl);
        if (imageHex) {
          importedProduct = {
            ...importedProduct,
            variants: [
              { ...firstVariant, colorHex: imageHex },
              ...importedProduct.variants.slice(1),
            ],
          };
        }
      }

      if (data.warning) {
        setImportWarning(data.warning);
      }

      if (addDirectly) {
        handleAddToPage(importedProduct, importedProduct.variants[0], cleanRoom);
        window.setTimeout(() => {
          document.getElementById('riepilogo-pagina')?.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
        }, 80);
      } else {
        setPreviewProducts([importedProduct]);
        setShowResults(true);
        window.setTimeout(() => {
          resultsAnchorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 60);
      }
      return true;
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'Errore durante la lettura del link prodotto.';
      setImportError(msg);
      return false;
    } finally {
      setIsImportingUrl(false);
    }
  }

  function jumpToLinkBar() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    searchInputRef.current?.focus();
  }

  function openManualPanel(prefill = '') {
    setPrefillManualName(prefill);
    setManualPanelOpen(true);
    setImportError(null);
    setImportWarning(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function jumpToMyPage() {
    document.getElementById('riepilogo-pagina')?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  }

  return (
    <div id="top" className="min-h-screen flex flex-col bg-[#F7F7F5] text-[#141413]">
      <TopBar
        pageItemCount={totalPageCount}
        onJumpToLinkBar={jumpToLinkBar}
        onOpenManualPanel={() => openManualPanel()}
        onJumpToMyPage={jumpToMyPage}
      />

      {/* Top Link Import & Manual Workspace */}
      <section className="bg-white border-b border-[#E4E4E0]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
          <div className="max-w-4xl">
            <h1 className="text-2xl sm:text-4xl font-bold tracking-tight text-[#141413] [text-wrap:balance]">
              Incolla il link di un prodotto per aggiungerlo alla tua pagina
            </h1>
            <p className="text-sm sm:text-base text-[#5E5E59] mt-2 max-w-2xl leading-relaxed">
              Estrazione automatica di titolo, marca, categoria, colore, memoria, prezzo e foto
              direttamente dai link dei negozi, oppure inserimento manuale con assegnazione alla
              stanza.
            </p>
          </div>

          <div className="mt-6">
            <SearchBar
              query={query}
              rooms={rooms}
              savedItems={pageItems}
              isDropdownOpen={isDropdownOpen}
              isImportingUrl={isImportingUrl}
              inputRef={searchInputRef}
              onQueryChange={setQuery}
              onDropdownOpenChange={setIsDropdownOpen}
              onImportFromUrl={handleImportFromUrl}
              onOpenManualWithText={(name) => {
                openManualPanel(name);
                setQuery('');
              }}
              onJumpToMyPage={jumpToMyPage}
            />
          </div>

          <CustomImportPanel
            isOpen={manualPanelOpen}
            rooms={rooms}
            defaultRoom="Non assegnata"
            initialModelName={prefillManualName}
            onOpenChange={(open) => {
              setManualPanelOpen(open);
              if (!open) setPrefillManualName('');
            }}
            onAddCustomProduct={(product, room, paidPrice) => {
              handleAddToPage(product, product.variants[0], room, paidPrice);
              setManualPanelOpen(false);
              setPrefillManualName('');
              window.setTimeout(jumpToMyPage, 80);
            }}
          />
        </div>
      </section>

      {/* Main Content Area: Link Preview (when open) + Curated User Page Below */}
      <main className="flex-1">
        <div ref={resultsAnchorRef} />

        {showResults && previewProducts.length > 0 && (
          <SearchResults
            results={previewProducts}
            pageItems={pageItems}
            rooms={rooms}
            defaultRoom="Non assegnata"
            onAddToPage={handleAddToPage}
            onCloseResults={() => {
              setShowResults(false);
              setPreviewProducts([]);
            }}
          />
        )}

        {importError && (
          <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 pt-6">
            <div className="p-3.5 bg-[#FEF2F2] border border-[#FECACA] rounded-lg text-xs sm:text-sm text-[#991B1B] flex items-start justify-between gap-3">
              <span>{importError}</span>
              <button
                type="button"
                onClick={() => setImportError(null)}
                aria-label="Chiudi errore"
                className="p-0.5 text-[#991B1B] hover:text-[#141413] shrink-0 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {importWarning && (
          <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 pt-6">
            <div className="p-3.5 bg-[#FFFBEB] border border-[#FDE68A] rounded-lg text-xs sm:text-sm text-[#92400E] flex items-start justify-between gap-3">
              <span>{importWarning}</span>
              <button
                type="button"
                onClick={() => setImportWarning(null)}
                aria-label="Chiudi avviso"
                className="p-0.5 text-[#92400E] hover:text-[#141413] shrink-0 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        <UserPageSection
          items={pageItems}
          rooms={rooms}
          onAddRoom={handleAddRoom}
          onUpdateQuantity={handleUpdateQuantity}
          onUpdateTitle={handleUpdateTitle}
          onUpdatePrice={handleUpdatePrice}
          onUpdatePaidPrice={handleUpdatePaidPrice}
          onUpdateImage={handleUpdateImage}
          onUpdateRoom={handleUpdateRoom}
          onUpdateItemDetails={handleUpdateItemDetails}
          onAddAttachments={handleAddAttachments}
          onRemoveAttachment={handleRemoveAttachment}
          onRemoveItem={handleRemoveItem}
          onMoveItem={handleMoveItem}
          onClearPage={handleClearPage}
          onOpenLinkPanel={jumpToLinkBar}
          onOpenManualPanel={() => openManualPanel()}
        />
      </main>

      {/* Quiet Footer */}
      <footer className="bg-white border-t border-[#E4E4E0] mt-auto">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#5E5E59]">
          <p>© {new Date().getFullYear()} Vetrina Diretta · Importazione da link e inventario stanze</p>
          <p className="tabular-nums">
            Articoli salvati nella tua pagina: {totalPageCount}
          </p>
        </div>
      </footer>

      {/* Subtle Bottom Feedback Notification when adding items */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 bg-[#141413] text-white text-xs sm:text-sm font-medium px-4 py-3 rounded-lg shadow-lg flex items-center gap-2.5 max-w-sm"
        >
          <Check className="w-4 h-4 text-[#F59E0B] shrink-0" aria-hidden="true" />
          <span className="truncate">{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
