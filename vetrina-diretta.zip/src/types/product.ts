export type ProductCategory =
  | 'Smartphone'
  | 'Tablet'
  | 'Computer'
  | 'Audio'
  | 'Wearable'
  | 'Fotografia'
  | 'Casa & Gaming'
  | 'Elettrodomestici'
  | 'Arredamento'
  | 'Strumenti Musicali'
  | 'Sport & Tempo Libero'
  | 'Fai da te'
  | 'Domotica & Rete'
  | (string & {});

export type VisualKind =
  | 'phone-pro'
  | 'phone-blue'
  | 'phone-teal'
  | 'tablet-pro'
  | 'tablet-air'
  | 'laptop-pro'
  | 'headphones'
  | 'earbuds'
  | 'watch-ultra'
  | 'watch-series'
  | 'camera'
  | 'ereader'
  | 'vacuum'
  | 'console'
  | 'mouse'
  | 'monitor'
  | 'drone'
  | 'appliance'
  | 'furniture'
  | 'guitar'
  | 'amp'
  | 'shoe'
  | 'tool'
  | 'lighting'
  | 'tv'
  | 'sofa'
  | 'router'
  | 'kitchen'
  | 'smarthome'
  | 'generic-product';

export interface ProductColorOption {
  id: string;
  name: string;
  hex: string;
}

export interface ProductVariant {
  id: string;
  label: string;
  colorName?: string;
  colorHex?: string;
  priceDelta: number;
  sourceUrl?: string;
  sku?: string;
}

export interface VariantLinkOption {
  size?: string;
  color?: string;
  sku: string;
  url: string;
}

export interface TechnicalSpec {
  label: string;
  value: string;
}

export interface ProductAttachment {
  id: string;
  name: string;
  mimeType: string;
  size: number;
  addedAt: number;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  brand: string;
  category: ProductCategory;
  searchPriority: number;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  availability: string;
  deliveryText: string;
  warranty: string;
  imageUrl?: string;
  sourceUrl?: string;
  officialUrl?: string;
  visualKind: VisualKind;
  shortSummary: string;
  highlights: string[];
  specs: TechnicalSpec[];
  boxContents: string[];
  colorOptions?: ProductColorOption[];
  variantLinks?: VariantLinkOption[];
  sizeLabel?: string;
  variants: ProductVariant[];
  keywords: string[];
}

export interface SavedPageItem {
  entryId: string;
  product: Product;
  variant: ProductVariant;
  quantity: number;
  room?: string;
  paidPrice?: number;
  attachments?: ProductAttachment[];
  customizedVariant?: boolean;
  customTitle?: boolean;
  addedAt: number;
}

export const DEFAULT_HOME_ROOMS: string[] = [
  'Salone',
  'Cucina',
  'Bagno 1',
  'Bagno 2',
  'Stanza Roberta',
  'Stanza Maurizio',
  'Camera Matrimoniale',
  'Terrazzo / Esterno',
  'Non assegnata'
];
