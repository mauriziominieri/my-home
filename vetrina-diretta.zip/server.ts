import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

type ProductSpec = { label: string; value: string };

interface NormalizedProduct {
  id: string;
  sku: string;
  name: string;
  brand: string;
  category: string;
  searchPriority: number;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  availability: string;
  deliveryText: string;
  warranty: string;
  imageUrl?: string;
  sourceUrl?: string;
  officialUrl?: string;
  visualKind: string;
  shortSummary: string;
  highlights: string[];
  specs: ProductSpec[];
  boxContents: string[];
  colorOptions?: Array<{ id: string; name: string; hex: string }>;
  variantLinks?: Array<{ size?: string; color?: string; sku: string; url: string }>;
  sizeLabel?: string;
  variants: Array<{
    id: string;
    label: string;
    colorName?: string;
    colorHex?: string;
    priceDelta: number;
    sourceUrl?: string;
    sku?: string;
  }>;
  keywords: string[];
}


function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY_MISSING');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}


function isSafeExternalUrl(rawUrl: string): URL | null {
  try {
    const parsed = new URL(rawUrl.trim());
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
    if (parsed.port && parsed.port !== '80' && parsed.port !== '443') return null;

    const host = parsed.hostname.toLowerCase();
    if (
      host === 'localhost' ||
      host === '0.0.0.0' ||
      host === '::1' ||
      host.endsWith('.local') ||
      host.endsWith('.internal')
    ) {
      return null;
    }

    // Block private IPv4 ranges
    const ipv4 = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
    if (ipv4) {
      const a = Number(ipv4[1]);
      const b = Number(ipv4[2]);
      if (
        a === 10 ||
        a === 127 ||
        a === 0 ||
        (a === 169 && b === 254) ||
        (a === 172 && b >= 16 && b <= 31) ||
        (a === 192 && b === 168)
      ) {
        return null;
      }
    }

    return parsed;
  } catch {
    return null;
  }
}

function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function inferBrandFromHost(hostname: string): string {
  const h = hostname.toLowerCase().replace(/^www\./, '');
  if (h.includes('ikea.')) return 'IKEA';
  if (h.includes('federicisofa.')) return 'Federici Sofà';
  if (h.includes('venetacucine.')) return 'Veneta Cucine';
  if (h.includes('maisonsdumonde.')) return 'Maisons du Monde';
  if (h.includes('tcl.')) return 'TCL';
  if (h.includes('samsung.')) return 'Samsung';
  if (h.includes('apple.')) return 'Apple';
  if (h.includes('windtre.')) return 'WindTre';
  if (h.includes('bticino.')) return 'BTicino';
  if (h.includes('febalcasa.')) return 'Febal Casa';
  if (h.includes('electrolux.')) return 'Electrolux';
  if (h.includes('leroymerlin.')) return 'Leroy Merlin';
  if (h.includes('mediaworld.')) return 'MediaWorld';
  if (h.includes('unieuro.')) return 'Unieuro';
  if (h.includes('amazon.')) return 'Amazon';
  const main = h.split('.')[0] || 'Web';
  return main.charAt(0).toUpperCase() + main.slice(1);
}

function inferManufacturerFromText(text: string): string | undefined {
  const t = text.toLowerCase();
  const known: Array<[RegExp, string]> = [
    [/\b(iphone|ipad|macbook|apple|airpods|imac)\b/, 'Apple'],
    [/\b(galaxy|samsung)\b/, 'Samsung'],
    [/\btcl\b/, 'TCL'],
    [/\belectrolux\b/, 'Electrolux'],
    [/\bbticino\b/, 'BTicino'],
    [/\bwind\s*tre\b|\bwindtre\b/, 'WindTre'],
    [/\bfederici\b/, 'Federici Sofà'],
    [/\bveneta cucine\b/, 'Veneta Cucine'],
    [/\bfebal\b/, 'Febal Casa'],
    [/\bmaisons du monde\b/, 'Maisons du Monde'],
    [/\bikea\b/, 'IKEA'],
    [/\bibanez\b/, 'Ibanez'],
    [/\bsony\b/, 'Sony'],
    [/\bdyson\b/, 'Dyson'],
    [/\bnintendo\b/, 'Nintendo'],
    [/\bkindle\b/, 'Amazon Kindle'],
    [/\bgarmin\b/, 'Garmin'],
    [/\blogitech\b/, 'Logitech'],
    [/\bbose\b/, 'Bose'],
    [/\bdji\b/, 'DJI'],
    [/\bphilips\b/, 'Philips'],
  ];
  for (const [re, brand] of known) {
    if (re.test(t)) return brand;
  }
  return undefined;
}

const SERVER_COLOR_RULES: Array<[RegExp, string]> = [
  [/\b(arancione\s*cosmico|cosmic\s*orange)\b/, '#D96B27'],
  [/\b(oro\s*rosa|rose\s*gold|pink\s*gold)\b/, '#C99588'],
  [/\b(blu\s*(?:notte|mezzanotte)|midnight(?:\s*blue)?|mezzanotte)\b/, '#1A2438'],
  [/\b(blu\s*(?:profondo|marino|scuro)|deep\s*blue|dark\s*blue|navy)\b/, '#1F2F4C'],
  [/\b(blu\s*(?:cobalto|elettrico|zaffiro)|cobalto|cobalt|zaffiro|sapphire|ultramarino|oltremare)\b/, '#1E4D9B'],
  [/\b(carta\s*da\s*zucchero|avio|denim|jeans)\b/, '#52728F'],
  [/\b(verde\s*petrolio|petrolio|ottanio|teal|pavone)\b/, '#1C5D68'],
  [/\b(verde\s*(?:bosco|abete|pino|scuro)|forest\s*green|dark\s*green)\b/, '#244C38'],
  [/\b(verde\s*militare|militare|oliva|olive|muschio|moss|kaki|khaki|cachi)\b/, '#55613C'],
  [/\b(verde\s*smeraldo|smeraldo|emerald|giada|jade)\b/, '#257A57'],
  [/\b(verde\s*salvia|salvia|sage|eucalipto)\b/, '#7A9482'],
  [/\b(verde\s*menta|menta|mint|pistacchio|pistachio|acquamarina|tiffany)\b/, '#74B89E'],
  [/\b(verde\s*acqua)\b/, '#5FA395'],
  [/\b(rosa\s*(?:antico|cipria)|cipria|dusty\s*rose|blush)\b/, '#CFA1A6'],
  [/\b(titanio\s*naturale|natural\s*titanium)\b/, '#A8A59E'],
  [/\b(titanio\s*nero|black\s*titanium|canna\s*di\s*fucile|gunmetal)\b/, '#525458'],
  [/\b(grigio\s*(?:siderale|scuro)|space\s*gr[ae]y|dark\s*gr[ae]y|piombo|fumo)\b/, '#5A5D64'],
  [/\b(bianco\s*caldo|off\s*white)\b/, '#EDE8DC'],

  [/\b(borgogna|burgundy|bordeaux|vinaccia|sangria|chianti|barolo|amarone)\b/, '#7A1C2E'],
  [/\b(granata|garnet)\b/, '#7B1E26'],
  [/\b(amaranto|crimson|cremisi|carminio|rubino|ruby|ciliegia|cherry)\b/, '#9E1B32'],
  [/\b(melanzana|aubergine|eggplant)\b/, '#4E2340'],
  [/\b(prugna|plum)\b/, '#5E2B4E'],
  [/\b(lampone|raspberry|fragola|strawberry)\b/, '#B8294B'],
  [/\b(terracotta|mattone|brick|coccio)\b/, '#B55239'],
  [/\b(ruggine|rust)\b/, '#9E472A'],
  [/\b(corallo|coral)\b/, '#E06553'],
  [/\b(salmone|salmon)\b/, '#E58975'],

  [/\b(pesca|peach|albicocca|apricot)\b/, '#F0A678'],
  [/\b(ambra|amber|miele|honey|caramello|caramel)\b/, '#C97A2B'],
  [/\b(senape|mustard|ocra|ochre|curcuma|zafferano)\b/, '#C79326'],
  [/\b(champagne|starlight|galassia)\b/, '#DFD3BE'],
  [/\b(ottone|brass|ottonato)\b/, '#C5A059'],
  [/\b(lime|cedro|chartreuse)\b/, '#9AB83B'],

  [/\b(turchese|turquoise|ciano|cyan)\b/, '#249EA8'],
  [/\b(azzurro|celeste|sky\s*blue|light\s*blue|ghiaccio)\b/, '#6AA7D9'],
  [/\b(fucsia|fuchsia|magenta)\b/, '#B8296B'],
  [/\b(indaco|indigo|mora)\b/, '#4B2E6E'],
  [/\b(lavanda|lavender|lilla|lilac|glicine|pervinca|malva|mauve|orchidea)\b/, '#A38DB8'],

  [/\b(wenge|ebano|ebony|palissandro)\b/, '#3D2B22'],
  [/\b(caffe|coffee|espresso|cioccolato|chocolate|cacao)\b/, '#4E3529'],
  [/\b(mogano|mahogany|castagno|chestnut)\b/, '#6E3B2B'],
  [/\b(cuoio|cognac|tabacco|leather|saddle|nocciola|noce|walnut)\b/, '#855436'],
  [/\b(teak|rovere|quercia|oak|legno|wood|faggio|frassino|betulla|bambu)\b/, '#B58F63'],
  [/\b(cammello|camel|taupe|tortora|talpa|visone|marrone|brown)\b/, '#7F614A'],
  [/\b(sabbia|sand|beige|canapa|lino|ecru|crema|cream)\b/, '#CFC1AA'],
  [/\b(rame|copper)\b/, '#B86B43'],
  [/\b(bronzo|bronze)\b/, '#7D5C3E'],
  [/\b(titanio|titanium)\b/, '#7A7C80'],
  [/\b(antracite|anthracite|grafite|graphite|carbone|charcoal|ossidiana|onice|ardesia)\b/, '#36383E'],
  [/\b(argento|silver|inox|acciaio|steel|cromo|cromato|chrome|platino|platinum|alluminio)\b/, '#C5C8CE'],
  [/\b(avorio|ivory|panna|perla|pearl)\b/, '#EDE8DC'],

  [/\b(arancione|arancio|orange|mandarino|tangerine|zucca|cosmico)\b/, '#E06D22'],
  [/\b(rosso|red|scarlatto|vermiglio)\b/, '#B82828'],
  [/\b(oro|gold|dorato)\b/, '#D4AF37'],
  [/\b(giallo|yellow|limone|lemon|canarino)\b/, '#E2B729'],
  [/\b(verde|green|acqua)\b/, '#38764B'],
  [/\b(blu|blue|marino)\b/, '#25539B'],
  [/\b(viola|violetto|violet|purple)\b/, '#764B9E'],
  [/\b(rosa|pink)\b/, '#D9829B'],
  [/\b(grigio|gr[ae]y|cemento|concrete|cenere|pietra)\b/, '#8D9096'],
  [/\b(bianco|white|neve|snow|latte)\b/, '#F2F2EE'],
  [/\b(nero|black|corvino)\b/, '#1C1D20'],
];

function inferColorHex(colorName: string): string {
  const normalized = colorName
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
  if (!normalized) return '#2B2C30';
  for (const [pattern, hex] of SERVER_COLOR_RULES) {
    if (pattern.test(normalized)) return hex;
  }
  return '#2B2C30';
}

const IGNORED_COLOR_PLACEHOLDERS = new Set([
  'originale',
  'come da pagina prodotto',
  'modello specifico',
  'non specificato',
  'non presente',
  'nessuno',
  'nessuna',
  'n/a',
  'nd',
  'n.d.',
  'standard',
]);

function cleanOptionalColorName(raw: unknown): string {
  if (typeof raw !== 'string') return '';
  const cleaned = decodeHtmlEntities(raw).trim();
  if (!cleaned) return '';
  if (IGNORED_COLOR_PLACEHOLDERS.has(cleaned.toLowerCase())) return '';
  return cleaned;
}

const EXPLICIT_COLOR_PATTERNS: Array<[RegExp, string]> = [
  [/\b(grigio\s*siderale|space\s*gr[ae]y)\b/i, 'Grigio Siderale'],
  [/\b(titanio\s*naturale|natural\s*titanium)\b/i, 'Titanio Naturale'],
  [/\b(titanio\s*nero|black\s*titanium)\b/i, 'Titanio Nero'],
  [/\b(titanio\s*blu|blue\s*titanium)\b/i, 'Titanio Blu'],
  [/\b(titanio\s*sabbia|desert\s*titanium)\b/i, 'Titanio Sabbia'],
  [/\b(titanio\s*bianco|white\s*titanium)\b/i, 'Titanio Bianco'],
  [/\b(oro\s*rosa|rose\s*gold|pink\s*gold)\b/i, 'Oro Rosa'],
  [/\b(blu\s*mezzanotte|midnight(?:\s*blue)?)\b/i, 'Blu Mezzanotte'],
  [/\b(blu\s*notte)\b/i, 'Blu Notte'],
  [/\b(blu\s*profondo|deep\s*blue)\b/i, 'Blu Profondo'],
  [/\b(blu\s*marino|navy\s*blue|navy)\b/i, 'Blu Marino'],
  [/\b(blu\s*cobalto|cobalt\s*blue)\b/i, 'Blu Cobalto'],
  [/\b(verde\s*petrolio|ottanio|teal)\b/i, 'Verde Petrolio'],
  [/\b(verde\s*bosco|forest\s*green)\b/i, 'Verde Bosco'],
  [/\b(verde\s*militare|olive\s*green|oliva)\b/i, 'Verde Militare'],
  [/\b(verde\s*salvia|sage\s*green|salvia)\b/i, 'Verde Salvia'],
  [/\b(verde\s*smeraldo|emerald)\b/i, 'Verde Smeraldo'],
  [/\b(verde\s*menta|mint\s*green)\b/i, 'Verde Menta'],
  [/\b(verde\s*acqua)\b/i, 'Verde Acqua'],
  [/\b(rosa\s*cipria|dusty\s*rose)\b/i, 'Rosa Cipria'],
  [/\b(rosa\s*antico)\b/i, 'Rosa Antico'],
  [/\b(bianco\s*caldo|off\s*white)\b/i, 'Bianco Caldo'],
  [/\b(arancione\s*cosmico|cosmic\s*orange)\b/i, 'Arancione Cosmico'],
  [/\b(grigio\s*scuro|dark\s*gr[ae]y)\b/i, 'Grigio Scuro'],
  [/\b(grigio\s*chiaro|light\s*gr[ae]y)\b/i, 'Grigio Chiaro'],
  [/\b(antracite|anthracite)\b/i, 'Antracite'],
  [/\b(grafite|graphite)\b/i, 'Grafite'],
  [/\b(argento|silver)\b/i, 'Argento'],
  [/\b(champagne|starlight|galassia)\b/i, 'Champagne'],
  [/\b(bordeaux|borgogna|burgundy)\b/i, 'Bordeaux'],
  [/\b(turchese|turquoise)\b/i, 'Turchese'],
  [/\b(azzurro|celeste|sky\s*blue)\b/i, 'Azzurro'],
  [/\b(tortora|taupe)\b/i, 'Tortora'],
  [/\b(beige|sabbia)\b/i, 'Beige'],
  [/\b(avorio|panna)\b/i, 'Avorio'],
  [/\b(marrone|brown)\b/i, 'Marrone'],
  [/\b(bronzo|bronze)\b/i, 'Bronzo'],
  [/\b(rosso|red)\b/i, 'Rosso'],
  [/\b(blu|blue)\b/i, 'Blu'],
  [/\b(verde|green)\b/i, 'Verde'],
  [/\b(giallo|yellow)\b/i, 'Giallo'],
  [/\b(arancione|orange)\b/i, 'Arancione'],
  [/\b(viola|purple|violet)\b/i, 'Viola'],
  [/\b(rosa|pink)\b/i, 'Rosa'],
  [/\b(grigio|gr[ae]y)\b/i, 'Grigio'],
  [/\b(bianco|white)\b/i, 'Bianco'],
  [/\b(nero|black)\b/i, 'Nero'],
];

function extractExplicitColorFromText(rawText: string): string {
  const cleaned = decodeHtmlEntities(rawText)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, ' ')
    .trim();
  if (!cleaned) return '';
  for (const [pattern, label] of EXPLICIT_COLOR_PATTERNS) {
    if (pattern.test(cleaned)) return label;
  }
  return '';
}

function normalizeServerSizeText(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  const storageMatch = trimmed.match(
    /^(\d+(?:[.,]\d+)?)\s*(giga(?:byte)?s?|gb|tera(?:byte)?s?|tb|mega(?:byte)?s?|mb)$/i
  );
  if (storageMatch) {
    const num = storageMatch[1].replace(',', '.');
    const unitRaw = storageMatch[2].toLowerCase();
    const unit = unitRaw.startsWith('t') ? 'TB' : unitRaw.startsWith('g') ? 'GB' : 'MB';
    return `${num} ${unit}`;
  }
  return trimmed;
}

function isSameServerSize(a?: string, b?: string): boolean {
  if (!a || !b) return false;
  const na = normalizeServerSizeText(a).replace(/\s+/g, '').toLowerCase();
  const nb = normalizeServerSizeText(b).replace(/\s+/g, '').toLowerCase();
  return Boolean(na && nb && na === nb);
}

function stripDuplicateColorFromTitle(rawTitle: string, colorName?: string): string {
  const title = rawTitle.trim();
  const color = colorName?.trim();
  if (!title || !color) return title;

  const titleExplicitColor = extractExplicitColorFromText(title);
  const targetColor =
    titleExplicitColor &&
    titleExplicitColor.toLowerCase() !== color.toLowerCase() &&
    titleExplicitColor.toLowerCase().includes(color.toLowerCase())
      ? titleExplicitColor
      : color;

  const escapedColor = targetColor.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+');
  const result = title
    // Remove parenthesized color e.g. "(Borgogna)" or "(Colore: Borgogna)"
    .replace(new RegExp(`\\s*\\(\\s*(?:colore\\s*[:\\-]?\\s*)?${escapedColor}\\s*\\)`, 'gi'), '')
    // Remove color preceded by separator or standalone word boundary
    .replace(
      new RegExp(
        `\\s*(?:[-–—|/;,:\\u00b7]+\\s*)?(?:colore\\s*[:\\-]?\\s*)?(?<![A-Za-zÀ-ÿ0-9])${escapedColor}(?![A-Za-zÀ-ÿ0-9])`,
        'gi'
      ),
      ''
    )
    .replace(/\(\s*\)/g, '')
    .replace(/\s*,\s*(?=[(\[])/g, ' ')
    .replace(/,\s*,+/g, ',')
    .replace(/\s{2,}/g, ' ')
    .replace(/^[\s,\-–—|/;:,]+|[\s,\-–—|/;:,]+$/g, '')
    .trim();

  return result.length >= 4 ? result : title;
}

function parseAmazonAStateJson<T>(html: string, keys: string[]): T | null {
  for (const key of keys) {
    const escapedKey = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp(
      `data-a-state=["']\\{[^"']*${escapedKey}[^"']*\\}["'][^>]*>([^<]+)<`,
      'i'
    );
    const match = html.match(re)?.[1];
    if (match) {
      try {
        return JSON.parse(decodeHtmlEntities(match)) as T;
      } catch {
        // try next key
      }
    }
  }
  return null;
}

function stableUrlId(sku: string, parsedUrl: URL): string {
  const canonical = `${parsedUrl.hostname.toLowerCase().replace(/^www\./, '')}${parsedUrl.pathname.replace(/\/+$/, '')}`;
  let hash = 2166136261;
  for (let i = 0; i < canonical.length; i++) {
    hash ^= canonical.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  const hashHex = (hash >>> 0).toString(36);
  const safeSku = sku.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'item';
  return `url-${safeSku}-${hashHex}`;
}

function inferCategoryAndVisual(
  rawCat: string,
  title: string
): { category: string; visualKind: string } {
  const text = `${rawCat} ${title}`.toLowerCase();
  if (
    text.includes('lampad') ||
    text.includes('sospensione') ||
    text.includes('plafoniera') ||
    text.includes('abat-jour') ||
    text.includes('illuminazione')
  ) {
    return { category: 'Arredamento', visualKind: 'lighting' };
  }
  if (text.includes('divan') || text.includes('sofà') || text.includes('sofa') || text.includes('poltrona')) {
    return { category: 'Arredamento', visualKind: 'sofa' };
  }
  if (text.includes('cucin') && !text.includes('piano cottura') && !text.includes('forno')) {
    return { category: 'Arredamento', visualKind: 'kitchen' };
  }
  if (
    text.includes('libreria') ||
    text.includes('scaffale') ||
    text.includes('armadio') ||
    text.includes('letto') ||
    text.includes('tavolo') ||
    text.includes('sedia') ||
    text.includes('mobile') ||
    text.includes('specchio') ||
    text.includes('credenza') ||
    text.includes('statuetta') ||
    text.includes('scultura') ||
    text.includes('busto') ||
    text.includes('vaso') ||
    text.includes('quadro') ||
    text.includes('tappeto') ||
    text.includes('decor')
  ) {
    return { category: 'Arredamento', visualKind: 'furniture' };
  }
  if (text.includes('tv') || text.includes('oled') || text.includes('qled') || text.includes('televisore')) {
    return { category: 'Casa & Gaming', visualKind: 'tv' };
  }
  if (
    text.includes('lavatrice') ||
    text.includes('asciugatrice') ||
    text.includes('lavastoviglie') ||
    text.includes('frigo') ||
    text.includes('forno') ||
    text.includes('induzione') ||
    text.includes('climatizzatore')
  ) {
    return { category: 'Elettrodomestici', visualKind: 'appliance' };
  }
  if (text.includes('router') || text.includes('modem') || text.includes('mesh') || text.includes('wifi')) {
    return { category: 'Domotica & Rete', visualKind: 'router' };
  }
  if (
    text.includes('bticino') ||
    text.includes('termostato') ||
    text.includes('placca') ||
    text.includes('videocitofono') ||
    text.includes('presa')
  ) {
    return { category: 'Domotica & Rete', visualKind: 'smarthome' };
  }
  if (text.includes('iphone') || text.includes('smartphone') || text.includes('galaxy')) {
    return { category: 'Smartphone', visualKind: 'phone-pro' };
  }
  if (text.includes('ipad') || text.includes('tablet')) {
    return { category: 'Tablet', visualKind: 'tablet-pro' };
  }
  if (text.includes('macbook') || text.includes('laptop') || text.includes('notebook')) {
    return { category: 'Computer', visualKind: 'laptop-pro' };
  }
  if (text.includes('chitarra') || text.includes('basso')) {
    return { category: 'Strumenti Musicali', visualKind: 'guitar' };
  }
  if (text.includes('cuffie') || text.includes('auricolari') || text.includes('soundbar')) {
    return { category: 'Audio', visualKind: 'headphones' };
  }
  return { category: 'Casa & Gaming', visualKind: 'generic-product' };
}

function extractMetaTag(html: string, attrName: string, attrValue: string): string | undefined {
  const re1 = new RegExp(
    `<meta[^>]*${attrName}=["']${attrValue}["'][^>]*content=["']([^"']+)["'][^>]*>`,
    'i'
  );
  const re2 = new RegExp(
    `<meta[^>]*content=["']([^"']+)["'][^>]*${attrName}=["']${attrValue}["'][^>]*>`,
    'i'
  );
  const match = html.match(re1) || html.match(re2);
  return match?.[1] ? decodeHtmlEntities(match[1]) : undefined;
}

function findProductLdNodes(node: unknown, out: Array<Record<string, unknown>>): void {
  if (!node || typeof node !== 'object') return;
  if (Array.isArray(node)) {
    for (const item of node) findProductLdNodes(item, out);
    return;
  }
  const obj = node as Record<string, unknown>;
  const nodeType = obj['@type'];
  const isProduct =
    nodeType === 'Product' ||
    (Array.isArray(nodeType) && nodeType.includes('Product'));
  if (isProduct) {
    out.push(obj);
  }
  if (Array.isArray(obj['@graph'])) {
    findProductLdNodes(obj['@graph'], out);
  }
}

function buildUrlFallbackFromSlug(parsedUrl: URL): NormalizedProduct {
  const brand = inferBrandFromHost(parsedUrl.hostname);
  const segments = parsedUrl.pathname.split('/').filter(Boolean);
  const rawSlug = (segments[segments.length - 1] || segments[segments.length - 2] || 'Articolo')
    .replace(/\.html?$/i, '');

  const skuMatch = rawSlug.match(/[-_](\d{5,12})$/);
  const extractedSku = skuMatch?.[1];
  const nameSlug = extractedSku ? rawSlug.slice(0, -extractedSku.length - 1) : rawSlug;

  const cleanedName = nameSlug
    .replace(/[-_]+/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();

  const lowerName = cleanedName.toLowerCase();
  const { category, visualKind } = inferCategoryAndVisual('', cleanedName);
  const sku = extractedSku || `URL-${stableUrlId('item', parsedUrl).slice(-6).toUpperCase()}`;

  const materialMatch = lowerName.match(
    /\b(?:in|di)\s+(cemento|legno|vetro|metallo|ottone|ferro|ceramica|porcellana|tessuto|velluto|pelle|lino|cotone|marmo|resina|plastica|acciaio|bambu|bambù)\b/i
  );
  const detectedMaterial = materialMatch?.[1]
    ? materialMatch[1].charAt(0).toUpperCase() + materialMatch[1].slice(1)
    : undefined;

  const dimMatch = lowerName.match(
    /\b(?:alt(?:ezza)?\s*)?(\d+(?:\s*[x×]\s*\d+)*\s*(?:cm|mm|m))\b/i
  );
  const detectedDim = dimMatch?.[0]
    ? dimMatch[0].replace(/\balt\b/i, 'Altezza').replace(/\s+/g, ' ').trim()
    : undefined;

  const specs: Array<{ label: string; value: string }> = [
    { label: 'Marca', value: brand },
    { label: 'Codice / SKU', value: sku },
  ];
  if (detectedMaterial) specs.push({ label: 'Materiale rilevato', value: detectedMaterial });
  if (detectedDim) specs.push({ label: 'Dimensioni rilevate', value: detectedDim });
  const fallbackColorName = extractExplicitColorFromText(cleanedName);
  const fallbackColorHex = fallbackColorName ? inferColorHex(fallbackColorName) : '';
  if (fallbackColorName) {
    specs.push({ label: 'Colore rilevato', value: fallbackColorName });
  }
  specs.push({ label: 'Link sorgente', value: parsedUrl.hostname.replace(/^www\./, '') });
  specs.push({ label: 'Collegamento originale', value: parsedUrl.href });

  const detailBits = [detectedMaterial, detectedDim].filter(Boolean).join(' · ');

  const slugDisplayName = stripDuplicateColorFromTitle(
    cleanedName || `Articolo ${brand}`,
    fallbackColorName
  );

  return {
    id: stableUrlId(sku, parsedUrl),
    sku,
    name: slugDisplayName,
    brand,
    category,
    searchPriority: 95,
    price: 0,
    rating: 4.7,
    reviewCount: 1,
    availability: 'Link importato (sito protetto)',
    deliveryText: `Fonte: ${parsedUrl.hostname.replace(/^www\./, '')}`,
    warranty: 'Verifica garanzia sul sito del venditore',
    sourceUrl: parsedUrl.href,
    visualKind,
    shortSummary: `${cleanedName || 'Articolo'} — ${brand}${
      detailBits ? ` (${detailBits})` : ''
    }. Il sito protegge la pagina con filtro anti-bot: puoi inserire prezzo e link foto direttamente nella card.`,
    highlights: [
      `Marca: ${brand}`,
      ...(extractedSku ? [`Codice articolo dal link: ${extractedSku}`] : []),
      ...(detectedMaterial ? [`Materiale: ${detectedMaterial}`] : []),
      ...(detectedDim ? [`Misure: ${detectedDim}`] : []),
      `Collegamento salvato: ${parsedUrl.hostname.replace(/^www\./, '')}`,
    ],
    specs,
    boxContents: [cleanedName || `Articolo ${brand}`],
    variants: [
      {
        id: 'url-std',
        label: 'Modello da link',
        colorName: fallbackColorName,
        colorHex: fallbackColorHex,
        priceDelta: 0,
      },
    ],
    keywords: [brand.toLowerCase(), cleanedName.toLowerCase(), sku.toLowerCase()],
  };
}

async function verifyImageUrl(candidateUrl: unknown): Promise<string | undefined> {
  if (typeof candidateUrl !== 'string') return undefined;
  const safe = isSafeExternalUrl(candidateUrl);
  if (!safe) return undefined;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 3000);
  try {
    const res = await fetch(safe.href, {
      method: 'GET',
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        Accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
      },
    });
    if (!res.ok) return undefined;
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.toLowerCase().startsWith('image/')) return undefined;
    return safe.href;
  } catch {
    return undefined;
  } finally {
    clearTimeout(timeout);
  }
}

const KNOWN_MANUFACTURER_DOMAINS: Array<[RegExp, string[]]> = [
  [/\bapple\b/i, ['apple.com']],
  [/\bsamsung\b/i, ['samsung.com']],
  [/\bsony\b/i, ['sony.it', 'sony.com', 'sony.eu']],
  [/\bdyson\b/i, ['dyson.it', 'dyson.com']],
  [/\belectrolux\b/i, ['electrolux.it', 'electrolux.com']],
  [/\btcl\b/i, ['tcl.com']],
  [/\bbticino\b/i, ['bticino.it', 'bticino.com']],
  [/\blg\b/i, ['lg.com']],
  [/\bdell\b/i, ['dell.com']],
  [/\blenovo\b/i, ['lenovo.com']],
  [/\basus\b/i, ['asus.com']],
  [/\bhp\b|hewlett/i, ['hp.com']],
  [/\bacer\b/i, ['acer.com']],
  [/\bmicrosoft\b/i, ['microsoft.com']],
  [/\bbose\b/i, ['bose.it', 'bose.com']],
  [/\blogitech\b/i, ['logitech.com', 'logitechg.com']],
  [/\bphilips\b/i, ['philips.it', 'philips.com']],
  [/\bgarmin\b/i, ['garmin.com']],
  [/\bnintendo\b/i, ['nintendo.it', 'nintendo.com']],
  [/\bdji\b/i, ['dji.com']],
  [/\bbosch\b/i, ['bosch-home.com', 'bosch-home.it', 'bosch.it', 'bosch.com']],
  [/\bsiemens\b/i, ['siemens-home.bsh-group.com', 'siemens.com']],
  [/\bmiele\b/i, ['miele.it', 'miele.com']],
  [/\bwhirlpool\b/i, ['whirlpool.it', 'whirlpool.com']],
  [/\bsmeg\b/i, ['smeg.com']],
  [/\bkitchenaid\b/i, ['kitchenaid.it', 'kitchenaid.com']],
  [/\bdelonghi\b|de'longhi/i, ['delonghi.com']],
  [/\bnikon\b/i, ['nikon.it', 'nikon.com']],
  [/\bcanon\b/i, ['canon.it', 'canon.com']],
  [/\bfujifilm\b/i, ['fujifilm.com', 'fujifilm-x.com']],
  [/\bibanez\b/i, ['ibanez.com']],
  [/\bfender\b/i, ['fender.com']],
  [/\byamaha\b/i, ['yamaha.com']],
  [/\bmarshall\b/i, ['marshall.com', 'marshallheadphones.com']],
  [/\broborock\b/i, ['roborock.com']],
  [/\bdreame\b/i, ['dreametech.com', 'dreame.it']],
  [/\bxiaomi\b/i, ['mi.com', 'xiaomi.com']],
  [/\bgoogle\b/i, ['store.google.com', 'google.com']],
  [/\bmeta\b/i, ['meta.com']],
  [/\brazer\b/i, ['razer.com']],
  [/\bcorsair\b/i, ['corsair.com']],
  [/\bsennheiser\b/i, ['sennheiser.com', 'sennheiser-hearing.com']],
  [/\banker\b|soundcore/i, ['anker.com', 'soundcore.com']],
  [/\bikea\b/i, ['ikea.com']],
  [/\bwindtre\b/i, ['windtre.it']],
];

const RETAILER_OR_NOISE_DOMAINS = [
  'amazon.',
  'ebay.',
  'mediaworld.',
  'unieuro.',
  'euronics.',
  'trony.',
  'monclick.',
  'eprice.',
  'leroymerlin.',
  'manomano.',
  'trovaprezzi.',
  'idealo.',
  'kelkoo.',
  'subito.',
  'wikipedia.',
  'youtube.',
  'facebook.',
  'instagram.',
  'tiktok.',
  'reddit.',
  'trustpilot.',
  'gsmarena.',
  'notebookcheck.',
  'rtings.',
  'vertexaisearch.',
];

const GENERIC_NON_BRANDS = new Set([
  'amazon',
  'amazon renewed',
  'amazon kindle',
  'web',
  'personale',
  'generico',
  'generic',
  'sconosciuto',
  'unknown',
]);

function isRetailerOrNoiseHost(hostname: string): boolean {
  const h = hostname.toLowerCase();
  return RETAILER_OR_NOISE_DOMAINS.some((frag) => h.includes(frag));
}

function isManufacturerHost(hostname: string, brand: string): boolean {
  const h = hostname.toLowerCase().replace(/^www\./, '');
  const cleanBrand = brand.trim().toLowerCase();
  if (!cleanBrand || GENERIC_NON_BRANDS.has(cleanBrand)) return false;

  for (const [pattern, domains] of KNOWN_MANUFACTURER_DOMAINS) {
    if (pattern.test(cleanBrand)) {
      return domains.some((d) => h === d || h.endsWith(`.${d}`));
    }
  }

  const brandSlug = cleanBrand
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '');
  if (brandSlug.length >= 3 && !isRetailerOrNoiseHost(h)) {
    const sld = h.split('.').slice(0, -1).join('');
    return sld.includes(brandSlug) || h.includes(brandSlug);
  }
  return false;
}

async function verifyManufacturerUrl(
  candidateUrl: unknown,
  brand: string,
  sourceHost?: string
): Promise<string | undefined> {
  if (typeof candidateUrl !== 'string') return undefined;
  const safe = isSafeExternalUrl(candidateUrl);
  if (!safe) return undefined;

  const candHost = safe.hostname.toLowerCase().replace(/^www\./, '');
  const isGroundingRedirect = candHost === 'vertexaisearch.cloud.google.com';
  if (!isGroundingRedirect) {
    if (sourceHost && candHost === sourceHost.toLowerCase().replace(/^www\./, '')) {
      return undefined;
    }
    if (isRetailerOrNoiseHost(candHost)) return undefined;
    if (!isManufacturerHost(candHost, brand)) return undefined;
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const res = await fetch(safe.href, {
      method: 'GET',
      redirect: 'follow',
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,*/*;q=0.8',
        'Accept-Language': 'it-IT,it;q=0.9,en;q=0.8',
      },
    });
    const finalParsed = isSafeExternalUrl(res.url || safe.href);
    if (!finalParsed) return undefined;
    const finalHost = finalParsed.hostname.toLowerCase().replace(/^www\./, '');
    if (sourceHost && finalHost === sourceHost.toLowerCase().replace(/^www\./, '')) {
      return undefined;
    }
    if (isRetailerOrNoiseHost(finalHost) || !isManufacturerHost(finalHost, brand)) {
      return undefined;
    }

    if (res.ok) {
      const snippet = (await res.text()).slice(0, 12000).toLowerCase();
      if (
        /<title[^>]*>\s*(?:404|pagina non trovata|page not found|not found)/i.test(snippet)
      ) {
        return undefined;
      }
      return finalParsed.href;
    }

    // Some manufacturer WAFs return 403 to server fetches; allow only if hostname is verified (not redirect wrapper)
    if (res.status === 403 && !isGroundingRedirect) {
      return finalParsed.href;
    }
    return undefined;
  } catch {
    return undefined;
  } finally {
    clearTimeout(timeout);
  }
}

function buildManufacturerContextText(params: {
  name: string;
  sourceUrl?: string;
  specs?: ProductSpec[];
}): string {
  const parts: string[] = [params.name];
  if (params.sourceUrl) {
    try {
      const u = new URL(params.sourceUrl);
      parts.push(decodeURIComponent(u.pathname).replace(/[/_-]+/g, ' '));
    } catch {
      // ignore invalid URL
    }
  }
  if (Array.isArray(params.specs)) {
    for (const s of params.specs) {
      if (s?.label && s?.value && !/sito ufficiale/i.test(s.label)) {
        parts.push(`${s.label} ${s.value}`);
      }
    }
  }
  return parts.join(' ').toLowerCase();
}

function extractAppleSearchQuery(name: string, contextText: string): string {
  const cleaned = name
    .replace(/\bapple\b/gi, ' ')
    .replace(/\b(?:ricondizionato|renewed|usato|certified refurbished|processore)\b/gi, ' ')
    .replace(/\b\d+\s*(?:gb|tb)\b/gi, ' ')
    .replace(/\([^)]*\)/g, ' ')
    .replace(/[,;|]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const familyPatterns: Array<[RegExp, string]> = [
    [/\bmacbook\s+pro\b/i, 'MacBook Pro'],
    [/\bmacbook\s+air\b/i, 'MacBook Air'],
    [/\bmacbook\b/i, 'MacBook'],
    [/\bmac\s+mini\b/i, 'Mac mini'],
    [/\bmac\s+studio\b/i, 'Mac Studio'],
    [/\bmac\s+pro\b/i, 'Mac Pro'],
    [/\bimac\b/i, 'iMac'],
    [/\bipad\s+pro\b/i, 'iPad Pro'],
    [/\bipad\s+air\b/i, 'iPad Air'],
    [/\bipad\s+mini\b/i, 'iPad mini'],
    [/\bipad\b/i, 'iPad'],
    [/\bairpods\s+pro\b/i, 'AirPods Pro'],
    [/\bairpods\s+max\b/i, 'AirPods Max'],
    [/\bairpods\b/i, 'AirPods'],
    [/\bapple\s+watch\s+ultra\b/i, 'Apple Watch Ultra'],
    [/\bapple\s+watch\s+se\b/i, 'Apple Watch SE'],
    [/\bapple\s+watch\b/i, 'Apple Watch'],
    [/\bhomepod\s+mini\b/i, 'HomePod mini'],
    [/\bhomepod\b/i, 'HomePod'],
    [/\bapple\s+tv\b/i, 'Apple TV'],
    [/\biphone\b/i, 'iPhone'],
  ];

  let family = '';
  for (const [re, label] of familyPatterns) {
    if (re.test(cleaned) || re.test(contextText)) {
      family = label;
      break;
    }
  }
  if (!family) return cleaned;

  const extraTokens: string[] = [];
  if (family === 'iPhone') {
    const genMatch = contextText.match(/\biphone\s*(\d{1,2}e?)\b/i);
    if (genMatch) extraTokens.push(genMatch[1]);
    if (/\bpro\s+max\b/i.test(contextText)) extraTokens.push('Pro Max');
    else if (/\bpro\b/i.test(contextText)) extraTokens.push('Pro');
    else if (/\bplus\b/i.test(contextText)) extraTokens.push('Plus');
    else if (/\bair\b/i.test(contextText)) extraTokens.push('Air');
    else if (/\bmini\b/i.test(contextText)) extraTokens.push('mini');
  } else {
    const yearMatch = contextText.match(/\b(201\d|202\d)\b/);
    if (yearMatch) {
      extraTokens.push(yearMatch[1]);
    } else {
      const genNum = cleaned.match(/\b(\d{1,2})\b/);
      if (genNum) extraTokens.push(genNum[1]);
    }
    const chipMatch = contextText.match(/\bm[1-9]\s*(?:pro|max|ultra)?\b/i);
    if (chipMatch && extraTokens.length === 0) {
      extraTokens.push(chipMatch[0].replace(/\s+/g, ' ').trim());
    }
  }

  return [family, ...extraTokens].join(' ').trim();
}

async function fetchAppleSearchLinks(url: string): Promise<Array<{ href: string; text: string }>> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 4500);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,*/*;q=0.8',
        'Accept-Language': 'it-IT,it;q=0.9,en;q=0.8',
      },
    });
    if (!res.ok) return [];
    const html = await res.text();
    const out: Array<{ href: string; text: string }> = [];
    const seen = new Map<string, number>();

    for (const m of html.matchAll(/<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)) {
      let href = m[1].trim();
      if (href.startsWith('/')) href = `https://www.apple.com${href}`;
      if (!/^https:\/\/(?:www|support)\.apple\.com\//i.test(href)) continue;

      const text = decodeHtmlEntities(m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
      if (
        /^https:\/\/www\.apple\.com\/it\/(?:|store|mac|ipad|iphone|watch|airpods|home|services|support)\/?$/i.test(
          href
        ) ||
        /\/(?:search|switch|compare|accessories|shop\/bag)\b/i.test(href)
      ) {
        continue;
      }

      const cleanUrl = href.split('#')[0].split('?')[0];
      if (!seen.has(cleanUrl)) {
        seen.set(cleanUrl, out.length);
        out.push({ href: cleanUrl, text });
      } else {
        const idx = seen.get(cleanUrl)!;
        if (text && text !== cleanUrl && (out[idx].text === cleanUrl || text.length > out[idx].text.length)) {
          out[idx].text = text;
        }
      }
    }
    return out;
  } catch {
    return [];
  } finally {
    clearTimeout(timeout);
  }
}

async function findAppleOfficialUrl(params: {
  name: string;
  brand: string;
  sourceUrl?: string;
  specs?: ProductSpec[];
}): Promise<string | undefined> {
  const contextText = buildManufacturerContextText(params);
  const query = extractAppleSearchQuery(params.name, contextText);
  if (!query) return undefined;

  const slug = query.replace(/\s+/g, '-');
  const urlsToFetch = [
    `https://www.apple.com/it/search/${encodeURIComponent(slug)}`,
    `https://www.apple.com/it/search/${encodeURIComponent(slug)}?tab=support`,
  ];

  const linkBatches = await Promise.all(urlsToFetch.map((u) => fetchAppleSearchLinks(u)));
  const combined = new Map<string, { href: string; text: string }>();
  for (const batch of linkBatches) {
    for (const item of batch) {
      const existing = combined.get(item.href);
      if (!existing || (item.text !== item.href && existing.text === existing.href)) {
        combined.set(item.href, item);
      }
    }
  }

  const desiredYear = contextText.match(/\b(201\d|202\d)\b/)?.[1];
  const desiredInches = contextText.match(/\b(1[1-6])(?:[,.]\d)?[\s-]*(?:pollici|inch|"|'')\b/i)?.[1];
  const desiredIphoneGen = contextText.match(/\biphone\s*(\d{1,2}e?)\b/i)?.[1]?.toLowerCase();
  const wantsProMax = /\bpro\s+max\b/i.test(contextText);
  const wantsPro = !wantsProMax && /\bpro\b/i.test(contextText);
  const wantsAir = /\bair\b/i.test(contextText);
  const wantsMini = /\bmini\b/i.test(contextText);
  const wantsUltra = /\bultra\b/i.test(contextText);
  const wantsMacBook = /\bmacbook\b/i.test(contextText);
  const wantsIPhone = /\biphone\b/i.test(contextText);
  const wantsIPad = /\bipad\b/i.test(contextText);
  const wantsAirPods = /\bairpods\b/i.test(contextText);
  const wantsWatch = /\bwatch\b/i.test(contextText);

  const scored = Array.from(combined.values())
    .map((cand) => {
      const urlLower = cand.href.toLowerCase();
      const textLower = cand.text.toLowerCase();
      const hay = `${urlLower} ${textLower}`;
      let score = 0;

      const isSupportSpec =
        /^https:\/\/support\.apple\.com\/it-it\/\d+/.test(urlLower) &&
        /specifiche tecniche|tech specs/.test(textLower);
      const isProductPage =
        /^https:\/\/www\.apple\.com\/it\/(?:iphone|macbook|mac|ipad|airpods|apple-watch|watch|homepod|apple-tv|studio-display)[^/]*(?:\/specs)?\/?$/.test(
          urlLower
        );
      const isShopBuyPage = /^https:\/\/www\.apple\.com\/it\/shop\/buy-/.test(urlLower);

      if (/manuale di riparazione|repair manual|preparare|ricaricare|identificare|collegati/.test(textLower)) {
        score -= 250;
      }

      if (isProductPage) score += 80;
      else if (isSupportSpec) score += 75;
      else if (isShopBuyPage) score += 45;
      else if (/^https:\/\/support\.apple\.com\/it-it\/\d+/.test(urlLower)) score += 10;
      else score -= 40;

      // Family checks
      if (wantsMacBook) {
        if (hay.includes('macbook')) score += 40;
        else score -= 120;
      }
      if (wantsIPhone) {
        if (hay.includes('iphone')) score += 40;
        else score -= 120;
      }
      if (wantsIPad) {
        if (hay.includes('ipad')) score += 40;
        else score -= 120;
      }
      if (wantsAirPods) {
        if (hay.includes('airpods')) score += 40;
        else score -= 120;
      }
      if (wantsWatch) {
        if (hay.includes('watch')) score += 40;
        else score -= 120;
      }

      // Sub-tier alignment
      if (wantsProMax) {
        if (/pro[- ]max/.test(hay)) score += 70;
        else if (isProductPage && /iphone-\d{2}-pro\/?$/.test(urlLower)) score += 50; // Apple groups Pro & Pro Max on /iphone-XX-pro/
        else score -= 80;
      } else if (wantsPro) {
        if (/\bpro\b/.test(hay) && !/pro[- ]max/.test(hay)) score += 60;
        else if (/\bpro\b/.test(hay)) score += 30;
        else score -= 70;
      } else {
        if (/pro/.test(hay) && !/\bpro\b/.test(contextText)) score -= 40;
      }

      if (wantsAir) {
        if (/\bair\b/.test(hay)) score += 50;
        else score -= 70;
      }
      if (wantsMini) {
        if (/\bmini\b/.test(hay)) score += 50;
        else score -= 60;
      }
      if (wantsUltra) {
        if (/\bultra\b/.test(hay)) score += 50;
        else score -= 70;
      }

      // iPhone generation check
      if (desiredIphoneGen) {
        const genRe = new RegExp(`\\biphone[- ]?${desiredIphoneGen}\\b`, 'i');
        if (genRe.test(hay)) score += 75;
        else score -= 110;
      }

      // Year check (crucial for historical MacBooks / iPads / Watches)
      if (desiredYear) {
        if (textLower.includes(desiredYear)) {
          score += isSupportSpec ? 95 : 70;
        } else if (/\b20[12]\d\b/.test(textLower)) {
          score -= 85;
        } else if (isProductPage && parseInt(desiredYear, 10) <= new Date().getFullYear() - 2) {
          // Generic current-year flagship page shouldn't beat exact older support specs
          score -= 40;
        }
      }

      // Screen size check (16 pollici vs 14 pollici)
      if (desiredInches) {
        const inchRe = new RegExp(`\\b${desiredInches}\\s*(?:pollici|inch)`, 'i');
        const otherInchMatch = textLower.match(/\b(1[1-6])\s*(?:pollici|inch)/i);
        if (inchRe.test(textLower)) score += 90;
        else if (otherInchMatch && otherInchMatch[1] !== desiredInches) score -= 90;
      }

      // Mild preference for clean product page without /specs/ suffix if tied
      if (isProductPage && !urlLower.endsWith('/specs/')) score += 10;

      return { ...cand, score };
    })
    .filter((c) => c.score > 40)
    .sort((a, b) => b.score - a.score);

  for (const cand of scored.slice(0, 4)) {
    const verified = await verifyManufacturerUrl(cand.href, 'Apple', params.sourceUrl ? (() => {
      try { return new URL(params.sourceUrl).hostname; } catch { return undefined; }
    })() : undefined);
    if (verified) return verified;
  }

  return undefined;
}

async function findManufacturerUrl(params: {
  name: string;
  brand: string;
  category?: string;
  sku?: string;
  sourceUrl?: string;
  specs?: ProductSpec[];
}): Promise<string | undefined> {
  const brand = params.brand.trim();
  const name = params.name.trim();
  if (!brand || !name || GENERIC_NON_BRANDS.has(brand.toLowerCase())) {
    return undefined;
  }

  const parsedSource = params.sourceUrl ? isSafeExternalUrl(params.sourceUrl) : null;
  const sourceHost = parsedSource?.hostname;
  if (sourceHost && isManufacturerHost(sourceHost, brand)) {
    return undefined;
  }

  // 1. Direct Apple search resolver (works reliably with zero external API keys)
  if (
    /\bapple\b/i.test(brand) ||
    /\b(?:iphone|macbook|imac|mac mini|mac studio|mac pro|ipad|airpods|apple watch|homepod|apple tv)\b/i.test(name)
  ) {
    const appleUrl = await findAppleOfficialUrl({
      name,
      brand,
      sourceUrl: params.sourceUrl,
      specs: params.specs,
    });
    if (appleUrl) return appleUrl;
  }

  // 2. Gemini Google Search grounding (when GEMINI_API_KEY is configured)
  if (!process.env.GEMINI_API_KEY?.trim()) {
    return undefined;
  }

  try {
    const ai = getAiClient();
    const cleanedTitleForQuery = name
      .replace(/\b(?:ricondizionato|renewed|usato|certified refurbished)\b/gi, '')
      .replace(/\s+/g, ' ')
      .trim();

    const prompt = `Trova la pagina prodotto ufficiale (o la scheda specifiche ufficiali se fuori produzione) sul sito ufficiale del produttore "${brand}" per questo articolo:
Prodotto: ${cleanedTitleForQuery}
Marca produttore: ${brand}
${params.category ? `Categoria: ${params.category}` : ''}

Regole:
- Restituisci SOLO la URL del sito ufficiale del produttore (es. apple.com/it/..., support.apple.com/..., samsung.com/it/..., dyson.it/..., sony.it/...).
- NON restituire link a negozi terzi (Amazon, MediaWorld, Unieuro, eBay) né Wikipedia o recensioni.
- Preferisci la versione italiana (/it/) se disponibile, altrimenti quella internazionale ufficiale.
- Se non trovi una pagina ufficiale pertinente sul sito di "${brand}", restituisci "url": "".

Rispondi SOLO in JSON valido:
{
  "url": "https://..."
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      },
    });

    const candidates: string[] = [];
    const parsedJson = extractJsonObject(response.text ?? '');
    if (typeof parsedJson?.url === 'string' && parsedJson.url.trim()) {
      candidates.push(parsedJson.url.trim());
    }

    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (Array.isArray(chunks)) {
      for (const ch of chunks) {
        const uri = ch?.web?.uri;
        if (typeof uri === 'string' && uri.trim() && !candidates.includes(uri.trim())) {
          candidates.push(uri.trim());
        }
      }
    }

    for (const cand of candidates.slice(0, 5)) {
      const verified = await verifyManufacturerUrl(cand, brand, sourceHost);
      if (verified) return verified;
    }
    return undefined;
  } catch (err) {
    console.warn('[manufacturer-url] Lookup failed:', err instanceof Error ? err.message : err);
    return undefined;
  }
}

async function attachManufacturerUrl(
  product: NormalizedProduct,
  sourceHost?: string
): Promise<NormalizedProduct> {
  if (product.officialUrl) return product;
  const officialUrl = await findManufacturerUrl({
    name: product.name,
    brand: product.brand,
    category: product.category,
    sku: product.sku,
    sourceUrl: product.sourceUrl,
    specs: product.specs,
  });
  if (!officialUrl) return product;
  if (sourceHost && isManufacturerHost(sourceHost, product.brand)) return product;

  product.officialUrl = officialUrl;
  if (!product.specs.some((s) => s.label.toLowerCase() === 'sito ufficiale produttore')) {
    product.specs.push({ label: 'Sito ufficiale produttore', value: officialUrl });
  }
  return product;
}

function extractJsonObject(rawText: string): Record<string, unknown> | null {
  const cleaned = rawText
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();

  try {
    const parsed = JSON.parse(cleaned);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>;
    }
  } catch {
    // Try extracting first {...} block
  }

  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start !== -1 && end > start) {
    try {
      const parsed = JSON.parse(cleaned.slice(start, end + 1));
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        return parsed as Record<string, unknown>;
      }
    } catch {
      return null;
    }
  }
  return null;
}

async function enrichBlockedUrlWithSearch(
  parsedUrl: URL,
  baseProduct: NormalizedProduct
): Promise<NormalizedProduct | null> {
  try {
    const ai = getAiClient();
    const prompt = `Cerca su Google informazioni reali su questo prodotto specifico in vendita online:
URL: ${parsedUrl.href}
Marca probabile: ${baseProduct.brand}
Titolo ricavato dal link: ${baseProduct.name}
Codice / SKU probabile: ${baseProduct.sku}

Restituisci ESCLUSIVAMENTE un oggetto JSON valido (senza testo aggiuntivo) con i dati reali trovati in italiano:
{
  "name": "nome esatto completo del prodotto",
  "brand": "marca ufficiale",
  "category": "una categoria tra: Arredamento, Casa & Gaming, Elettrodomestici, Smartphone, Tablet, Computer, Audio, Wearable, Fotografia, Strumenti Musicali, Sport & Tempo Libero, Fai da te, Domotica & Rete",
  "price": numero prezzo attuale in Euro (es. 29.99, usa 0 solo se introvabile),
  "originalPrice": numero opzionale se scontato oppure null,
  "sku": "codice prodotto / referenza reale",
  "colorName": "colore reale solo se l'articolo ha un colore esplicito, altrimenti stringa vuota \"\" (NON inserire materiali come vetro o parole generiche come Originale)",
  "colorHex": "codice esadecimale reale se colorName è valorizzato, altrimenti stringa vuota \"\"",
  "material": "materiale principale",
  "dimensions": "dimensioni reali (es. Altezza 30 cm × Larghezza 18 cm)",
  "shortSummary": "descrizione dettagliata in italiano di 2-3 frasi basata sulle caratteristiche reali",
  "highlights": ["punto chiave 1", "punto chiave 2", "punto chiave 3"],
  "specs": [{"label": "nome specifica", "value": "valore"}],
  "boxContents": ["contenuto confezione"],
  "imageUrl": "URL diretto https:// ad un'immagine reale del prodotto trovata nei risultati, oppure stringa vuota se non disponibile",
  "officialUrl": "URL della pagina ufficiale sul sito del produttore (se diverso dal negozio di origine, es. apple.com, samsung.com), altrimenti stringa vuota \"\""
}`;

    const attemptModels = ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'];
    let responseText = '';

    for (let i = 0; i < attemptModels.length; i++) {
      try {
        const modelName = attemptModels[i];
        const res = await ai.models.generateContent({
          model: modelName,
          contents: prompt,
          config: {
            tools: [{ googleSearch: {} }],
            ...(modelName === 'gemini-4-hydrogen'
              ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
              : {}),
          },
        });
        responseText = res.text ?? '';
        if (responseText.trim()) break;
      } catch (err) {
        if (i === attemptModels.length - 1) throw err;
      }
    }

    const parsed = extractJsonObject(responseText);
    if (!parsed) return null;

    const verifiedImg = await verifyImageUrl(parsed.imageUrl);
    const name = typeof parsed.name === 'string' && parsed.name.trim() ? parsed.name.trim() : baseProduct.name;
    const rawParsedBrand = typeof parsed.brand === 'string' && parsed.brand.trim() ? parsed.brand.trim() : '';
    const brand =
      (rawParsedBrand && rawParsedBrand.toLowerCase() !== 'amazon' ? rawParsedBrand : undefined) ||
      inferManufacturerFromText(name) ||
      rawParsedBrand ||
      baseProduct.brand;
    const { category, visualKind } = inferCategoryAndVisual(
      typeof parsed.category === 'string' ? parsed.category : '',
      name
    );

    const rawPrice = Number(parsed.price);
    const price = Number.isFinite(rawPrice) && rawPrice > 0 ? Number(rawPrice.toFixed(2)) : 0;
    const rawOrig = Number(parsed.originalPrice);
    const originalPrice =
      price > 0 && Number.isFinite(rawOrig) && rawOrig > price
        ? Number(rawOrig.toFixed(2))
        : undefined;

    const sku =
      typeof parsed.sku === 'string' && parsed.sku.trim() ? parsed.sku.trim() : baseProduct.sku;
    const colorName = cleanOptionalColorName(parsed.colorName);
    const aiColorHex =
      colorName &&
      typeof parsed.colorHex === 'string' &&
      /^#[0-9a-fA-F]{6}$/.test(parsed.colorHex.trim())
        ? parsed.colorHex.trim().toUpperCase()
        : '';
    const dictColorHex = colorName ? inferColorHex(colorName) : '';
    const colorHex = colorName
      ? dictColorHex !== '#2B2C30'
        ? dictColorHex
        : aiColorHex || dictColorHex
      : '';
    const detectedSize = name.match(/\b(\d+\s*(?:GB|TB))\b/i)?.[1] || 'Modello da link';
    const shortSummary =
      typeof parsed.shortSummary === 'string' && parsed.shortSummary.trim()
        ? parsed.shortSummary.trim()
        : baseProduct.shortSummary;

    const specs: Array<{ label: string; value: string }> = [
      { label: 'Marca', value: brand },
      { label: 'Codice / SKU', value: sku },
    ];
    if (typeof parsed.material === 'string' && parsed.material.trim()) {
      specs.push({ label: 'Materiale', value: parsed.material.trim() });
    }
    if (typeof parsed.dimensions === 'string' && parsed.dimensions.trim()) {
      specs.push({ label: 'Dimensioni', value: parsed.dimensions.trim() });
    }
    if (colorName) {
      specs.push({ label: 'Colore / Finitura', value: colorName });
    }
    if (Array.isArray(parsed.specs)) {
      for (const s of parsed.specs) {
        if (s && typeof s === 'object' && 'label' in s && 'value' in s) {
          const lbl = String((s as Record<string, unknown>).label || '').trim();
          const val = String((s as Record<string, unknown>).value || '').trim();
          if (lbl && val && !specs.some((existing) => existing.label.toLowerCase() === lbl.toLowerCase())) {
            specs.push({ label: lbl, value: val });
          }
        }
      }
    }
    specs.push({ label: 'Link sorgente', value: parsedUrl.hostname.replace(/^www\./, '') });
    specs.push({ label: 'Collegamento originale', value: parsedUrl.href });

    const highlights = Array.isArray(parsed.highlights)
      ? parsed.highlights.map(String).filter(Boolean).slice(0, 5)
      : baseProduct.highlights;

    const boxContents = Array.isArray(parsed.boxContents)
      ? parsed.boxContents.map(String).filter(Boolean)
      : [name];

    const finalEnrichedName = stripDuplicateColorFromTitle(name, colorName);
    const verifiedOfficialUrl =
      (await verifyManufacturerUrl(parsed.officialUrl, brand, parsedUrl.hostname)) ||
      (await findManufacturerUrl({
        name: finalEnrichedName,
        brand,
        category,
        sku,
        sourceUrl: parsedUrl.href,
        specs,
      }));
    if (verifiedOfficialUrl) {
      specs.push({ label: 'Sito ufficiale produttore', value: verifiedOfficialUrl });
    }

    return {
      ...baseProduct,
      id: stableUrlId(sku, parsedUrl),
      sku,
      name: finalEnrichedName,
      brand,
      category:
        typeof parsed.category === 'string' && parsed.category.trim()
          ? parsed.category.trim()
          : category,
      price,
      originalPrice,
      imageUrl: verifiedImg,
      sourceUrl: parsedUrl.href,
      ...(verifiedOfficialUrl ? { officialUrl: verifiedOfficialUrl } : {}),
      visualKind,
      shortSummary,
      highlights: highlights.length > 0 ? highlights : baseProduct.highlights,
      specs,
      boxContents: boxContents.length > 0 ? boxContents : [name],
      variants: [
        {
          id: 'imported',
          label: detectedSize,
          colorName,
          colorHex,
          priceDelta: 0,
        },
      ],
      keywords: [brand.toLowerCase(), name.toLowerCase(), sku.toLowerCase()],
    };
  } catch (err) {
    console.warn('[import-url] Search enrichment failed:', err instanceof Error ? err.message : err);
    return null;
  }
}

function parseEuroPriceText(raw: string): number {
  const cleaned = raw.replace(/\s+/g, '').replace(/[^0-9.,]/g, '');
  if (!cleaned) return 0;
  // Italian format e.g. 1.849,00 or 149,99
  if (cleaned.includes(',')) {
    const normalized = cleaned.replace(/\./g, '').replace(',', '.');
    const num = Number(normalized);
    return Number.isFinite(num) ? num : 0;
  }
  const num = Number(cleaned);
  return Number.isFinite(num) ? num : 0;
}

function extractAmazonAsin(parsedUrl: URL, html?: string): string | undefined {
  const fromPath = parsedUrl.pathname.match(/\/(?:dp|gp\/(?:product|aw\/d))\/([A-Z0-9]{10})/i)?.[1];
  if (fromPath) return fromPath.toUpperCase();
  if (html) {
    const fromHtml = html.match(/data-asin=["']([A-Z0-9]{10})["']/i)?.[1];
    if (fromHtml) return fromHtml.toUpperCase();
  }
  return undefined;
}

function isAmazonChallengeHtml(html: string, parsedUrl: URL): boolean {
  if (!parsedUrl.hostname.toLowerCase().includes('amazon.')) return false;
  const hasProductMarkup =
    /id=["'](?:productTitle|title)["']/i.test(html) &&
    /id=["'](?:landingImage|main-image|corePriceDisplay_desktop_feature_div|corePriceDisplay_mobile_feature_div|bylineInfo)["']/i.test(html);
  if (hasProductMarkup) return false;
  if (html.length < 25000) return true;
  if (/validateCaptcha|opfcaptcha|<title[^>]*>\s*(?:Amazon\.[a-z.]+|Ci dispiace|Sorry)/i.test(html)) {
    return true;
  }
  return false;
}

function parseAmazonProductHtml(html: string, parsedUrl: URL): NormalizedProduct | null {
  if (!parsedUrl.hostname.toLowerCase().includes('amazon.')) return null;
  if (isAmazonChallengeHtml(html, parsedUrl)) return null;

  const desktopTitleMatch = html.match(/id=["']productTitle["'][^>]*>([\s\S]*?)<\/span>/i);
  const mobileTitleRaw = html.match(/<h1[^>]*id=["']title["'][^>]*>([\s\S]*?)<\/h1>/i)?.[1];
  const mobileTitleClean = mobileTitleRaw
    ? decodeHtmlEntities(mobileTitleRaw.replace(/<input[\s\S]*$/i, '').replace(/<[^>]+>/g, ' '))
    : '';
  const htmlTitleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const rawPageTitle = htmlTitleMatch?.[1]
    ? decodeHtmlEntities(htmlTitleMatch[1]).replace(/\s*:\s*Amazon\.[a-z.]+.*$/i, '').trim()
    : '';
  const rawTitle =
    (desktopTitleMatch?.[1] ? decodeHtmlEntities(desktopTitleMatch[1]) : '') ||
    mobileTitleClean ||
    rawPageTitle;

  if (
    !rawTitle ||
    /^(?:amazon\.[a-z.]+|ci dispiace|sorry)$/i.test(rawTitle) ||
    /captcha|robot check/i.test(rawTitle)
  ) {
    return null;
  }

  const asin =
    extractAmazonAsin(parsedUrl, html) ||
    `AMZ-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

  // Extract overview table specs (#productOverview_feature_div)
  const overviewMap = new Map<string, string>();
  const overviewBlock = html.match(/id=["']productOverview_feature_div["'][\s\S]{0,12000}/i)?.[0] || '';
  const rowMatches = overviewBlock.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi);
  for (const row of rowMatches) {
    const cells = Array.from(row[1].matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)).map((c) =>
      decodeHtmlEntities(c[1].replace(/<[^>]+>/g, ' '))
    );
    if (cells.length >= 2 && cells[0] && cells[1]) {
      overviewMap.set(cells[0], cells[1]);
    }
  }

  // Brand resolution: Overview "Marchio" -> #bylineInfo -> inferred from title
  const overviewBrand = overviewMap.get('Marchio') || overviewMap.get('Marca') || overviewMap.get('Brand');
  const bylineRaw = html.match(/id=["']bylineInfo["'][^>]*>([\s\S]*?)<\/a>/i)?.[1];
  const bylineClean = bylineRaw
    ? decodeHtmlEntities(bylineRaw)
        .replace(/^Visita lo Store di\s+/i, '')
        .replace(/^Visit the\s+/i, '')
        .replace(/\s+Store$/i, '')
        .replace(/^Marca:\s*/i, '')
        .replace(/^Brand:\s*/i, '')
        .trim()
    : '';

  const isGenericAmazonByline = /^amazon(?:\s+renewed)?$/i.test(bylineClean);
  const brand =
    overviewBrand ||
    (!isGenericAmazonByline && bylineClean ? bylineClean : undefined) ||
    inferManufacturerFromText(rawTitle) ||
    bylineClean ||
    'Amazon';

  // Breadcrumbs for category inference
  const breadcrumbBlock =
    html.match(/id=["']wayfinding-breadcrumbs_feature_div["'][\s\S]{0,3000}/i)?.[0] || '';
  const breadcrumbText = decodeHtmlEntities(breadcrumbBlock.replace(/<[^>]+>/g, ' '));
  const overviewJoined = Array.from(overviewMap.entries())
    .map(([k, v]) => `${k} ${v}`)
    .join(' ');
  const { category, visualKind } = inferCategoryAndVisual(
    `${breadcrumbText} ${overviewJoined}`,
    rawTitle
  );

  // Price extraction (desktop OR mobile feature divs)
  const priceBlock =
    html.match(/id=["']corePriceDisplay_desktop_feature_div["'][\s\S]{0,6000}/i)?.[0] ||
    html.match(/id=["']corePriceDisplay_mobile_feature_div["'][\s\S]{0,6000}/i)?.[0] ||
    html.match(/id=["']corePrice_feature_div["'][\s\S]{0,6000}/i)?.[0] ||
    '';

  let priceNum = 0;
  const wholeMatch = priceBlock.match(/class=["']a-price-whole["'][^>]*>([^<]+)/i);
  const fracMatch = priceBlock.match(/class=["']a-price-fraction["'][^>]*>([^<]+)/i);
  if (wholeMatch?.[1]) {
    const combined = `${wholeMatch[1].replace(/[^0-9.]/g, '')},${fracMatch?.[1]?.replace(/[^0-9]/g, '') || '00'}`;
    priceNum = parseEuroPriceText(combined);
  }
  if (!priceNum) {
    const offscreenMatches = Array.from(
      priceBlock.matchAll(/class=["'][^"']*(?:a-offscreen|aok-offscreen)[^"']*["'][^>]*>([\s\S]*?)<\/span>/gi)
    );
    for (const m of offscreenMatches) {
      const candidate = parseEuroPriceText(decodeHtmlEntities(m[1]));
      if (candidate > 0) {
        priceNum = candidate;
        break;
      }
    }
  }

  let originalPrice: number | undefined;
  const basisMatch = priceBlock.match(
    /basisPrice[\s\S]{0,400}?class=["']a-offscreen["'][^>]*>([^<]+)</i
  );
  if (basisMatch?.[1]) {
    const parsedBasis = parseEuroPriceText(decodeHtmlEntities(basisMatch[1]));
    if (parsedBasis > priceNum && priceNum > 0) {
      originalPrice = parsedBasis;
    }
  }

  // Image extraction (hi-res desktop landingImage OR mobile main-image)
  const landingHiRes = html.match(/id=["']landingImage["'][^>]*data-old-hires=["']([^"']+)["']/i)?.[1];
  const anyOldHiRes = html.match(/data-old-hires=["'](https:\/\/m\.media-amazon\.com\/images\/I\/[^"']+)["']/i)?.[1];
  const mobileMainHiRes = html.match(/id=["']main-image["'][^>]*data-a-hires=["']([^"']+)["']/i)?.[1];
  const anyDataAHires = html.match(/data-a-hires=["'](https:\/\/m\.media-amazon\.com\/images\/I\/[^"']+)["']/i)?.[1];
  const jsonHiRes = html.match(/"hiRes"\s*:\s*"(https:\/\/m\.media-amazon\.com\/images\/I\/[^"]+)"/i)?.[1];
  const landingSrc = html.match(/id=["'](?:landingImage|main-image)["'][^>]*src=["'](https:\/\/[^"']+)["']/i)?.[1];
  const imageUrl =
    landingHiRes || anyOldHiRes || mobileMainHiRes || anyDataAHires || jsonHiRes || landingSrc;

  // Color & Size extraction (twister dimensions + tech spec tables + variationValues JSON + explicit title color)
  const twisterColor = html.match(
    /id=["']inline-twister-expanded-dimension-text-color_name["'][^>]*>([^<]+)</i
  )?.[1];
  const tableColorMatch = html.match(
    /<th[^>]*>\s*(?:Colore|Color)\s*<\/th>\s*<td[^>]*>([\s\S]*?)<\/td>/i
  )?.[1];
  const tableColorClean = tableColorMatch
    ? decodeHtmlEntities(tableColorMatch.replace(/<[^>]+>/g, ' '))
    : '';
  const selectedColorName = decodeHtmlEntities(
    twisterColor ||
      overviewMap.get('Colore') ||
      overviewMap.get('Color') ||
      tableColorClean ||
      ''
  );

  const twisterSize = html.match(
    /id=["']inline-twister-expanded-dimension-text-size_name["'][^>]*>([^<]+)</i
  )?.[1];
  const titleSizeMatch = rawTitle.match(/\b(\d+\s*(?:GB|TB))\b/i)?.[1];
  const selectedSizeName = decodeHtmlEntities(
    twisterSize ||
      overviewMap.get('Capacità della memoria') ||
      overviewMap.get('Dimensioni') ||
      titleSizeMatch ||
      ''
  );

  let colorOptions: Array<{ id: string; name: string; hex: string }> | undefined;
  let variantLinks: Array<{ size?: string; color?: string; sku: string; url: string }> = [];
  let variantList: Array<{
    id: string;
    label: string;
    colorName: string;
    colorHex: string;
    priceDelta: number;
    sourceUrl?: string;
    sku?: string;
  }> = [];

  // Parse Amazon mobile twister dimension maps for exact (color, size) -> ASIN URLs
  const dimKeysObj = parseAmazonAStateJson<{ key?: string[] }>(html, [
    'twister-plus-mobile-inline-twister-dim-list',
    'mobile-twister-dim-list',
  ]);
  const dimValsObj = parseAmazonAStateJson<Record<string, string[]>>(html, [
    'twister-plus-mobile-inline-twister-dim-val-list',
    'mobile-twister-dim-val-list',
  ]);
  const dimsToAsinObj = parseAmazonAStateJson<Record<string, string>>(html, [
    'twister-plus-mobile-inline-twister-dims-to-asin-list',
    'mobile-twister-dims-to-asin-list',
  ]);

  if (dimKeysObj?.key && dimValsObj && dimsToAsinObj) {
    const dimKeys = dimKeysObj.key;
    const sizeIdxInKeys = dimKeys.indexOf('size_name');
    const colorIdxInKeys = dimKeys.indexOf('color_name');
    for (const [coordKey, varAsin] of Object.entries(dimsToAsinObj)) {
      if (!varAsin || !/^[A-Z0-9]{10}$/i.test(varAsin)) continue;
      const parts = coordKey.split(':').map((p) => Number(p));
      const sizeVal =
        sizeIdxInKeys >= 0 && parts[sizeIdxInKeys] !== undefined
          ? dimValsObj.size_name?.[parts[sizeIdxInKeys]]
          : undefined;
      const colorVal =
        colorIdxInKeys >= 0 && parts[colorIdxInKeys] !== undefined
          ? dimValsObj.color_name?.[parts[colorIdxInKeys]]
          : undefined;
      variantLinks.push({
        ...(sizeVal ? { size: decodeHtmlEntities(String(sizeVal)) } : {}),
        ...(colorVal ? { color: decodeHtmlEntities(String(colorVal)) } : {}),
        sku: varAsin.toUpperCase(),
        url: `https://${parsedUrl.hostname}/dp/${varAsin.toUpperCase()}?th=1`,
      });
    }
  }

  const varValuesMatch = html.match(/"variationValues"\s*:\s*(\{[^}]*(?:\{[^}]*\}[^}]*)*\})/);
  let parsedVarColors: string[] | undefined;
  let parsedVarSizes: string[] | undefined;

  if (varValuesMatch?.[1]) {
    try {
      const parsedVars = JSON.parse(varValuesMatch[1]) as {
        color_name?: string[];
        size_name?: string[];
      };
      if (Array.isArray(parsedVars.color_name) && parsedVars.color_name.length > 0) {
        parsedVarColors = parsedVars.color_name;
      }
      if (Array.isArray(parsedVars.size_name) && parsedVars.size_name.length > 0) {
        parsedVarSizes = parsedVars.size_name;
      }
    } catch {
      // Ignore partial variation JSON
    }
  }

  if (!parsedVarColors && Array.isArray(dimValsObj?.color_name) && dimValsObj.color_name.length > 0) {
    parsedVarColors = dimValsObj.color_name;
  }
  if (!parsedVarSizes && Array.isArray(dimValsObj?.size_name) && dimValsObj.size_name.length > 0) {
    parsedVarSizes = dimValsObj.size_name;
  }

  // Also parse desktop Amazon dimensionValuesDisplayData ("ASIN": ["Color", "Size"])
  const dimDispMatch = html.match(/"dimensionValuesDisplayData"\s*:\s*(\{[^}]+\})/);
  if (dimDispMatch?.[1] && variantLinks.length === 0) {
    try {
      const dimDisp = JSON.parse(dimDispMatch[1]) as Record<string, string[]>;
      const colorSet = new Set(
        (parsedVarColors || []).map((c) => decodeHtmlEntities(String(c)).toLowerCase())
      );
      const sizeSet = new Set(
        (parsedVarSizes || []).map((s) => decodeHtmlEntities(String(s)).toLowerCase())
      );
      for (const [varAsin, vals] of Object.entries(dimDisp)) {
        if (!/^[A-Z0-9]{10}$/i.test(varAsin) || !Array.isArray(vals)) continue;
        let sizeVal: string | undefined;
        let colorVal: string | undefined;
        for (const v of vals) {
          const cleanV = decodeHtmlEntities(String(v));
          if (sizeSet.has(cleanV.toLowerCase())) sizeVal = cleanV;
          else if (colorSet.has(cleanV.toLowerCase())) colorVal = cleanV;
        }
        variantLinks.push({
          ...(sizeVal ? { size: sizeVal } : {}),
          ...(colorVal ? { color: colorVal } : {}),
          sku: varAsin.toUpperCase(),
          url: `https://${parsedUrl.hostname}/dp/${varAsin.toUpperCase()}?th=1`,
        });
      }
    } catch {
      // Ignore partial dimensionValuesDisplayData
    }
  }

  if (parsedVarColors && parsedVarColors.length > 0) {
    const orderedColors = parsedVarColors.map((c) => decodeHtmlEntities(String(c)));
    if (selectedColorName) {
      orderedColors.sort((a, b) =>
        a.toLowerCase() === selectedColorName.toLowerCase()
          ? -1
          : b.toLowerCase() === selectedColorName.toLowerCase()
          ? 1
          : 0
      );
    }
    colorOptions = orderedColors.map((name, i) => ({
      id: `amz-col-${i}`,
      name,
      hex: inferColorHex(name),
    }));
  }

  const finalColorName =
    cleanOptionalColorName(selectedColorName || colorOptions?.[0]?.name || '') ||
    extractExplicitColorFromText(rawTitle);
  const finalColorHex = finalColorName ? inferColorHex(finalColorName) : '';

  if (parsedVarSizes && parsedVarSizes.length > 0) {
    const orderedSizes = parsedVarSizes.map((s) => decodeHtmlEntities(String(s)));
    if (selectedSizeName) {
      orderedSizes.sort((a, b) =>
        a.toLowerCase() === selectedSizeName.toLowerCase()
          ? -1
          : b.toLowerCase() === selectedSizeName.toLowerCase()
          ? 1
          : 0
      );
    }
    variantList = orderedSizes.map((label, i) => {
      const matchedLink =
        variantLinks.find(
          (vl) =>
            isSameServerSize(vl.size, label) &&
            (!finalColorName || !vl.color || vl.color.toLowerCase() === finalColorName.toLowerCase())
        ) || variantLinks.find((vl) => isSameServerSize(vl.size, label));
      return {
        id: `amz-sz-${i}`,
        label,
        colorName: finalColorName,
        colorHex: finalColorHex,
        priceDelta: 0,
        ...(matchedLink ? { sourceUrl: matchedLink.url, sku: matchedLink.sku } : {}),
      };
    });
  }

  if (variantList.length === 0) {
    variantList = [
      {
        id: 'imported',
        label: selectedSizeName || 'Versione Amazon',
        colorName: finalColorName,
        colorHex: finalColorHex,
        priceDelta: 0,
        sourceUrl: parsedUrl.href,
        sku: asin,
      },
    ];
  }

  // Rating & Review count (desktop OR mobile)
  const ratingMatch =
    html.match(/id=["']acrPopover["'][^>]*title=["']([0-9.,]+)/i)?.[1] ||
    html.match(/([0-9],[0-9])\s*su\s*5\s*stelle/i)?.[1];
  const rating = ratingMatch
    ? Math.min(5, Math.max(1, Number(ratingMatch.replace(',', '.')) || 4.7))
    : 4.7;
  const revCntMatch =
    html.match(/id=["']acrCustomerReviewText["'][^>]*>\(?([0-9.]+)/i)?.[1] ||
    html.match(/([0-9.]+)\s*(?:voti|recensioni)/i)?.[1];
  const reviewCount = revCntMatch ? Math.max(1, Number(revCntMatch.replace(/\./g, '')) || 1) : 1;

  // Feature bullets (#feature-bullets) or title subtitle fallback
  const bulletsBlock = html.match(/id=["']feature-bullets["'][\s\S]{0,6000}/i)?.[0] || '';
  const bullets: string[] = [];
  for (const li of bulletsBlock.matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)) {
    const text = decodeHtmlEntities(li[1].replace(/<[^>]+>/g, ' '));
    if (
      text.length > 10 &&
      !/vedi altri dettagli prodotto/i.test(text) &&
      !bullets.includes(text)
    ) {
      bullets.push(text);
    }
    if (bullets.length >= 4) break;
  }

  // Split descriptive mobile/long Amazon titles cleanly into concise name + subtitle
  const shortModelName = overviewMap.get('Nome modello');
  const titleSplit = rawTitle.match(/^([^|:]{8,85}?)\s*[|:]\s*(.+)$/);
  if (bullets.length === 0 && titleSplit?.[2]) {
    bullets.push(titleSplit[2].trim());
  }

  const rawDisplayName =
    rawTitle.length > 85 && shortModelName
      ? `${brand !== shortModelName.split(' ')[0] ? `${brand} ` : ''}${shortModelName}${
          selectedSizeName && !shortModelName.includes(selectedSizeName) ? ` (${selectedSizeName})` : ''
        }`
      : titleSplit && rawTitle.length > 85
      ? titleSplit[1].trim()
      : rawTitle;
  const displayName = stripDuplicateColorFromTitle(rawDisplayName, finalColorName);

  const specs: Array<{ label: string; value: string }> = [
    { label: 'Marca', value: brand },
    { label: 'ASIN / Codice', value: asin },
  ];
  if (finalColorName) {
    specs.push({ label: 'Colore selezionato', value: finalColorName });
  }
  if (selectedSizeName) {
    specs.push({ label: 'Memoria / Taglia', value: selectedSizeName });
  }
  for (const [k, v] of overviewMap.entries()) {
    if (!specs.some((s) => s.label.toLowerCase() === k.toLowerCase())) {
      specs.push({ label: k, value: v });
    }
  }
  specs.push({ label: 'Link sorgente', value: parsedUrl.hostname.replace(/^www\./, '') });
  specs.push({ label: 'Collegamento originale', value: parsedUrl.href });

  const shortSummary = bullets[0] || rawTitle;

  return {
    id: stableUrlId(asin, parsedUrl),
    sku: asin,
    name: displayName,
    brand,
    category,
    searchPriority: 98,
    price: priceNum,
    originalPrice,
    rating,
    reviewCount,
    availability: 'Disponibilità verificata su Amazon',
    deliveryText: `Importato da ${parsedUrl.hostname.replace(/^www\./, '')}`,
    warranty: 'Garanzia legale 24 mesi Italia',
    imageUrl,
    sourceUrl: parsedUrl.href,
    visualKind,
    shortSummary,
    highlights:
      bullets.length > 0
        ? bullets
        : [rawTitle, `Codice ASIN: ${asin}`, `Importato da ${parsedUrl.hostname.replace(/^www\./, '')}`],
    specs,
    boxContents: [displayName, 'Documentazione originale'],
    ...(colorOptions && colorOptions.length > 0 ? { colorOptions } : {}),
    ...(variantLinks.length > 0 ? { variantLinks } : {}),
    variants: variantList,
    keywords: [brand.toLowerCase(), displayName.toLowerCase(), asin.toLowerCase(), ...(finalColorName ? [finalColorName.toLowerCase()] : [])],
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.get('/api/image-proxy', async (req, res) => {
    const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim() : '';
    const safe = isSafeExternalUrl(rawUrl);
    if (!safe) {
      res.status(400).json({ error: 'Invalid image URL' });
      return;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    try {
      const imgRes = await fetch(safe.href, {
        signal: controller.signal,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
          Accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
        },
      });
      if (!imgRes.ok) {
        res.status(502).end();
        return;
      }
      const contentType = imgRes.headers.get('content-type') || '';
      if (!contentType.toLowerCase().startsWith('image/')) {
        res.status(415).end();
        return;
      }
      const buf = Buffer.from(await imgRes.arrayBuffer());
      if (buf.length > 5 * 1024 * 1024) {
        res.status(413).end();
        return;
      }
      res.setHeader('Content-Type', contentType);
      res.setHeader('Cache-Control', 'public, max-age=3600');
      res.send(buf);
    } catch {
      res.status(502).end();
    } finally {
      clearTimeout(timeout);
    }
  });

  app.post('/api/catalog/import-url', async (req, res) => {
    const rawUrl = typeof req.body?.url === 'string' ? req.body.url.trim() : '';
    const parsedUrl = isSafeExternalUrl(rawUrl);

    if (!parsedUrl) {
      res.status(400).json({
        error: 'Inserisci un link valido che inizi con https:// o http://.',
      });
      return;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 14000);

    try {
      const isAmazonHost = parsedUrl.hostname.toLowerCase().includes('amazon.');
      const amazonAsin = isAmazonHost ? extractAmazonAsin(parsedUrl) : undefined;
      const mobileAmazonUrl = amazonAsin
        ? `https://${parsedUrl.hostname}/gp/aw/d/${amazonAsin}${parsedUrl.search || '?th=1'}`
        : undefined;

      const fetchTargets: Array<{ targetUrl: string; ua: string; pauseMs: number }> =
        isAmazonHost && mobileAmazonUrl
          ? [
              {
                targetUrl: parsedUrl.href,
                ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
                pauseMs: 0,
              },
              {
                targetUrl: mobileAmazonUrl,
                ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',
                pauseMs: 120,
              },
              {
                targetUrl: mobileAmazonUrl,
                ua: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
                pauseMs: 300,
              },
              {
                targetUrl: parsedUrl.href,
                ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36',
                pauseMs: 350,
              },
            ]
          : [
              {
                targetUrl: parsedUrl.href,
                ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
                pauseMs: 0,
              },
            ];

      let response: Response | null = null;
      let html = '';

      for (const step of fetchTargets) {
        if (step.pauseMs > 0) {
          await new Promise((r) => setTimeout(r, step.pauseMs));
        }
        response = await fetch(step.targetUrl, {
          signal: controller.signal,
          headers: {
            'User-Agent': step.ua,
            Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'it-IT,it;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
          },
        });

        if (response.status === 503) {
          continue;
        }
        if (response.ok) {
          html = (await response.text()).slice(0, 2_500_000);
          if (isAmazonChallengeHtml(html, parsedUrl)) {
            continue;
          }
          break;
        }
        if (!isAmazonHost) break;
      }

      clearTimeout(timeout);

      if (!response || !response.ok || isAmazonChallengeHtml(html, parsedUrl)) {
        const fallbackProduct = buildUrlFallbackFromSlug(parsedUrl);
        const enriched = await enrichBlockedUrlWithSearch(parsedUrl, fallbackProduct);
        const finalProduct = enriched ?? fallbackProduct;
        if (!isManufacturerHost(parsedUrl.hostname, finalProduct.brand)) {
          await attachManufacturerUrl(finalProduct, parsedUrl.hostname);
        }

        const warningMsg = finalProduct.imageUrl
          ? undefined
          : enriched
          ? `Il sito (${parsedUrl.hostname}) usa una protezione anti-bot che blocca il download della foto, ma abbiamo recuperato descrizione, specifiche${finalProduct.price > 0 ? ' e prezzo' : ''} tramite ricerca web. Puoi incollare il link della foto direttamente nella card.`
          : `Il sito (${parsedUrl.hostname}) blocca la lettura automatica (stato ${response?.status ?? 'bloccato'}): abbiamo salvato i dati ricavati dal link. Puoi inserire prezzo e foto direttamente nella tua pagina.`;

        res.json({
          product: finalProduct,
          partial: !finalProduct.imageUrl || finalProduct.price === 0,
          warning: warningMsg,
        });
        return;
      }

      const amazonProduct = parseAmazonProductHtml(html, parsedUrl);
      if (amazonProduct) {
        await attachManufacturerUrl(amazonProduct, parsedUrl.hostname);
        res.json({
          product: amazonProduct,
          partial: !amazonProduct.imageUrl || amazonProduct.price === 0,
        });
        return;
      }

      const ldMatches =
        html.match(/<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi) ||
        [];

      const productNodes: Array<Record<string, unknown>> = [];
      for (const block of ldMatches) {
        const inner = block
          .replace(/^<script[^>]*>/i, '')
          .replace(/<\/script>$/i, '')
          .trim();
        try {
          const parsedJson = JSON.parse(inner);
          findProductLdNodes(parsedJson, productNodes);
        } catch {
          // Ignore malformed JSON-LD blocks
        }
      }

      const ld = productNodes[0];
      const ogTitle = extractMetaTag(html, 'property', 'og:title');
      const ogDesc =
        extractMetaTag(html, 'property', 'og:description') ||
        extractMetaTag(html, 'name', 'description');
      const ogImage = extractMetaTag(html, 'property', 'og:image');
      const metaPrice =
        extractMetaTag(html, 'property', 'product:price:amount') ||
        extractMetaTag(html, 'property', 'og:price:amount');
      const htmlTitleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
      const htmlTitle = htmlTitleMatch?.[1] ? decodeHtmlEntities(htmlTitleMatch[1]) : undefined;

      const rawName =
        (typeof ld?.name === 'string' && decodeHtmlEntities(ld.name)) ||
        ogTitle ||
        htmlTitle ||
        buildUrlFallbackFromSlug(parsedUrl).name;

      const ldBrand =
        typeof ld?.brand === 'string'
          ? ld.brand
          : ld?.brand && typeof ld.brand === 'object' && 'name' in ld.brand
          ? String((ld.brand as Record<string, unknown>).name)
          : undefined;

      const brand =
        (ldBrand ? decodeHtmlEntities(ldBrand) : undefined) ||
        inferManufacturerFromText(rawName) ||
        inferBrandFromHost(parsedUrl.hostname);

      let priceNum = 0;
      const offersRaw = ld?.offers;
      const firstOffer = Array.isArray(offersRaw)
        ? (offersRaw[0] as Record<string, unknown> | undefined)
        : (offersRaw as Record<string, unknown> | undefined);

      if (firstOffer) {
        const rawP = firstOffer.price ?? firstOffer.lowPrice;
        if (rawP !== undefined) {
          priceNum = Number(String(rawP).replace(',', '.').replace(/[^0-9.]/g, '')) || 0;
        }
      }
      if (!priceNum && metaPrice) {
        priceNum = Number(metaPrice.replace(',', '.').replace(/[^0-9.]/g, '')) || 0;
      }

      let imageUrl: string | undefined = ogImage;
      const ldImg = ld?.image;
      if (typeof ldImg === 'string') {
        imageUrl = ldImg;
      } else if (Array.isArray(ldImg) && ldImg.length > 0) {
        const firstImg = ldImg[0];
        if (typeof firstImg === 'string') {
          imageUrl = firstImg;
        } else if (firstImg && typeof firstImg === 'object' && 'contentUrl' in firstImg) {
          imageUrl = String((firstImg as Record<string, unknown>).contentUrl);
        } else if (firstImg && typeof firstImg === 'object' && 'url' in firstImg) {
          imageUrl = String((firstImg as Record<string, unknown>).url);
        }
      } else if (ldImg && typeof ldImg === 'object' && 'url' in ldImg) {
        imageUrl = String((ldImg as Record<string, unknown>).url);
      }

      const rawCat = typeof ld?.category === 'string' ? decodeHtmlEntities(ld.category) : '';
      const { category, visualKind } = inferCategoryAndVisual(rawCat, rawName);

      const description =
        (typeof ld?.description === 'string' && decodeHtmlEntities(ld.description)) ||
        ogDesc ||
        `Articolo ${rawName} importato direttamente da ${parsedUrl.hostname}.`;

      const sku =
        (typeof ld?.sku === 'string' && ld.sku) ||
        (typeof ld?.mpn === 'string' && ld.mpn) ||
        (typeof ld?.gtin13 === 'string' && ld.gtin13) ||
        `WEB-${stableUrlId('item', parsedUrl).slice(-5).toUpperCase()}`;

      const agg = ld?.aggregateRating as Record<string, unknown> | undefined;
      const rating = agg?.ratingValue
        ? Math.min(5, Math.max(1, Number(agg.ratingValue) || 4.8))
        : 4.8;
      const reviewCount = agg?.reviewCount ? Math.max(1, Number(agg.reviewCount) || 1) : 1;

      const availRaw = typeof firstOffer?.availability === 'string' ? firstOffer.availability : '';
      const availability = availRaw.includes('OutOfStock')
        ? 'Attualmente esaurito sul sito'
        : 'Disponibilità immediata (verificata online)';

      const specs: Array<{ label: string; value: string }> = [
        { label: 'Marca', value: brand },
        { label: 'Codice / SKU', value: sku },
      ];
      if (rawCat) specs.push({ label: 'Categoria originale', value: rawCat });
      const colorText =
        cleanOptionalColorName(ld?.color) || extractExplicitColorFromText(rawName);
      if (colorText) {
        specs.push({ label: 'Colore', value: colorText });
      }
      if (typeof ld?.material === 'string' && ld.material) {
        specs.push({ label: 'Materiale', value: decodeHtmlEntities(ld.material) });
      }
      specs.push({ label: 'Link sorgente', value: parsedUrl.hostname.replace(/^www\./, '') });
      specs.push({ label: 'Collegamento originale', value: parsedUrl.href });

      const colorHex = colorText ? inferColorHex(colorText) : '';

      const genericDisplayName = stripDuplicateColorFromTitle(rawName, colorText);

      const product: NormalizedProduct = {
        id: stableUrlId(sku, parsedUrl),
        sku,
        name: genericDisplayName,
        brand,
        category,
        searchPriority: 98,
        price: priceNum,
        rating,
        reviewCount,
        availability,
        deliveryText: `Importato da ${parsedUrl.hostname.replace(/^www\./, '')}`,
        warranty: 'Garanzia ufficiale del venditore (24 mesi UE)',
        imageUrl,
        sourceUrl: parsedUrl.href,
        visualKind,
        shortSummary: description,
        highlights: [
          description,
          `Codice articolo rilevato: ${sku}`,
          `Importato direttamente dalla scheda ufficiale su ${parsedUrl.hostname.replace(/^www\./, '')}`,
        ],
        specs,
        boxContents: [rawName, 'Documentazione originale del produttore'],
        variants: [
          {
            id: 'imported',
            label: 'Versione da link',
            colorName: colorText,
            colorHex,
            priceDelta: 0,
          },
        ],
        keywords: [brand.toLowerCase(), rawName.toLowerCase(), sku.toLowerCase()],
      };

      if (!ld && !ogTitle) {
        const fallbackProduct = buildUrlFallbackFromSlug(parsedUrl);
        const enriched = await enrichBlockedUrlWithSearch(parsedUrl, fallbackProduct);
        if (enriched) {
          res.json({
            product: enriched,
            partial: !enriched.imageUrl || enriched.price === 0,
            warning: !enriched.imageUrl
              ? `Il sito (${parsedUrl.hostname}) non espone pubblicamente la foto ai server automatici, ma abbiamo recuperato i dettagli del prodotto.`
              : undefined,
          });
          return;
        }
      }

      if (!isManufacturerHost(parsedUrl.hostname, product.brand)) {
        await attachManufacturerUrl(product, parsedUrl.hostname);
      }

      res.json({ product, partial: !ld && !ogTitle });
    } catch {
      const fallbackProduct = buildUrlFallbackFromSlug(parsedUrl);
      const enriched = await enrichBlockedUrlWithSearch(parsedUrl, fallbackProduct);
      const finalProduct = enriched ?? fallbackProduct;
      if (!isManufacturerHost(parsedUrl.hostname, finalProduct.brand)) {
        await attachManufacturerUrl(finalProduct, parsedUrl.hostname);
      }

      res.json({
        product: finalProduct,
        partial: !finalProduct.imageUrl || finalProduct.price === 0,
        warning: finalProduct.imageUrl
          ? undefined
          : enriched
          ? `Il sito (${parsedUrl.hostname}) blocca il download diretto della foto, ma abbiamo recuperato descrizione e specifiche tramite ricerca web.`
          : 'Il sito ha impedito il download automatico della pagina: abbiamo creato la scheda dai dati del collegamento.',
      });
    } finally {
      clearTimeout(timeout);
    }
  });

  app.post('/api/catalog/resolve-variant', async (req, res) => {
    const rawName = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
    const rawBrand = typeof req.body?.brand === 'string' ? req.body.brand.trim() : '';
    const currentUrlStr = typeof req.body?.currentUrl === 'string' ? req.body.currentUrl.trim() : '';
    const currentVariant = typeof req.body?.currentVariant === 'string' ? req.body.currentVariant.trim() : '';
    const targetVariantRaw = typeof req.body?.targetVariant === 'string' ? req.body.targetVariant.trim() : '';
    const colorName = typeof req.body?.colorName === 'string' ? req.body.colorName.trim() : '';
    const variantLinks = Array.isArray(req.body?.variantLinks)
      ? (req.body.variantLinks as Array<{ size?: string; color?: string; sku?: string; url?: string }>)
      : [];

    const normalizedTarget = normalizeServerSizeText(targetVariantRaw);
    if (!rawName || !normalizedTarget) {
      res.status(400).json({ found: false, error: 'Nome prodotto o taglia mancante.' });
      return;
    }

    const parsedCurrentUrl = currentUrlStr ? isSafeExternalUrl(currentUrlStr) : null;

    const fetchAmazonProduct = async (
      host: string,
      asin: string
    ): Promise<NormalizedProduct | null> => {
      const canonicalUrl = new URL(`https://${host}/dp/${asin}?th=1`);
      const mobileUrl = `https://${host}/gp/aw/d/${asin}?th=1`;
      const attempts = [
        {
          url: mobileUrl,
          ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',
        },
        {
          url: canonicalUrl.href,
          ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        },
      ];
      for (const att of attempts) {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 7000);
        try {
          const r = await fetch(att.url, {
            signal: ctrl.signal,
            headers: {
              'User-Agent': att.ua,
              Accept: 'text/html,application/xhtml+xml',
              'Accept-Language': 'it-IT,it;q=0.9,en;q=0.8',
            },
          });
          if (!r.ok) continue;
          const html = (await r.text()).slice(0, 2_500_000);
          const parsed = parseAmazonProductHtml(html, canonicalUrl);
          if (parsed) return parsed;
        } catch {
          // ignore attempt error
        } finally {
          clearTimeout(t);
        }
      }
      return null;
    };

    // 1. Check local twister variantLinks from the original product first
    const twisterMatch =
      variantLinks.find(
        (vl) =>
          vl.url &&
          vl.size &&
          isSameServerSize(vl.size, normalizedTarget) &&
          (!colorName || !vl.color || vl.color.toLowerCase() === colorName.toLowerCase())
      ) ||
      variantLinks.find(
        (vl) => vl.url && vl.size && isSameServerSize(vl.size, normalizedTarget)
      );

    if (twisterMatch?.url) {
      const twisterParsedUrl = isSafeExternalUrl(twisterMatch.url);
      if (twisterParsedUrl && twisterParsedUrl.hostname.toLowerCase().includes('amazon.') && twisterMatch.sku) {
        const parsedProduct = await fetchAmazonProduct(twisterParsedUrl.hostname, twisterMatch.sku);
        if (parsedProduct) {
          res.json({
            found: true,
            matchedVia: 'twister',
            sourceUrl: parsedProduct.sourceUrl || twisterMatch.url,
            sku: parsedProduct.sku,
            name: parsedProduct.name,
            price: parsedProduct.price,
            imageUrl: parsedProduct.imageUrl,
            variantLabel: normalizedTarget,
            colorName: parsedProduct.variants[0]?.colorName || colorName,
            colorHex: parsedProduct.variants[0]?.colorHex || '',
          });
          return;
        }
      }
      res.json({
        found: true,
        matchedVia: 'twister',
        sourceUrl: twisterMatch.url,
        sku: twisterMatch.sku,
        variantLabel: normalizedTarget,
      });
      return;
    }

    // Build base model name without old size / condition tags for strict matching
    const cleanOldSizePattern = currentVariant
      ? new RegExp(
          `\\(?\\b${currentVariant.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s*')}\\b\\)?`,
          'gi'
        )
      : null;
    let baseModel = rawName
      .replace(/\([^)]*\)/g, (m: string) =>
        /\b\d+(?:[.,]\d+)?\s*(?:gb|tb|mb|cm|mm|pollici)\b/i.test(m) ? '' : m
      )
      .replace(/\b\d+(?:[.,]\d+)?\s*(?:gb|tb)\b/gi, '');
    if (cleanOldSizePattern) {
      baseModel = baseModel.replace(cleanOldSizePattern, '');
    }
    if (colorName) {
      const colorRe = new RegExp(
        colorName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'),
        'gi'
      );
      baseModel = baseModel.replace(colorRe, '');
    }
    baseModel = baseModel
      .replace(/[,|-]\s*$/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    const STOP_TOKENS = new Set([
      'per',
      'con',
      'da',
      'di',
      'in',
      'su',
      'il',
      'lo',
      'la',
      'i',
      'gli',
      'le',
      'del',
      'della',
      'ricondizionato',
      'renewed',
      'nuovo',
      'originale',
      'edizione',
    ]);
    const ACCESSORY_WORDS = [
      'custodia',
      'cover',
      'pellicola',
      'vetro temperato',
      'protezione',
      'caricatore',
      'alimentatore',
      'cavo',
      'adattatore',
      'supporto',
      'dock',
      'borsa',
      'zaino',
      'scocca',
    ];

    const coreTokens = baseModel
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, ' ')
      .split(/\s+/)
      .filter((t: string) => t.length >= 1 && !STOP_TOKENS.has(t));

    const targetCompact = normalizedTarget.replace(/\s+/g, '').toLowerCase();
    const targetSpaced = normalizedTarget.toLowerCase();
    const targetRegex = new RegExp(
      `(?<![a-z0-9])(?:${targetSpaced.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}|${targetCompact.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})(?![a-z0-9])`,
      'i'
    );

    const isStrictTitleMatch = (candidateTitle: string): boolean => {
      const normTitle = candidateTitle
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');
      const rawLower = rawName.toLowerCase();

      // Reject accessories unless original product was an accessory
      for (const acc of ACCESSORY_WORDS) {
        if (normTitle.includes(acc) && !rawLower.includes(acc)) {
          return false;
        }
      }

      // Must explicitly contain the requested target size
      if (!targetRegex.test(normTitle)) return false;

      // Must contain ALL core model tokens (e.g. apple, iphone, 17, pro, max)
      const titleTokens = new Set(normTitle.replace(/[^a-z0-9]+/g, ' ').split(/\s+/).filter(Boolean));
      for (const tok of coreTokens) {
        if (!titleTokens.has(tok)) return false;
      }
      return true;
    };

    // 2. Live Amazon search if currentUrl is an Amazon domain
    if (parsedCurrentUrl && parsedCurrentUrl.hostname.toLowerCase().includes('amazon.')) {
      const amazonHost = parsedCurrentUrl.hostname;
      const searchQuery = `${baseModel}${rawBrand && !baseModel.toLowerCase().includes(rawBrand.toLowerCase()) ? ` ${rawBrand}` : ''} ${normalizedTarget}`.trim();
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 8000);
      try {
        const searchRes = await fetch(
          `https://${amazonHost}/s?k=${encodeURIComponent(searchQuery)}`,
          {
            signal: ctrl.signal,
            headers: {
              'User-Agent':
                'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',
              Accept: 'text/html,application/xhtml+xml',
              'Accept-Language': 'it-IT,it;q=0.9',
            },
          }
        );
        if (searchRes.ok) {
          const searchHtml = (await searchRes.text()).slice(0, 2_500_000);
          const seenAsins = new Set<string>();
          const candidates: Array<{ asin: string; title: string; score: number }> = [];
          const linkRe =
            /href="[^"]*\/dp\/([A-Z0-9]{10})[^"]*"[\s\S]{0,1200}?(?:alt="([^"]{12,240})"|<h2[^>]*>[\s\S]{0,400}?<span[^>]*>([^<]{12,240})<\/span>)/gi;
          let m: RegExpExecArray | null;
          while ((m = linkRe.exec(searchHtml)) !== null) {
            const candAsin = m[1].toUpperCase();
            if (seenAsins.has(candAsin)) continue;
            seenAsins.add(candAsin);
            const candTitle = decodeHtmlEntities(m[2] || m[3] || '');
            if (!candTitle || !isStrictTitleMatch(candTitle)) continue;

            let score = 10;
            if (colorName && candTitle.toLowerCase().includes(colorName.toLowerCase())) {
              score += 5;
            }
            if (
              rawName.toLowerCase().includes('ricondizionato') ===
              candTitle.toLowerCase().includes('ricondizionato')
            ) {
              score += 3;
            }
            candidates.push({ asin: candAsin, title: candTitle, score });
          }

          candidates.sort((a, b) => b.score - a.score);
          if (candidates.length > 0) {
            const best = candidates[0];
            const parsedProduct = await fetchAmazonProduct(amazonHost, best.asin);
            if (parsedProduct && isStrictTitleMatch(parsedProduct.name)) {
              res.json({
                found: true,
                matchedVia: 'amazon-search',
                sourceUrl: parsedProduct.sourceUrl || `https://${amazonHost}/dp/${best.asin}?th=1`,
                sku: parsedProduct.sku,
                name: parsedProduct.name,
                price: parsedProduct.price,
                imageUrl: parsedProduct.imageUrl,
                variantLabel: normalizedTarget,
                colorName: parsedProduct.variants[0]?.colorName || colorName,
                colorHex: parsedProduct.variants[0]?.colorHex || '',
              });
              return;
            }
          }
        }
      } catch {
        // fallback to Google search below
      } finally {
        clearTimeout(t);
      }
    }

    // 3. Google Search grounding fallback via Gemini (for non-Amazon stores or if Amazon search didn't find it)
    if (parsedCurrentUrl) {
      try {
        const ai = getAiClient();
        const storeHost = parsedCurrentUrl.hostname.replace(/^www\./, '');
        const prompt = `Cerca su Google se esiste esattamente la pagina prodotto sul sito ${storeHost} per questo articolo con la variante richiesta:
Modello: ${baseModel}
Marca: ${rawBrand}
Taglia / Memoria / Configurazione richiesta: ${normalizedTarget}
${colorName ? `Colore preferito: ${colorName}` : ''}

Regole severissime:
- NON restituire un modello diverso (es. non restituire iPhone 18 se cerchiamo iPhone 17, non restituire Pro se cerchiamo Pro Max).
- NON restituire una memoria/taglia diversa da ${normalizedTarget}.
- NON restituire accessori, cover o pellicole.
- Se quella specifica variante NON esiste in vendita su ${storeHost}, restituisci "url": "".

Rispondi SOLO in JSON valido:
{
  "url": "URL esatto verificato su ${storeHost} oppure stringa vuota",
  "title": "titolo esatto trovato",
  "price": numero prezzo in euro oppure 0
}`;
        const aiRes = await ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: prompt,
          config: {
            tools: [{ googleSearch: {} }],
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          },
        });
        const parsedJson = extractJsonObject(aiRes.text ?? '');
        const candidateUrl =
          typeof parsedJson?.url === 'string' ? isSafeExternalUrl(parsedJson.url) : null;
        const candidateTitle =
          typeof parsedJson?.title === 'string' ? parsedJson.title.trim() : '';

        if (
          candidateUrl &&
          candidateUrl.hostname.replace(/^www\./, '') === storeHost &&
          candidateTitle &&
          isStrictTitleMatch(candidateTitle)
        ) {
          if (storeHost.includes('amazon.')) {
            const asin = extractAmazonAsin(candidateUrl);
            if (asin) {
              const verifiedProduct = await fetchAmazonProduct(candidateUrl.hostname, asin);
              if (verifiedProduct && isStrictTitleMatch(verifiedProduct.name)) {
                res.json({
                  found: true,
                  matchedVia: 'search',
                  sourceUrl: verifiedProduct.sourceUrl || candidateUrl.href,
                  sku: verifiedProduct.sku,
                  name: verifiedProduct.name,
                  price: verifiedProduct.price,
                  imageUrl: verifiedProduct.imageUrl,
                  variantLabel: normalizedTarget,
                  colorName: verifiedProduct.variants[0]?.colorName || colorName,
                  colorHex: verifiedProduct.variants[0]?.colorHex || '',
                });
                return;
              }
            }
          } else {
            const rawP = Number(parsedJson?.price);
            res.json({
              found: true,
              matchedVia: 'search',
              sourceUrl: candidateUrl.href,
              name: candidateTitle,
              price: Number.isFinite(rawP) && rawP > 0 ? Number(rawP.toFixed(2)) : undefined,
              variantLabel: normalizedTarget,
            });
            return;
          }
        }
      } catch {
        // ignore search errors
      }
    }

    res.json({
      found: false,
      normalizedVariant: normalizedTarget,
    });
  });

  app.post('/api/catalog/find-manufacturer-url', async (req, res) => {
    const rawName = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
    const rawBrand = typeof req.body?.brand === 'string' ? req.body.brand.trim() : '';
    const rawCategory = typeof req.body?.category === 'string' ? req.body.category.trim() : '';
    const rawSku = typeof req.body?.sku === 'string' ? req.body.sku.trim() : '';
    const rawSourceUrl = typeof req.body?.sourceUrl === 'string' ? req.body.sourceUrl.trim() : '';
    const rawSpecs = Array.isArray(req.body?.specs)
      ? (req.body.specs as ProductSpec[]).filter(
          (s) => s && typeof s.label === 'string' && typeof s.value === 'string'
        )
      : undefined;

    if (!rawName || !rawBrand) {
      res.status(400).json({ found: false, error: 'Nome prodotto o marca mancante.' });
      return;
    }

    const officialUrl = await findManufacturerUrl({
      name: rawName,
      brand: rawBrand,
      category: rawCategory,
      sku: rawSku,
      sourceUrl: rawSourceUrl,
      specs: rawSpecs,
    });

    if (officialUrl) {
      res.json({ found: true, officialUrl });
      return;
    }

    res.json({ found: false });
  });


  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
