import { Product, ProductCategory, VisualKind } from '../types/product';

export interface SearchMatch {
  product: Product;
  score: number;
  matchedField: 'name' | 'brand' | 'category' | 'keyword' | 'spec';
}

const QUERY_ALIASES: Array<[RegExp, string]> = [
  [/\bmaosn\b/g, 'maisons'],
  [/\bmason\b/g, 'maisons'],
  [/\bdue\s+monde\b/g, 'du monde'],
  [/\bb\s+ticino\b/g, 'bticino'],
  [/\bticino\b/g, 'bticino'],
  [/\bwind\s+tre\b/g, 'windtre'],
  [/\bwind3\b/g, 'windtre'],
  [/\blampadari\b/g, 'lampadario'],
  [/\bdivani\b/g, 'divano'],
  [/\bplacche\b/g, 'placca'],
  [/\btelevisori\b/g, 'tv'],
  [/\btelevisore\b/g, 'tv'],
  [/\bsmart\s*tv\b/g, 'tv'],
];

function normalize(str: string): string {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

function applyAliases(normQuery: string): string {
  let result = normQuery;
  for (const [pattern, replacement] of QUERY_ALIASES) {
    result = result.replace(pattern, replacement);
  }
  return result;
}

export function searchCatalog(
  catalog: Product[],
  rawQuery: string,
  categoryFilter: ProductCategory | 'Tutte' = 'Tutte'
): SearchMatch[] {
  const query = applyAliases(normalize(rawQuery));
  const filteredByCategory =
    categoryFilter === 'Tutte'
      ? catalog
      : catalog.filter((p) => p.category === categoryFilter);

  if (!query) {
    return filteredByCategory
      .slice()
      .sort((a, b) => b.searchPriority - a.searchPriority)
      .map((product) => ({
        product,
        score: product.searchPriority,
        matchedField: 'name',
      }));
  }

  const tokens = query.split(/\s+/).filter(Boolean);
  const matches: SearchMatch[] = [];

  for (const product of filteredByCategory) {
    const nameNorm = normalize(product.name);
    const brandNorm = normalize(product.brand);
    const catNorm = normalize(product.category);
    const keywordsNorm = product.keywords.map(normalize);
    const summaryNorm = normalize(product.shortSummary);
    const specsNorm = normalize(product.specs.map((s) => `${s.label} ${s.value}`).join(' '));

    const searchableText = `${nameNorm} ${brandNorm} ${catNorm} ${keywordsNorm.join(' ')} ${summaryNorm} ${specsNorm}`;
    const allTokensPresent = tokens.every((t) => searchableText.includes(t));

    if (!allTokensPresent) continue;

    let score = product.searchPriority * 0.2;
    let matchedField: SearchMatch['matchedField'] = 'spec';

    if (nameNorm.startsWith(query)) {
      score += 1000;
      matchedField = 'name';
    } else if (nameNorm.split(/[\s"()-]+/).some((word) => word.startsWith(query))) {
      score += 750;
      matchedField = 'name';
    } else if (tokens.every((t) => nameNorm.includes(t) || brandNorm.includes(t))) {
      score += 650;
      matchedField = 'name';
    } else if (nameNorm.includes(query)) {
      score += 500;
      matchedField = 'name';
    } else if (brandNorm.startsWith(query) || tokens.some((t) => brandNorm.startsWith(t))) {
      score += 420;
      matchedField = 'brand';
    } else if (keywordsNorm.some((k) => k.startsWith(query))) {
      score += 320;
      matchedField = 'keyword';
    } else if (catNorm.startsWith(query) || catNorm.includes(query)) {
      score += 220;
      matchedField = 'category';
    } else {
      score += 100;
    }

    matches.push({ product, score, matchedField });
  }

  return matches.sort((a, b) => b.score - a.score);
}

export interface TextSegment {
  text: string;
  highlighted: boolean;
}

export function splitHighlight(text: string, query: string): TextSegment[] {
  const cleanQuery = query.trim();
  if (!cleanQuery) {
    return [{ text, highlighted: false }];
  }

  const lowerText = text.toLowerCase();
  const lowerQuery = cleanQuery.toLowerCase();
  const index = lowerText.indexOf(lowerQuery);

  if (index === -1) {
    return [{ text, highlighted: false }];
  }

  const segments: TextSegment[] = [];
  if (index > 0) {
    segments.push({ text: text.slice(0, index), highlighted: false });
  }
  segments.push({
    text: text.slice(index, index + cleanQuery.length),
    highlighted: true,
  });
  if (index + cleanQuery.length < text.length) {
    segments.push({
      text: text.slice(index + cleanQuery.length),
      highlighted: false,
    });
  }
  return segments;
}

export function formatEuro(amount: number): string {
  return new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
  }).format(amount);
}

export function isProductUrl(value: string): boolean {
  const trimmed = value.trim();
  if (!/^https?:\/\/\S+$/i.test(trimmed)) return false;
  try {
    const parsed = new URL(trimmed);
    return (parsed.protocol === 'http:' || parsed.protocol === 'https:') && parsed.hostname.includes('.');
  } catch {
    return false;
  }
}

export function inferVisualKind(category: string, text: string): VisualKind {
  const combined = `${category} ${text}`.toLowerCase();
  if (
    combined.includes('lampad') ||
    combined.includes('sospensione') ||
    combined.includes('plafoniera') ||
    combined.includes('abat-jour') ||
    combined.includes('illuminazione')
  ) {
    return 'lighting';
  }
  if (combined.includes('divan') || combined.includes('sofa') || combined.includes('sofà') || combined.includes('poltrona')) {
    return 'sofa';
  }
  if (combined.includes('cucin') && !combined.includes('forno') && !combined.includes('piano cottura')) {
    return 'kitchen';
  }
  if (combined.includes('tv') || combined.includes('oled') || combined.includes('qled') || combined.includes('televisore')) {
    return 'tv';
  }
  if (combined.includes('router') || combined.includes('modem') || combined.includes('mesh') || combined.includes('wifi')) {
    return 'router';
  }
  if (combined.includes('bticino') || combined.includes('termostato') || combined.includes('placca') || combined.includes('videocitofono')) {
    return 'smarthome';
  }
  if (category === 'Smartphone' || combined.includes('iphone') || combined.includes('galaxy')) {
    return 'phone-pro';
  }
  if (category === 'Tablet' || combined.includes('ipad') || combined.includes('tablet')) {
    return 'tablet-pro';
  }
  if (category === 'Computer' || combined.includes('macbook') || combined.includes('laptop')) {
    return 'laptop-pro';
  }
  if (category === 'Audio' || combined.includes('cuffie') || combined.includes('soundbar')) {
    return 'headphones';
  }
  if (category === 'Wearable' || combined.includes('watch') || combined.includes('orologio')) {
    return 'watch-series';
  }
  if (category === 'Fotografia' || combined.includes('fotocamera')) {
    return 'camera';
  }
  if (category === 'Elettrodomestici' || combined.includes('lavatrice') || combined.includes('frigo') || combined.includes('forno')) {
    return 'appliance';
  }
  if (category === 'Arredamento' || combined.includes('mobile') || combined.includes('tavolo') || combined.includes('sedia') || combined.includes('armadio')) {
    return 'furniture';
  }
  if (category === 'Strumenti Musicali' || combined.includes('chitarra') || combined.includes('basso')) {
    return 'guitar';
  }
  if (category === 'Domotica & Rete') {
    return 'smarthome';
  }
  return 'generic-product';
}

export function inferBrandFromText(text: string): string | undefined {
  const t = text.toLowerCase();
  const known: Array<[RegExp, string]> = [
    [/\b(iphone|ipad|macbook|apple|airpods|imac)\b/, 'Apple'],
    [/\b(galaxy|samsung)\b/, 'Samsung'],
    [/\btcl\b/, 'TCL'],
    [/\belectrolux\b/, 'Electrolux'],
    [/\bbticino\b/, 'BTicino'],
    [/\bwind\s*tre\b|\bwindtre\b/, 'WindTre'],
    [/\bfederici\b/, 'Federici Sofà'],
    [/\bveneta cucine\b/, 'Veneta Cucine'],
    [/\bfebal\b/, 'Febal Casa'],
    [/\bmaisons du monde\b/, 'Maisons du Monde'],
    [/\bikea\b/, 'IKEA'],
    [/\bibanez\b/, 'Ibanez'],
    [/\bsony\b/, 'Sony'],
    [/\bdyson\b/, 'Dyson'],
  ];
  for (const [re, brand] of known) {
    if (re.test(t)) return brand;
  }
  return undefined;
}

export function inferCategoryFromText(text: string): ProductCategory | undefined {
  const t = text.toLowerCase();
  if (/\b(iphone|smartphone|galaxy\s*s|pixel)\b/.test(t)) return 'Smartphone';
  if (/\b(ipad|tablet)\b/.test(t)) return 'Tablet';
  if (/\b(macbook|laptop|notebook|imac)\b/.test(t)) return 'Computer';
  if (/\b(cuffie|airpods|soundbar|cassa|speaker)\b/.test(t)) return 'Audio';
  if (/\b(tv|oled|qled|televisore|console|playstation|xbox|switch)\b/.test(t)) return 'Casa & Gaming';
  if (/\b(lavatrice|asciugatrice|lavastoviglie|frigo|forno|induzione|microonde|electrolux)\b/.test(t))
    return 'Elettrodomestici';
  if (/\b(bticino|router|modem|termostato|placca|videocitofono|windtre)\b/.test(t))
    return 'Domotica & Rete';
  if (/\b(divano|lampadario|lampada|cucina|armadio|tavolo|sedia|statuetta|specchio|libreria|ikea|federici|veneta|febal|maisons)\b/.test(t))
    return 'Arredamento';
  if (/\b(chitarra|basso|amplificatore|ibanez)\b/.test(t)) return 'Strumenti Musicali';
  return undefined;
}

const COLOR_PALETTE_RULES: Array<[RegExp, string]> = [
  // Multi-word & specific shades first
  [/\b(arancione\s*cosmico|cosmic\s*orange)\b/, '#D96B27'],
  [/\b(oro\s*rosa|rose\s*gold|pink\s*gold)\b/, '#C99588'],
  [/\b(blu\s*(?:notte|mezzanotte)|midnight(?:\s*blue)?|mezzanotte)\b/, '#1A2438'],
  [/\b(blu\s*(?:profondo|marino|scuro)|deep\s*blue|dark\s*blue|navy)\b/, '#1F2F4C'],
  [/\b(blu\s*(?:cobalto|elettrico|zaffiro)|cobalto|cobalt|zaffiro|sapphire|ultramarino|oltremare)\b/, '#1E4D9B'],
  [/\b(carta\s*da\s*zucchero|avio|denim|jeans)\b/, '#52728F'],
  [/\b(verde\s*petrolio|petrolio|ottanio|teal|pavone)\b/, '#1C5D68'],
  [/\b(verde\s*(?:bosco|abete|pino|scuro)|forest\s*green|dark\s*green)\b/, '#244C38'],
  [/\b(verde\s*militare|militare|oliva|olive|muschio|moss|kaki|khaki|cachi)\b/, '#55613C'],
  [/\b(verde\s*smeraldo|smeraldo|emerald|giada|jade)\b/, '#257A57'],
  [/\b(verde\s*salvia|salvia|sage|eucalipto)\b/, '#7A9482'],
  [/\b(verde\s*menta|menta|mint|pistacchio|pistachio|acquamarina|tiffany)\b/, '#74B89E'],
  [/\b(verde\s*acqua)\b/, '#5FA395'],
  [/\b(rosa\s*(?:antico|cipria)|cipria|dusty\s*rose|blush)\b/, '#CFA1A6'],
  [/\b(titanio\s*naturale|natural\s*titanium)\b/, '#A8A59E'],
  [/\b(titanio\s*nero|black\s*titanium|canna\s*di\s*fucile|gunmetal)\b/, '#525458'],
  [/\b(grigio\s*(?:siderale|scuro)|space\s*gr[ae]y|dark\s*gr[ae]y|piombo|fumo)\b/, '#5A5D64'],
  [/\b(bianco\s*caldo|off\s*white)\b/, '#EDE8DC'],

  // Reds / Burgundy / Wine
  [/\b(borgogna|burgundy|bordeaux|vinaccia|sangria|chianti|barolo|amarone)\b/, '#7A1C2E'],
  [/\b(granata|garnet)\b/, '#7B1E26'],
  [/\b(amaranto|crimson|cremisi|carminio|rubino|ruby|ciliegia|cherry)\b/, '#9E1B32'],
  [/\b(melanzana|aubergine|eggplant)\b/, '#4E2340'],
  [/\b(prugna|plum)\b/, '#5E2B4E'],
  [/\b(lampone|raspberry|fragola|strawberry)\b/, '#B8294B'],
  [/\b(terracotta|mattone|brick|coccio)\b/, '#B55239'],
  [/\b(ruggine|rust)\b/, '#9E472A'],
  [/\b(corallo|coral)\b/, '#E06553'],
  [/\b(salmone|salmon)\b/, '#E58975'],

  // Oranges / Yellows / Golds
  [/\b(pesca|peach|albicocca|apricot)\b/, '#F0A678'],
  [/\b(ambra|amber|miele|honey|caramello|caramel)\b/, '#C97A2B'],
  [/\b(senape|mustard|ocra|ochre|curcuma|zafferano)\b/, '#C79326'],
  [/\b(champagne|starlight|galassia)\b/, '#DFD3BE'],
  [/\b(ottone|brass|ottonato)\b/, '#C5A059'],
  [/\b(lime|cedro|chartreuse)\b/, '#9AB83B'],

  // Blues / Purples / Pinks
  [/\b(turchese|turquoise|ciano|cyan)\b/, '#249EA8'],
  [/\b(azzurro|celeste|sky\s*blue|light\s*blue|ghiaccio)\b/, '#6AA7D9'],
  [/\b(fucsia|fuchsia|magenta)\b/, '#B8296B'],
  [/\b(indaco|indigo|mora)\b/, '#4B2E6E'],
  [/\b(lavanda|lavender|lilla|lilac|glicine|pervinca|malva|mauve|orchidea)\b/, '#A38DB8'],

  // Browns / Woods / Metals
  [/\b(wenge|ebano|ebony|palissandro)\b/, '#3D2B22'],
  [/\b(caffe|coffee|espresso|cioccolato|chocolate|cacao)\b/, '#4E3529'],
  [/\b(mogano|mahogany|castagno|chestnut)\b/, '#6E3B2B'],
  [/\b(cuoio|cognac|tabacco|leather|saddle|nocciola|noce|walnut)\b/, '#855436'],
  [/\b(teak|rovere|quercia|oak|legno|wood|faggio|frassino|betulla|bambu)\b/, '#B58F63'],
  [/\b(cammello|camel|taupe|tortora|talpa|visone|marrone|brown)\b/, '#7F614A'],
  [/\b(sabbia|sand|beige|canapa|lino|ecru|crema|cream)\b/, '#CFC1AA'],
  [/\b(rame|copper)\b/, '#B86B43'],
  [/\b(bronzo|bronze)\b/, '#7D5C3E'],
  [/\b(titanio|titanium)\b/, '#7A7C80'],
  [/\b(antracite|anthracite|grafite|graphite|carbone|charcoal|ossidiana|onice|ardesia)\b/, '#36383E'],
  [/\b(argento|silver|inox|acciaio|steel|cromo|cromato|chrome|platino|platinum|alluminio)\b/, '#C5C8CE'],
  [/\b(avorio|ivory|panna|perla|pearl)\b/, '#EDE8DC'],

  // Base color families (catch-all for compound phrases like "Blu Egeo", "Rosso Corsa", etc.)
  [/\b(arancione|arancio|orange|mandarino|tangerine|zucca|cosmico)\b/, '#E06D22'],
  [/\b(rosso|red|scarlatto|vermiglio)\b/, '#B82828'],
  [/\b(oro|gold|dorato)\b/, '#D4AF37'],
  [/\b(giallo|yellow|limone|lemon|canarino)\b/, '#E2B729'],
  [/\b(verde|green|acqua)\b/, '#38764B'],
  [/\b(blu|blue|marino)\b/, '#25539B'],
  [/\b(viola|violetto|violet|purple)\b/, '#764B9E'],
  [/\b(rosa|pink)\b/, '#D9829B'],
  [/\b(grigio|gr[ae]y|cemento|concrete|cenere|pietra)\b/, '#8D9096'],
  [/\b(bianco|white|neve|snow|latte)\b/, '#F2F2EE'],
  [/\b(nero|black|corvino)\b/, '#1C1D20'],
];

export function inferColorHexClient(colorName: string): string {
  const normalized = colorName
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
  if (!normalized) return '#2B2C30';
  for (const [pattern, hex] of COLOR_PALETTE_RULES) {
    if (pattern.test(normalized)) return hex;
  }
  return '#2B2C30';
}

