import { useEffect, useRef, useState } from 'react';
import { Link2, Loader2, PenLine, Plus, Search, X } from 'lucide-react';
import { SavedPageItem } from '../types/product';
import { formatEuro, isProductUrl } from '../utils/search';
import { ProductVisual } from './ProductVisual';

interface SearchBarProps {
  query: string;
  rooms: string[];
  savedItems: SavedPageItem[];
  isDropdownOpen: boolean;
  isImportingUrl: boolean;
  inputRef: React.RefObject<HTMLInputElement | null>;
  onQueryChange: (value: string) => void;
  onDropdownOpenChange: (open: boolean) => void;
  onImportFromUrl: (url: string, addDirectly: boolean, room?: string) => Promise<boolean>;
  onOpenManualWithText: (modelName: string) => void;
  onJumpToMyPage: () => void;
}

export function SearchBar({
  query,
  rooms,
  savedItems,
  isDropdownOpen,
  isImportingUrl,
  inputRef,
  onQueryChange,
  onDropdownOpenChange,
  onImportFromUrl,
  onOpenManualWithText,
  onJumpToMyPage,
}: SearchBarProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedRoom, setSelectedRoom] = useState<string>('Non assegnata');

  useEffect(() => {
    function handleOutsideClick(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        onDropdownOpenChange(false);
      }
    }
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [onDropdownOpenChange]);

  const trimmed = query.trim();
  const isUrl = isProductUrl(trimmed);
  const showDropdown = isDropdownOpen && trimmed.length > 0;

  const matchingSaved =
    !isUrl && trimmed.length >= 2
      ? savedItems
          .filter((item) => {
            const hay =
              `${item.product.name} ${item.product.brand} ${item.product.category} ${item.variant.colorName} ${item.room || ''}`.toLowerCase();
            return hay.includes(trimmed.toLowerCase());
          })
          .slice(0, 4)
      : [];

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!trimmed) return;
    if (isUrl) {
      void onImportFromUrl(trimmed, true, selectedRoom).then((ok) => {
        if (ok) {
          onQueryChange('');
          onDropdownOpenChange(false);
        }
      });
    } else {
      onDropdownOpenChange(false);
      onOpenManualWithText(trimmed);
    }
  }

  return (
    <div ref={containerRef} className="relative w-full">
      <form
        onSubmit={handleSubmit}
        className="flex items-stretch w-full bg-white border-2 border-[#141413] rounded-lg shadow-sm focus-within:ring-2 focus-within:ring-[#F59E0B]"
        role="search"
        aria-label="Incolla link prodotto o inserisci modello"
      >
        <div className="relative flex-1 flex items-center">
          {isUrl ? (
            <Link2
              className="w-4 h-4 text-[#D97706] ml-3.5 shrink-0 pointer-events-none"
              aria-hidden="true"
            />
          ) : (
            <Search
              className="w-4 h-4 text-[#5E5E59] ml-3.5 shrink-0 pointer-events-none"
              aria-hidden="true"
            />
          )}
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              onQueryChange(e.target.value);
              onDropdownOpenChange(true);
            }}
            onFocus={() => {
              if (trimmed.length > 0) {
                onDropdownOpenChange(true);
              }
            }}
            onKeyDown={(e) => {
              if (e.key === 'Escape') {
                onDropdownOpenChange(false);
              }
            }}
            placeholder="Incolla il link di un articolo (Amazon, IKEA, ecc.) oppure scrivi il modello da aggiungere..."
            aria-expanded={showDropdown}
            className="w-full px-3 py-3 text-sm sm:text-base text-[#141413] placeholder:text-[#787872] bg-transparent focus:outline-none"
          />
          {isImportingUrl && (
            <Loader2
              className="w-4 h-4 text-[#5E5E59] animate-spin mr-1 shrink-0"
              aria-label="Lettura link in corso"
            />
          )}
          {query && (
            <button
              type="button"
              onClick={() => {
                onQueryChange('');
                onDropdownOpenChange(false);
                inputRef.current?.focus();
              }}
              aria-label="Cancella campo"
              className="p-2 mr-1 text-[#5E5E59] hover:text-[#141413] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <button
          type="submit"
          disabled={isImportingUrl}
          className="px-4 sm:px-6 bg-[#F59E0B] hover:bg-[#D97706] text-[#141413] hover:text-white font-semibold text-sm flex items-center gap-2 rounded-r-md transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
        >
          {isUrl ? (
            <>
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span className="hidden sm:inline">Importa</span>
            </>
          ) : (
            <>
              <PenLine className="w-4 h-4 sm:hidden" aria-hidden="true" />
              <span className="hidden sm:inline">Aggiungi</span>
            </>
          )}
        </button>
      </form>

      {showDropdown && (
        <div className="absolute left-0 right-0 top-[calc(100%+6px)] z-40 bg-white border border-[#D4D4CE] rounded-lg shadow-xl overflow-hidden">
          {isUrl ? (
            <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#FAFAF8]">
              <div className="flex items-start gap-3 min-w-0">
                <div className="w-10 h-10 rounded-md bg-white border border-[#E4E4E0] flex items-center justify-center shrink-0">
                  <Link2 className="w-5 h-5 text-[#141413]" aria-hidden="true" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-bold text-[#141413]">Link articolo rilevato</p>
                  <p className="text-xs text-[#5E5E59] truncate mt-0.5">{trimmed}</p>
                  <p className="text-xs text-[#4A4A46] mt-1">
                    Premi <strong className="font-semibold text-[#141413]">Importa</strong> per
                    aggiungerlo subito nella stanza scelta, oppure apri l’anteprima.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <select
                  aria-label="Stanza di destinazione"
                  value={selectedRoom}
                  onChange={(e) => setSelectedRoom(e.target.value)}
                  className="px-2.5 py-2 text-xs bg-white border border-[#D4D4CE] rounded-md text-[#141413] focus:outline-none focus:border-[#141413] cursor-pointer"
                >
                  {rooms.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  disabled={isImportingUrl}
                  onClick={async () => {
                    const ok = await onImportFromUrl(trimmed, false, selectedRoom);
                    if (ok) {
                      onDropdownOpenChange(false);
                    }
                  }}
                  className="px-3 py-2 text-xs font-medium text-[#141413] bg-white border border-[#D4D4CE] hover:bg-[#F3F3F0] rounded-md transition-colors whitespace-nowrap cursor-pointer disabled:opacity-60"
                >
                  Anteprima dettagli
                </button>
              </div>
            </div>
          ) : (
            <div className="divide-y divide-[#F0F0EC]">
              {matchingSaved.length > 0 && (
                <div className="p-3 bg-[#FAFAF8]">
                  <p className="text-[11px] font-semibold text-[#5E5E59] px-1 mb-2">
                    Già presenti nella tua pagina ({matchingSaved.length})
                  </p>
                  <div className="space-y-1.5">
                    {matchingSaved.map((item) => {
                      const unitPrice = item.product.price + item.variant.priceDelta;
                      return (
                        <button
                          key={item.entryId}
                          type="button"
                          onClick={() => {
                            onDropdownOpenChange(false);
                            onJumpToMyPage();
                          }}
                          className="w-full flex items-center justify-between gap-3 px-2.5 py-2 bg-white hover:bg-[#F3F3F0] border border-[#E4E4E0] rounded-md text-left cursor-pointer"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <ProductVisual
                              imageUrl={item.product.imageUrl}
                              visualKind={item.product.visualKind}
                              name={item.product.name}
                              accentHex={item.variant.colorHex}
                              className="w-9 h-9 rounded border border-[#EAEAE5] shrink-0"
                            />
                            <div className="min-w-0">
                              <p className="text-xs font-semibold text-[#141413] truncate">
                                {item.product.name}
                              </p>
                              <p className="text-[11px] text-[#5E5E59] truncate">
                                {item.product.brand} · {item.room || 'Non assegnata'} ·{' '}
                                {item.variant.colorName}
                              </p>
                            </div>
                          </div>
                          {unitPrice > 0 && (
                            <span className="text-xs font-bold text-[#141413] tabular-nums shrink-0">
                              {formatEuro(unitPrice)}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <button
                type="button"
                onClick={() => {
                  onDropdownOpenChange(false);
                  onOpenManualWithText(trimmed);
                }}
                className="w-full px-4 py-3.5 text-left hover:bg-[#FAFAF8] flex items-center justify-between gap-3 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <PenLine className="w-4 h-4 text-[#D97706] shrink-0" aria-hidden="true" />
                  <span className="text-xs sm:text-sm text-[#141413] truncate">
                    Inserisci <strong className="font-bold">«{trimmed}»</strong> come modello
                    manuale
                  </span>
                </div>
                <span className="text-xs font-semibold text-[#141413] shrink-0">
                  Compila scheda →
                </span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
