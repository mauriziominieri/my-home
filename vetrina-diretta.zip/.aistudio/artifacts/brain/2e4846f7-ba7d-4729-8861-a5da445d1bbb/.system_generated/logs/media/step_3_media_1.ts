import { useEffect, useMemo, useRef, useState } from 'react';
import { Check, X } from 'lucide-react';
import {
  DEFAULT_HOME_ROOMS,
  Product,
  ProductVariant,
  SavedPageItem,
} from './types/product';
import { inferColorHexClient } from './utils/search';
import { TopBar } from './components/TopBar';
import { SearchBar } from './components/SearchBar';
import { SearchResults } from './components/SearchResults';
import { ItemDetailsUpdate, UserPageSection } from './components/UserPageSection';
import { CustomImportPanel } from './components/CustomImportPanel';

const STORAGE_KEY = 'vetrina_diretta_page_items_v2';
const ROOMS_STORAGE_KEY = 'vetrina_diretta_rooms_v1';

function loadSavedItems(): SavedPageItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Array<{
      entryId: string;
      product: Product;
      variant: ProductVariant;
      quantity: number;
      addedAt: number;
    }>;
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((row) => row && row.product && row.variant)
      .map((row) => {
        const rawHex = row.variant.colorHex || '#2B2C30';
        const resolvedHex =
          rawHex.toUpperCase() === '#2B2C30' && row.variant.colorName
            ? inferColorHexClient(row.variant.colorName)
            : rawHex;
        const fixedColorOptions = row.product.colorOptions?.map((c) => ({
          ...c,
          hex: c.hex.toUpperCase() === '#2B2C30' ? inferColorHexClient(c.name) : c.hex,
        }));
        return {
          entryId: String(row.entryId),
          product: fixedColorOptions
            ? { ...row.product, colorOptions: fixedColorOptions }
            : row.product,
          variant:
            resolvedHex !== row.variant.colorHex
              ? { ...row.variant, colorHex: resolvedHex }
              : row.variant,
          quantity: Math.max(1, Number(row.quantity) || 1),
          room:
            typeof (row as SavedPageItem).room === 'string'
              ? (row as SavedPageItem).room
              : 'Non assegnata',
          addedAt: Number(row.addedAt) || Date.now(),
        };
      });
  } catch {
    return [];
  }
}

function loadRooms(initialItems: SavedPageItem[]): string[] {
  const merged = new Set<string>(DEFAULT_HOME_ROOMS);
  try {
    const raw = localStorage.getItem(ROOMS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as unknown;
      if (Array.isArray(parsed)) {
        for (const r of parsed) {
          if (typeof r === 'string' && r.trim()) merged.add(r.trim());
        }
      }
    }
  } catch {
    // Ignore storage errors
  }
  for (const item of initialItems) {
    if (item.room && item.room.trim()) merged.add(item.room.trim());
  }
  return Array.from(merged);
}

export default function App() {
  const [query, setQuery] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [previewProducts, setPreviewProducts] = useState<Product[]>([]);
  const [pageItems, setPageItems] = useState<SavedPageItem[]>(() => loadSavedItems());
  const [rooms, setRooms] = useState<string[]>(() => loadRooms(loadSavedItems()));
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [manualPanelOpen, setManualPanelOpen] = useState(false);
  const [prefillManualName, setPrefillManualName] = useState('');
  const [isImportingUrl, setIsImportingUrl] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [importWarning, setImportWarning] = useState<string | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);
  const resultsAnchorRef = useRef<HTMLDivElement>(null);
  const toastTimerRef = useRef<number | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(pageItems));
    } catch {
      // Ignore storage quota errors
    }
  }, [pageItems]);

  useEffect(() => {
    try {
      localStorage.setItem(ROOMS_STORAGE_KEY, JSON.stringify(rooms));
    } catch {
      // Ignore storage quota errors
    }
  }, [rooms]);

  const totalPageCount = useMemo(
    () => pageItems.reduce((sum, item) => sum + item.quantity, 0),
    [pageItems]
  );

  function notifyAdded(message: string) {
    setToastMessage(message);
    if (toastTimerRef.current) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 2400);
  }

  function handleAddRoom(roomName: string) {
    const clean = roomName.trim();
    if (!clean) return;
    setRooms((prev) => (prev.includes(clean) ? prev : [...prev, clean]));
    notifyAdded(`Stanza «${clean}» aggiunta`);
  }

  function handleAddToPage(
    product: Product,
    variant: ProductVariant = product.variants[0],
    room = 'Non assegnata'
  ) {
    const cleanRoom = room.trim() || 'Non assegnata';
    const entryKey = `${product.id}::${variant.id}::${cleanRoom}`;
    setPageItems((prev) => {
      const existing = prev.find((item) => item.entryId === entryKey);
      if (existing) {
        return prev.map((item) =>
          item.entryId === entryKey ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [
        {
          entryId: entryKey,
          product,
          variant,
          quantity: 1,
          room: cleanRoom,
          addedAt: Date.now(),
        },
        ...prev,
      ];
    });
    const roomNote = cleanRoom !== 'Non assegnata' ? ` in ${cleanRoom}` : '';
    notifyAdded(`«${product.name}» (${variant.label})${roomNote} aggiunto alla tua pagina`);
  }

  function handleUpdateQuantity(entryId: string, delta: number) {
    setPageItems((prev) =>
      prev
        .map((item) =>
          item.entryId === entryId
            ? { ...item, quantity: item.quantity + delta }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  }

  function handleRemoveItem(entryId: string) {
    setPageItems((prev) => prev.filter((item) => item.entryId !== entryId));
  }

  function handleMoveItem(entryId: string, direction: 'up' | 'down') {
    setPageItems((prev) => {
      const index = prev.findIndex((i) => i.entryId === entryId);
      if (index === -1) return prev;
      const targetIndex = direction === 'up' ? index - 1 : index + 1;
      if (targetIndex < 0 || targetIndex >= prev.length) return prev;
      const next = prev.slice();
      const [moved] = next.splice(index, 1);
      next.splice(targetIndex, 0, moved);
      return next;
    });
  }

  function handleUpdatePrice(entryId: string, newUnitPrice: number) {
    setPageItems((prev) =>
      prev.map((item) =>
        item.entryId === entryId
          ? {
              ...item,
              product: { ...item.product, price: newUnitPrice },
              variant: { ...item.variant, priceDelta: 0 },
            }
          : item
      )
    );
  }

  function handleUpdateImage(entryId: string, newImageUrl: string) {
    setPageItems((prev) =>
      prev.map((item) =>
        item.entryId === entryId
          ? {
              ...item,
              product: {
                ...item.product,
                imageUrl: newImageUrl ? newImageUrl : undefined,
              },
            }
          : item
      )
    );
  }

  function handleUpdateRoom(entryId: string, room: string) {
    const cleanRoom = room.trim() || 'Non assegnata';
    setPageItems((prev) =>
      prev.map((item) => (item.entryId === entryId ? { ...item, room: cleanRoom } : item))
    );
  }

  function handleUpdateItemDetails(entryId: string, updates: ItemDetailsUpdate) {
    setPageItems((prev) =>
      prev.map((item) =>
        item.entryId === entryId
          ? {
              ...item,
              room: updates.room || 'Non assegnata',
              product: {
                ...item.product,
                name: updates.name,
                brand: updates.brand,
                category: updates.category,
                sku: updates.sku,
                shortSummary: updates.shortSummary,
                price: updates.unitPrice,
                imageUrl: updates.imageUrl,
              },
              variant: {
                ...item.variant,
                label: updates.variantLabel,
                colorName: updates.colorName,
                colorHex: updates.colorHex,
                priceDelta: 0,
              },
            }
          : item
      )
    );
    notifyAdded(`Dettagli aggiornati per «${updates.name}»`);
  }

  async function handleImportFromUrl(
    url: string,
    addDirectly: boolean,
    room = 'Non assegnata'
  ): Promise<boolean> {
    setIsImportingUrl(true);
    setImportError(null);
    setImportWarning(null);

    try {
      const res = await fetch('/api/catalog/import-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });

      const data = (await res.json()) as {
        product?: Product;
        partial?: boolean;
        warning?: string;
        error?: string;
      };

      if (!res.ok || !data.product) {
        throw new Error(data.error || 'Impossibile leggere questo collegamento.');
      }

      const importedProduct = data.product;
      if (data.warning) {
        setImportWarning(data.warning);
      }

      if (addDirectly) {
        handleAddToPage(importedProduct, importedProduct.variants[0], room);
        window.setTimeout(() => {
          document.getElementById('riepilogo-pagina')?.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
        }, 80);
      } else {
        setPreviewProducts([importedProduct]);
        setShowResults(true);
        window.setTimeout(() => {
          resultsAnchorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 60);
      }
      return true;
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'Errore durante la lettura del link prodotto.';
      setImportError(msg);
      return false;
    } finally {
      setIsImportingUrl(false);
    }
  }

  function jumpToLinkBar() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    searchInputRef.current?.focus();
  }

  function openManualPanel(prefill = '') {
    setPrefillManualName(prefill);
    setManualPanelOpen(true);
    setImportError(null);
    setImportWarning(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function jumpToMyPage() {
    document.getElementById('riepilogo-pagina')?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  }

  return (
    <div id="top" className="min-h-screen flex flex-col bg-[#F7F7F5] text-[#141413]">
      <TopBar
        pageItemCount={totalPageCount}
        onJumpToLinkBar={jumpToLinkBar}
        onOpenManualPanel={() => openManualPanel()}
        onJumpToMyPage={jumpToMyPage}
      />

      {/* Top Link Import & Manual Workspace */}
      <section className="bg-white border-b border-[#E4E4E0]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
          <div className="max-w-4xl">
            <h1 className="text-2xl sm:text-4xl font-bold tracking-tight text-[#141413] [text-wrap:balance]">
              Incolla il link di un prodotto per aggiungerlo alla tua pagina
            </h1>
            <p className="text-sm sm:text-base text-[#5E5E59] mt-2 max-w-2xl leading-relaxed">
              Estrazione automatica di titolo, marca, categoria, colore, memoria, prezzo e foto
              direttamente dai link dei negozi, oppure inserimento manuale con assegnazione alla
              stanza.
            </p>
          </div>

          <div className="mt-6">
            <SearchBar
              query={query}
              rooms={rooms}
              savedItems={pageItems}
              isDropdownOpen={isDropdownOpen}
              isImportingUrl={isImportingUrl}
              inputRef={searchInputRef}
              onQueryChange={setQuery}
              onDropdownOpenChange={setIsDropdownOpen}
              onImportFromUrl={handleImportFromUrl}
              onOpenManualWithText={(name) => {
                openManualPanel(name);
                setQuery('');
              }}
              onJumpToMyPage={jumpToMyPage}
            />
          </div>

          <CustomImportPanel
            isOpen={manualPanelOpen}
            rooms={rooms}
            defaultRoom="Non assegnata"
            initialModelName={prefillManualName}
            onOpenChange={(open) => {
              setManualPanelOpen(open);
              if (!open) setPrefillManualName('');
            }}
            onAddCustomProduct={(product, room) => {
              handleAddToPage(product, product.variants[0], room);
              setManualPanelOpen(false);
              setPrefillManualName('');
              window.setTimeout(jumpToMyPage, 80);
            }}
          />
        </div>
      </section>

      {/* Main Content Area: Link Preview (when open) + Curated User Page Below */}
      <main className="flex-1">
        <div ref={resultsAnchorRef} />

        {showResults && previewProducts.length > 0 && (
          <SearchResults
            results={previewProducts}
            pageItems={pageItems}
            rooms={rooms}
            defaultRoom="Non assegnata"
            onAddToPage={handleAddToPage}
            onCloseResults={() => {
              setShowResults(false);
              setPreviewProducts([]);
            }}
          />
        )}

        {importError && (
          <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 pt-6">
            <div className="p-3.5 bg-[#FEF2F2] border border-[#FECACA] rounded-lg text-xs sm:text-sm text-[#991B1B] flex items-start justify-between gap-3">
              <span>{importError}</span>
              <button
                type="button"
                onClick={() => setImportError(null)}
                aria-label="Chiudi errore"
                className="p-0.5 text-[#991B1B] hover:text-[#141413] shrink-0 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {importWarning && (
          <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 pt-6">
            <div className="p-3.5 bg-[#FFFBEB] border border-[#FDE68A] rounded-lg text-xs sm:text-sm text-[#92400E] flex items-start justify-between gap-3">
              <span>{importWarning}</span>
              <button
                type="button"
                onClick={() => setImportWarning(null)}
                aria-label="Chiudi avviso"
                className="p-0.5 text-[#92400E] hover:text-[#141413] shrink-0 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        <UserPageSection
          items={pageItems}
          rooms={rooms}
          onAddRoom={handleAddRoom}
          onUpdateQuantity={handleUpdateQuantity}
          onUpdatePrice={handleUpdatePrice}
          onUpdateImage={handleUpdateImage}
          onUpdateRoom={handleUpdateRoom}
          onUpdateItemDetails={handleUpdateItemDetails}
          onRemoveItem={handleRemoveItem}
          onMoveItem={handleMoveItem}
          onClearPage={() => setPageItems([])}
          onOpenLinkPanel={jumpToLinkBar}
          onOpenManualPanel={() => openManualPanel()}
        />
      </main>

      {/* Quiet Footer */}
      <footer className="bg-white border-t border-[#E4E4E0] mt-auto">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#5E5E59]">
          <p>© {new Date().getFullYear()} Vetrina Diretta · Importazione da link e inventario stanze</p>
          <p className="tabular-nums">
            Articoli salvati nella tua pagina: {totalPageCount}
          </p>
        </div>
      </footer>

      {/* Subtle Bottom Feedback Notification when adding items */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 bg-[#141413] text-white text-xs sm:text-sm font-medium px-4 py-3 rounded-lg shadow-lg flex items-center gap-2.5 max-w-sm"
        >
          <Check className="w-4 h-4 text-[#F59E0B] shrink-0" aria-hidden="true" />
          <span className="truncate">{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
