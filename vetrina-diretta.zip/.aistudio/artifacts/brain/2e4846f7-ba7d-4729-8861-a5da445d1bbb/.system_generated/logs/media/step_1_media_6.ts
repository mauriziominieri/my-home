import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

interface NormalizedProduct {
  id: string;
  sku: string;
  name: string;
  brand: string;
  category: string;
  searchPriority: number;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  availability: string;
  deliveryText: string;
  warranty: string;
  imageUrl?: string;
  visualKind: string;
  shortSummary: string;
  highlights: string[];
  specs: Array<{ label: string; value: string }>;
  boxContents: string[];
  colorOptions?: Array<{ id: string; name: string; hex: string }>;
  variants: Array<{
    id: string;
    label: string;
    colorName: string;
    colorHex: string;
    priceDelta: number;
  }>;
  keywords: string[];
}


function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY_MISSING');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}


function isSafeExternalUrl(rawUrl: string): URL | null {
  try {
    const parsed = new URL(rawUrl.trim());
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
    if (parsed.port && parsed.port !== '80' && parsed.port !== '443') return null;

    const host = parsed.hostname.toLowerCase();
    if (
      host === 'localhost' ||
      host === '0.0.0.0' ||
      host === '::1' ||
      host.endsWith('.local') ||
      host.endsWith('.internal')
    ) {
      return null;
    }

    // Block private IPv4 ranges
    const ipv4 = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
    if (ipv4) {
      const a = Number(ipv4[1]);
      const b = Number(ipv4[2]);
      if (
        a === 10 ||
        a === 127 ||
        a === 0 ||
        (a === 169 && b === 254) ||
        (a === 172 && b >= 16 && b <= 31) ||
        (a === 192 && b === 168)
      ) {
        return null;
      }
    }

    return parsed;
  } catch {
    return null;
  }
}

function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function inferBrandFromHost(hostname: string): string {
  const h = hostname.toLowerCase().replace(/^www\./, '');
  if (h.includes('ikea.')) return 'IKEA';
  if (h.includes('federicisofa.')) return 'Federici Sofà';
  if (h.includes('venetacucine.')) return 'Veneta Cucine';
  if (h.includes('maisonsdumonde.')) return 'Maisons du Monde';
  if (h.includes('tcl.')) return 'TCL';
  if (h.includes('samsung.')) return 'Samsung';
  if (h.includes('apple.')) return 'Apple';
  if (h.includes('windtre.')) return 'WindTre';
  if (h.includes('bticino.')) return 'BTicino';
  if (h.includes('febalcasa.')) return 'Febal Casa';
  if (h.includes('electrolux.')) return 'Electrolux';
  if (h.includes('leroymerlin.')) return 'Leroy Merlin';
  if (h.includes('mediaworld.')) return 'MediaWorld';
  if (h.includes('unieuro.')) return 'Unieuro';
  if (h.includes('amazon.')) return 'Amazon';
  const main = h.split('.')[0] || 'Web';
  return main.charAt(0).toUpperCase() + main.slice(1);
}

function inferManufacturerFromText(text: string): string | undefined {
  const t = text.toLowerCase();
  const known: Array<[RegExp, string]> = [
    [/\b(iphone|ipad|macbook|apple|airpods|imac)\b/, 'Apple'],
    [/\b(galaxy|samsung)\b/, 'Samsung'],
    [/\btcl\b/, 'TCL'],
    [/\belectrolux\b/, 'Electrolux'],
    [/\bbticino\b/, 'BTicino'],
    [/\bwind\s*tre\b|\bwindtre\b/, 'WindTre'],
    [/\bfederici\b/, 'Federici Sofà'],
    [/\bveneta cucine\b/, 'Veneta Cucine'],
    [/\bfebal\b/, 'Febal Casa'],
    [/\bmaisons du monde\b/, 'Maisons du Monde'],
    [/\bikea\b/, 'IKEA'],
    [/\bibanez\b/, 'Ibanez'],
    [/\bsony\b/, 'Sony'],
    [/\bdyson\b/, 'Dyson'],
    [/\bnintendo\b/, 'Nintendo'],
    [/\bkindle\b/, 'Amazon Kindle'],
    [/\bgarmin\b/, 'Garmin'],
    [/\blogitech\b/, 'Logitech'],
    [/\bbose\b/, 'Bose'],
    [/\bdji\b/, 'DJI'],
    [/\bphilips\b/, 'Philips'],
  ];
  for (const [re, brand] of known) {
    if (re.test(t)) return brand;
  }
  return undefined;
}

const SERVER_COLOR_RULES: Array<[RegExp, string]> = [
  [/\b(arancione\s*cosmico|cosmic\s*orange)\b/, '#D96B27'],
  [/\b(oro\s*rosa|rose\s*gold|pink\s*gold)\b/, '#C99588'],
  [/\b(blu\s*(?:notte|mezzanotte)|midnight(?:\s*blue)?|mezzanotte)\b/, '#1A2438'],
  [/\b(blu\s*(?:profondo|marino|scuro)|deep\s*blue|dark\s*blue|navy)\b/, '#1F2F4C'],
  [/\b(blu\s*(?:cobalto|elettrico|zaffiro)|cobalto|cobalt|zaffiro|sapphire|ultramarino|oltremare)\b/, '#1E4D9B'],
  [/\b(carta\s*da\s*zucchero|avio|denim|jeans)\b/, '#52728F'],
  [/\b(verde\s*petrolio|petrolio|ottanio|teal|pavone)\b/, '#1C5D68'],
  [/\b(verde\s*(?:bosco|abete|pino|scuro)|forest\s*green|dark\s*green)\b/, '#244C38'],
  [/\b(verde\s*militare|militare|oliva|olive|muschio|moss|kaki|khaki|cachi)\b/, '#55613C'],
  [/\b(verde\s*smeraldo|smeraldo|emerald|giada|jade)\b/, '#257A57'],
  [/\b(verde\s*salvia|salvia|sage|eucalipto)\b/, '#7A9482'],
  [/\b(verde\s*menta|menta|mint|pistacchio|pistachio|acquamarina|tiffany)\b/, '#74B89E'],
  [/\b(verde\s*acqua)\b/, '#5FA395'],
  [/\b(rosa\s*(?:antico|cipria)|cipria|dusty\s*rose|blush)\b/, '#CFA1A6'],
  [/\b(titanio\s*naturale|natural\s*titanium)\b/, '#A8A59E'],
  [/\b(titanio\s*nero|black\s*titanium|canna\s*di\s*fucile|gunmetal)\b/, '#525458'],
  [/\b(grigio\s*(?:siderale|scuro)|space\s*gr[ae]y|dark\s*gr[ae]y|piombo|fumo)\b/, '#5A5D64'],
  [/\b(bianco\s*caldo|off\s*white)\b/, '#EDE8DC'],

  [/\b(borgogna|burgundy|bordeaux|vinaccia|sangria|chianti|barolo|amarone)\b/, '#7A1C2E'],
  [/\b(granata|garnet)\b/, '#7B1E26'],
  [/\b(amaranto|crimson|cremisi|carminio|rubino|ruby|ciliegia|cherry)\b/, '#9E1B32'],
  [/\b(melanzana|aubergine|eggplant)\b/, '#4E2340'],
  [/\b(prugna|plum)\b/, '#5E2B4E'],
  [/\b(lampone|raspberry|fragola|strawberry)\b/, '#B8294B'],
  [/\b(terracotta|mattone|brick|coccio)\b/, '#B55239'],
  [/\b(ruggine|rust)\b/, '#9E472A'],
  [/\b(corallo|coral)\b/, '#E06553'],
  [/\b(salmone|salmon)\b/, '#E58975'],

  [/\b(pesca|peach|albicocca|apricot)\b/, '#F0A678'],
  [/\b(ambra|amber|miele|honey|caramello|caramel)\b/, '#C97A2B'],
  [/\b(senape|mustard|ocra|ochre|curcuma|zafferano)\b/, '#C79326'],
  [/\b(champagne|starlight|galassia)\b/, '#DFD3BE'],
  [/\b(ottone|brass|ottonato)\b/, '#C5A059'],
  [/\b(lime|cedro|chartreuse)\b/, '#9AB83B'],

  [/\b(turchese|turquoise|ciano|cyan)\b/, '#249EA8'],
  [/\b(azzurro|celeste|sky\s*blue|light\s*blue|ghiaccio)\b/, '#6AA7D9'],
  [/\b(fucsia|fuchsia|magenta)\b/, '#B8296B'],
  [/\b(indaco|indigo|mora)\b/, '#4B2E6E'],
  [/\b(lavanda|lavender|lilla|lilac|glicine|pervinca|malva|mauve|orchidea)\b/, '#A38DB8'],

  [/\b(wenge|ebano|ebony|palissandro)\b/, '#3D2B22'],
  [/\b(caffe|coffee|espresso|cioccolato|chocolate|cacao)\b/, '#4E3529'],
  [/\b(mogano|mahogany|castagno|chestnut)\b/, '#6E3B2B'],
  [/\b(cuoio|cognac|tabacco|leather|saddle|nocciola|noce|walnut)\b/, '#855436'],
  [/\b(teak|rovere|quercia|oak|legno|wood|faggio|frassino|betulla|bambu)\b/, '#B58F63'],
  [/\b(cammello|camel|taupe|tortora|talpa|visone|marrone|brown)\b/, '#7F614A'],
  [/\b(sabbia|sand|beige|canapa|lino|ecru|crema|cream)\b/, '#CFC1AA'],
  [/\b(rame|copper)\b/, '#B86B43'],
  [/\b(bronzo|bronze)\b/, '#7D5C3E'],
  [/\b(titanio|titanium)\b/, '#7A7C80'],
  [/\b(antracite|anthracite|grafite|graphite|carbone|charcoal|ossidiana|onice|ardesia)\b/, '#36383E'],
  [/\b(argento|silver|inox|acciaio|steel|cromo|cromato|chrome|platino|platinum|alluminio)\b/, '#C5C8CE'],
  [/\b(avorio|ivory|panna|perla|pearl)\b/, '#EDE8DC'],

  [/\b(arancione|arancio|orange|mandarino|tangerine|zucca|cosmico)\b/, '#E06D22'],
  [/\b(rosso|red|scarlatto|vermiglio)\b/, '#B82828'],
  [/\b(oro|gold|dorato)\b/, '#D4AF37'],
  [/\b(giallo|yellow|limone|lemon|canarino)\b/, '#E2B729'],
  [/\b(verde|green|acqua)\b/, '#38764B'],
  [/\b(blu|blue|marino)\b/, '#25539B'],
  [/\b(viola|violetto|violet|purple)\b/, '#764B9E'],
  [/\b(rosa|pink)\b/, '#D9829B'],
  [/\b(grigio|gr[ae]y|cemento|concrete|cenere|pietra)\b/, '#8D9096'],
  [/\b(bianco|white|neve|snow|latte)\b/, '#F2F2EE'],
  [/\b(nero|black|corvino)\b/, '#1C1D20'],
];

function inferColorHex(colorName: string): string {
  const normalized = colorName
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
  if (!normalized) return '#2B2C30';
  for (const [pattern, hex] of SERVER_COLOR_RULES) {
    if (pattern.test(normalized)) return hex;
  }
  return '#2B2C30';
}

function inferCategoryAndVisual(
  rawCat: string,
  title: string
): { category: string; visualKind: string } {
  const text = `${rawCat} ${title}`.toLowerCase();
  if (
    text.includes('lampad') ||
    text.includes('sospensione') ||
    text.includes('plafoniera') ||
    text.includes('abat-jour') ||
    text.includes('illuminazione')
  ) {
    return { category: 'Arredamento', visualKind: 'lighting' };
  }
  if (text.includes('divan') || text.includes('sofà') || text.includes('sofa') || text.includes('poltrona')) {
    return { category: 'Arredamento', visualKind: 'sofa' };
  }
  if (text.includes('cucin') && !text.includes('piano cottura') && !text.includes('forno')) {
    return { category: 'Arredamento', visualKind: 'kitchen' };
  }
  if (
    text.includes('libreria') ||
    text.includes('scaffale') ||
    text.includes('armadio') ||
    text.includes('letto') ||
    text.includes('tavolo') ||
    text.includes('sedia') ||
    text.includes('mobile') ||
    text.includes('specchio') ||
    text.includes('credenza') ||
    text.includes('statuetta') ||
    text.includes('scultura') ||
    text.includes('busto') ||
    text.includes('vaso') ||
    text.includes('quadro') ||
    text.includes('tappeto') ||
    text.includes('decor')
  ) {
    return { category: 'Arredamento', visualKind: 'furniture' };
  }
  if (text.includes('tv') || text.includes('oled') || text.includes('qled') || text.includes('televisore')) {
    return { category: 'Casa & Gaming', visualKind: 'tv' };
  }
  if (
    text.includes('lavatrice') ||
    text.includes('asciugatrice') ||
    text.includes('lavastoviglie') ||
    text.includes('frigo') ||
    text.includes('forno') ||
    text.includes('induzione') ||
    text.includes('climatizzatore')
  ) {
    return { category: 'Elettrodomestici', visualKind: 'appliance' };
  }
  if (text.includes('router') || text.includes('modem') || text.includes('mesh') || text.includes('wifi')) {
    return { category: 'Domotica & Rete', visualKind: 'router' };
  }
  if (
    text.includes('bticino') ||
    text.includes('termostato') ||
    text.includes('placca') ||
    text.includes('videocitofono') ||
    text.includes('presa')
  ) {
    return { category: 'Domotica & Rete', visualKind: 'smarthome' };
  }
  if (text.includes('iphone') || text.includes('smartphone') || text.includes('galaxy')) {
    return { category: 'Smartphone', visualKind: 'phone-pro' };
  }
  if (text.includes('ipad') || text.includes('tablet')) {
    return { category: 'Tablet', visualKind: 'tablet-pro' };
  }
  if (text.includes('macbook') || text.includes('laptop') || text.includes('notebook')) {
    return { category: 'Computer', visualKind: 'laptop-pro' };
  }
  if (text.includes('chitarra') || text.includes('basso')) {
    return { category: 'Strumenti Musicali', visualKind: 'guitar' };
  }
  if (text.includes('cuffie') || text.includes('auricolari') || text.includes('soundbar')) {
    return { category: 'Audio', visualKind: 'headphones' };
  }
  return { category: 'Casa & Gaming', visualKind: 'generic-product' };
}

function extractMetaTag(html: string, attrName: string, attrValue: string): string | undefined {
  const re1 = new RegExp(
    `<meta[^>]*${attrName}=["']${attrValue}["'][^>]*content=["']([^"']+)["'][^>]*>`,
    'i'
  );
  const re2 = new RegExp(
    `<meta[^>]*content=["']([^"']+)["'][^>]*${attrName}=["']${attrValue}["'][^>]*>`,
    'i'
  );
  const match = html.match(re1) || html.match(re2);
  return match?.[1] ? decodeHtmlEntities(match[1]) : undefined;
}

function findProductLdNodes(node: unknown, out: Array<Record<string, unknown>>): void {
  if (!node || typeof node !== 'object') return;
  if (Array.isArray(node)) {
    for (const item of node) findProductLdNodes(item, out);
    return;
  }
  const obj = node as Record<string, unknown>;
  const nodeType = obj['@type'];
  const isProduct =
    nodeType === 'Product' ||
    (Array.isArray(nodeType) && nodeType.includes('Product'));
  if (isProduct) {
    out.push(obj);
  }
  if (Array.isArray(obj['@graph'])) {
    findProductLdNodes(obj['@graph'], out);
  }
}

function buildUrlFallbackFromSlug(parsedUrl: URL): NormalizedProduct {
  const brand = inferBrandFromHost(parsedUrl.hostname);
  const segments = parsedUrl.pathname.split('/').filter(Boolean);
  const rawSlug = (segments[segments.length - 1] || segments[segments.length - 2] || 'Articolo')
    .replace(/\.html?$/i, '');

  const skuMatch = rawSlug.match(/[-_](\d{5,12})$/);
  const extractedSku = skuMatch?.[1];
  const nameSlug = extractedSku ? rawSlug.slice(0, -extractedSku.length - 1) : rawSlug;

  const cleanedName = nameSlug
    .replace(/[-_]+/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();

  const lowerName = cleanedName.toLowerCase();
  const { category, visualKind } = inferCategoryAndVisual('', cleanedName);
  const sku = extractedSku || `URL-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;

  const materialMatch = lowerName.match(
    /\b(?:in|di)\s+(cemento|legno|vetro|metallo|ottone|ferro|ceramica|porcellana|tessuto|velluto|pelle|lino|cotone|marmo|resina|plastica|acciaio|bambu|bambù)\b/i
  );
  const detectedMaterial = materialMatch?.[1]
    ? materialMatch[1].charAt(0).toUpperCase() + materialMatch[1].slice(1)
    : undefined;

  const dimMatch = lowerName.match(
    /\b(?:alt(?:ezza)?\s*)?(\d+(?:\s*[x×]\s*\d+)*\s*(?:cm|mm|m))\b/i
  );
  const detectedDim = dimMatch?.[0]
    ? dimMatch[0].replace(/\balt\b/i, 'Altezza').replace(/\s+/g, ' ').trim()
    : undefined;

  const specs: Array<{ label: string; value: string }> = [
    { label: 'Marca', value: brand },
    { label: 'Codice / SKU', value: sku },
  ];
  if (detectedMaterial) specs.push({ label: 'Materiale rilevato', value: detectedMaterial });
  if (detectedDim) specs.push({ label: 'Dimensioni rilevate', value: detectedDim });
  specs.push({ label: 'Link sorgente', value: parsedUrl.hostname.replace(/^www\./, '') });
  specs.push({ label: 'Collegamento originale', value: parsedUrl.href });

  const detailBits = [detectedMaterial, detectedDim].filter(Boolean).join(' · ');

  return {
    id: `url-${sku.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now()}`,
    sku,
    name: cleanedName || `Articolo ${brand}`,
    brand,
    category,
    searchPriority: 95,
    price: 0,
    rating: 4.7,
    reviewCount: 1,
    availability: 'Link importato (sito protetto)',
    deliveryText: `Fonte: ${parsedUrl.hostname.replace(/^www\./, '')}`,
    warranty: 'Verifica garanzia sul sito del venditore',
    visualKind,
    shortSummary: `${cleanedName || 'Articolo'} — ${brand}${
      detailBits ? ` (${detailBits})` : ''
    }. Il sito protegge la pagina con filtro anti-bot: puoi inserire prezzo e link foto direttamente nella card.`,
    highlights: [
      `Marca: ${brand}`,
      ...(extractedSku ? [`Codice articolo dal link: ${extractedSku}`] : []),
      ...(detectedMaterial ? [`Materiale: ${detectedMaterial}`] : []),
      ...(detectedDim ? [`Misure: ${detectedDim}`] : []),
      `Collegamento salvato: ${parsedUrl.hostname.replace(/^www\./, '')}`,
    ],
    specs,
    boxContents: [cleanedName || `Articolo ${brand}`],
    variants: [
      {
        id: 'url-std',
        label: 'Modello da link',
        colorName: detectedMaterial || 'Come da pagina prodotto',
        colorHex: '#2B2C30',
        priceDelta: 0,
      },
    ],
    keywords: [brand.toLowerCase(), cleanedName.toLowerCase(), sku.toLowerCase()],
  };
}

async function verifyImageUrl(candidateUrl: unknown): Promise<string | undefined> {
  if (typeof candidateUrl !== 'string') return undefined;
  const safe = isSafeExternalUrl(candidateUrl);
  if (!safe) return undefined;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 3000);
  try {
    const res = await fetch(safe.href, {
      method: 'GET',
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        Accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
      },
    });
    if (!res.ok) return undefined;
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.toLowerCase().startsWith('image/')) return undefined;
    return safe.href;
  } catch {
    return undefined;
  } finally {
    clearTimeout(timeout);
  }
}

function extractJsonObject(rawText: string): Record<string, unknown> | null {
  const cleaned = rawText
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();

  try {
    const parsed = JSON.parse(cleaned);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>;
    }
  } catch {
    // Try extracting first {...} block
  }

  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start !== -1 && end > start) {
    try {
      const parsed = JSON.parse(cleaned.slice(start, end + 1));
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        return parsed as Record<string, unknown>;
      }
    } catch {
      return null;
    }
  }
  return null;
}

async function enrichBlockedUrlWithSearch(
  parsedUrl: URL,
  baseProduct: NormalizedProduct
): Promise<NormalizedProduct | null> {
  try {
    const ai = getAiClient();
    const prompt = `Cerca su Google informazioni reali su questo prodotto specifico in vendita online:
URL: ${parsedUrl.href}
Marca probabile: ${baseProduct.brand}
Titolo ricavato dal link: ${baseProduct.name}
Codice / SKU probabile: ${baseProduct.sku}

Restituisci ESCLUSIVAMENTE un oggetto JSON valido (senza testo aggiuntivo) con i dati reali trovati in italiano:
{
  "name": "nome esatto completo del prodotto",
  "brand": "marca ufficiale",
  "category": "una categoria tra: Arredamento, Casa & Gaming, Elettrodomestici, Smartphone, Tablet, Computer, Audio, Wearable, Fotografia, Strumenti Musicali, Sport & Tempo Libero, Fai da te, Domotica & Rete",
  "price": numero prezzo attuale in Euro (es. 29.99, usa 0 solo se introvabile),
  "originalPrice": numero opzionale se scontato oppure null,
  "sku": "codice prodotto / referenza reale",
  "colorName": "colore o finitura principale",
  "colorHex": "codice esadecimale reale del colore (es. #7A1C2E per Borgogna, #D96B27 per Arancione cosmico)",
  "material": "materiale principale",
  "dimensions": "dimensioni reali (es. Altezza 30 cm × Larghezza 18 cm)",
  "shortSummary": "descrizione dettagliata in italiano di 2-3 frasi basata sulle caratteristiche reali",
  "highlights": ["punto chiave 1", "punto chiave 2", "punto chiave 3"],
  "specs": [{"label": "nome specifica", "value": "valore"}],
  "boxContents": ["contenuto confezione"],
  "imageUrl": "URL diretto https:// ad un'immagine reale del prodotto trovata nei risultati, oppure stringa vuota se non disponibile"
}`;

    const attemptModels = ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'];
    let responseText = '';

    for (let i = 0; i < attemptModels.length; i++) {
      try {
        const modelName = attemptModels[i];
        const res = await ai.models.generateContent({
          model: modelName,
          contents: prompt,
          config: {
            tools: [{ googleSearch: {} }],
            ...(modelName === 'gemini-4-hydrogen'
              ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
              : {}),
          },
        });
        responseText = res.text ?? '';
        if (responseText.trim()) break;
      } catch (err) {
        if (i === attemptModels.length - 1) throw err;
      }
    }

    const parsed = extractJsonObject(responseText);
    if (!parsed) return null;

    const verifiedImg = await verifyImageUrl(parsed.imageUrl);
    const name = typeof parsed.name === 'string' && parsed.name.trim() ? parsed.name.trim() : baseProduct.name;
    const rawParsedBrand = typeof parsed.brand === 'string' && parsed.brand.trim() ? parsed.brand.trim() : '';
    const brand =
      (rawParsedBrand && rawParsedBrand.toLowerCase() !== 'amazon' ? rawParsedBrand : undefined) ||
      inferManufacturerFromText(name) ||
      rawParsedBrand ||
      baseProduct.brand;
    const { category, visualKind } = inferCategoryAndVisual(
      typeof parsed.category === 'string' ? parsed.category : '',
      name
    );

    const rawPrice = Number(parsed.price);
    const price = Number.isFinite(rawPrice) && rawPrice > 0 ? Number(rawPrice.toFixed(2)) : 0;
    const rawOrig = Number(parsed.originalPrice);
    const originalPrice =
      price > 0 && Number.isFinite(rawOrig) && rawOrig > price
        ? Number(rawOrig.toFixed(2))
        : undefined;

    const sku =
      typeof parsed.sku === 'string' && parsed.sku.trim() ? parsed.sku.trim() : baseProduct.sku;
    const colorName =
      typeof parsed.colorName === 'string' && parsed.colorName.trim()
        ? parsed.colorName.trim()
        : 'Originale';
    const aiColorHex =
      typeof parsed.colorHex === 'string' && /^#[0-9a-fA-F]{6}$/.test(parsed.colorHex.trim())
        ? parsed.colorHex.trim().toUpperCase()
        : '';
    const dictColorHex = inferColorHex(colorName);
    const colorHex = dictColorHex !== '#2B2C30' ? dictColorHex : aiColorHex || dictColorHex;
    const detectedSize = name.match(/\b(\d+\s*(?:GB|TB))\b/i)?.[1] || 'Modello da link';
    const shortSummary =
      typeof parsed.shortSummary === 'string' && parsed.shortSummary.trim()
        ? parsed.shortSummary.trim()
        : baseProduct.shortSummary;

    const specs: Array<{ label: string; value: string }> = [
      { label: 'Marca', value: brand },
      { label: 'Codice / SKU', value: sku },
    ];
    if (typeof parsed.material === 'string' && parsed.material.trim()) {
      specs.push({ label: 'Materiale', value: parsed.material.trim() });
    }
    if (typeof parsed.dimensions === 'string' && parsed.dimensions.trim()) {
      specs.push({ label: 'Dimensioni', value: parsed.dimensions.trim() });
    }
    if (colorName !== 'Originale') {
      specs.push({ label: 'Colore / Finitura', value: colorName });
    }
    if (Array.isArray(parsed.specs)) {
      for (const s of parsed.specs) {
        if (s && typeof s === 'object' && 'label' in s && 'value' in s) {
          const lbl = String((s as Record<string, unknown>).label || '').trim();
          const val = String((s as Record<string, unknown>).value || '').trim();
          if (lbl && val && !specs.some((existing) => existing.label.toLowerCase() === lbl.toLowerCase())) {
            specs.push({ label: lbl, value: val });
          }
        }
      }
    }
    specs.push({ label: 'Link sorgente', value: parsedUrl.hostname.replace(/^www\./, '') });
    specs.push({ label: 'Collegamento originale', value: parsedUrl.href });

    const highlights = Array.isArray(parsed.highlights)
      ? parsed.highlights.map(String).filter(Boolean).slice(0, 5)
      : baseProduct.highlights;

    const boxContents = Array.isArray(parsed.boxContents)
      ? parsed.boxContents.map(String).filter(Boolean)
      : [name];

    return {
      ...baseProduct,
      id: `url-${sku.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now()}`,
      sku,
      name,
      brand,
      category:
        typeof parsed.category === 'string' && parsed.category.trim()
          ? parsed.category.trim()
          : category,
      price,
      originalPrice,
      imageUrl: verifiedImg,
      visualKind,
      shortSummary,
      highlights: highlights.length > 0 ? highlights : baseProduct.highlights,
      specs,
      boxContents: boxContents.length > 0 ? boxContents : [name],
      variants: [
        {
          id: 'imported',
          label: detectedSize,
          colorName,
          colorHex,
          priceDelta: 0,
        },
      ],
      keywords: [brand.toLowerCase(), name.toLowerCase(), sku.toLowerCase()],
    };
  } catch (err) {
    console.warn('[import-url] Search enrichment failed:', err instanceof Error ? err.message : err);
    return null;
  }
}

function parseEuroPriceText(raw: string): number {
  const cleaned = raw.replace(/\s+/g, '').replace(/[^0-9.,]/g, '');
  if (!cleaned) return 0;
  // Italian format e.g. 1.849,00 or 149,99
  if (cleaned.includes(',')) {
    const normalized = cleaned.replace(/\./g, '').replace(',', '.');
    const num = Number(normalized);
    return Number.isFinite(num) ? num : 0;
  }
  const num = Number(cleaned);
  return Number.isFinite(num) ? num : 0;
}

function extractAmazonAsin(parsedUrl: URL, html?: string): string | undefined {
  const fromPath = parsedUrl.pathname.match(/\/(?:dp|gp\/(?:product|aw\/d))\/([A-Z0-9]{10})/i)?.[1];
  if (fromPath) return fromPath.toUpperCase();
  if (html) {
    const fromHtml = html.match(/data-asin=["']([A-Z0-9]{10})["']/i)?.[1];
    if (fromHtml) return fromHtml.toUpperCase();
  }
  return undefined;
}

function isAmazonChallengeHtml(html: string, parsedUrl: URL): boolean {
  if (!parsedUrl.hostname.toLowerCase().includes('amazon.')) return false;
  const hasProductMarkup =
    /id=["'](?:productTitle|title)["']/i.test(html) &&
    /id=["'](?:landingImage|main-image|corePriceDisplay_desktop_feature_div|corePriceDisplay_mobile_feature_div|bylineInfo)["']/i.test(html);
  if (hasProductMarkup) return false;
  if (html.length < 25000) return true;
  if (/validateCaptcha|opfcaptcha|<title[^>]*>\s*(?:Amazon\.[a-z.]+|Ci dispiace|Sorry)/i.test(html)) {
    return true;
  }
  return false;
}

function parseAmazonProductHtml(html: string, parsedUrl: URL): NormalizedProduct | null {
  if (!parsedUrl.hostname.toLowerCase().includes('amazon.')) return null;
  if (isAmazonChallengeHtml(html, parsedUrl)) return null;

  const desktopTitleMatch = html.match(/id=["']productTitle["'][^>]*>([\s\S]*?)<\/span>/i);
  const mobileTitleRaw = html.match(/<h1[^>]*id=["']title["'][^>]*>([\s\S]*?)<\/h1>/i)?.[1];
  const mobileTitleClean = mobileTitleRaw
    ? decodeHtmlEntities(mobileTitleRaw.replace(/<input[\s\S]*$/i, '').replace(/<[^>]+>/g, ' '))
    : '';
  const htmlTitleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const rawPageTitle = htmlTitleMatch?.[1]
    ? decodeHtmlEntities(htmlTitleMatch[1]).replace(/\s*:\s*Amazon\.[a-z.]+.*$/i, '').trim()
    : '';
  const rawTitle =
    (desktopTitleMatch?.[1] ? decodeHtmlEntities(desktopTitleMatch[1]) : '') ||
    mobileTitleClean ||
    rawPageTitle;

  if (
    !rawTitle ||
    /^(?:amazon\.[a-z.]+|ci dispiace|sorry)$/i.test(rawTitle) ||
    /captcha|robot check/i.test(rawTitle)
  ) {
    return null;
  }

  const asin =
    extractAmazonAsin(parsedUrl, html) ||
    `AMZ-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

  // Extract overview table specs (#productOverview_feature_div)
  const overviewMap = new Map<string, string>();
  const overviewBlock = html.match(/id=["']productOverview_feature_div["'][\s\S]{0,12000}/i)?.[0] || '';
  const rowMatches = overviewBlock.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi);
  for (const row of rowMatches) {
    const cells = Array.from(row[1].matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)).map((c) =>
      decodeHtmlEntities(c[1].replace(/<[^>]+>/g, ' '))
    );
    if (cells.length >= 2 && cells[0] && cells[1]) {
      overviewMap.set(cells[0], cells[1]);
    }
  }

  // Brand resolution: Overview "Marchio" -> #bylineInfo -> inferred from title
  const overviewBrand = overviewMap.get('Marchio') || overviewMap.get('Marca') || overviewMap.get('Brand');
  const bylineRaw = html.match(/id=["']bylineInfo["'][^>]*>([\s\S]*?)<\/a>/i)?.[1];
  const bylineClean = bylineRaw
    ? decodeHtmlEntities(bylineRaw)
        .replace(/^Visita lo Store di\s+/i, '')
        .replace(/^Visit the\s+/i, '')
        .replace(/\s+Store$/i, '')
        .replace(/^Marca:\s*/i, '')
        .replace(/^Brand:\s*/i, '')
        .trim()
    : '';

  const brand =
    overviewBrand ||
    bylineClean ||
    inferManufacturerFromText(rawTitle) ||
    'Amazon';

  // Breadcrumbs for category inference
  const breadcrumbBlock =
    html.match(/id=["']wayfinding-breadcrumbs_feature_div["'][\s\S]{0,3000}/i)?.[0] || '';
  const breadcrumbText = decodeHtmlEntities(breadcrumbBlock.replace(/<[^>]+>/g, ' '));
  const overviewJoined = Array.from(overviewMap.entries())
    .map(([k, v]) => `${k} ${v}`)
    .join(' ');
  const { category, visualKind } = inferCategoryAndVisual(
    `${breadcrumbText} ${overviewJoined}`,
    rawTitle
  );

  // Price extraction (desktop OR mobile feature divs)
  const priceBlock =
    html.match(/id=["']corePriceDisplay_desktop_feature_div["'][\s\S]{0,6000}/i)?.[0] ||
    html.match(/id=["']corePriceDisplay_mobile_feature_div["'][\s\S]{0,6000}/i)?.[0] ||
    html.match(/id=["']corePrice_feature_div["'][\s\S]{0,6000}/i)?.[0] ||
    '';

  let priceNum = 0;
  const wholeMatch = priceBlock.match(/class=["']a-price-whole["'][^>]*>([^<]+)/i);
  const fracMatch = priceBlock.match(/class=["']a-price-fraction["'][^>]*>([^<]+)/i);
  if (wholeMatch?.[1]) {
    const combined = `${wholeMatch[1].replace(/[^0-9.]/g, '')},${fracMatch?.[1]?.replace(/[^0-9]/g, '') || '00'}`;
    priceNum = parseEuroPriceText(combined);
  }
  if (!priceNum) {
    const offscreenMatches = Array.from(
      priceBlock.matchAll(/class=["'][^"']*(?:a-offscreen|aok-offscreen)[^"']*["'][^>]*>([\s\S]*?)<\/span>/gi)
    );
    for (const m of offscreenMatches) {
      const candidate = parseEuroPriceText(decodeHtmlEntities(m[1]));
      if (candidate > 0) {
        priceNum = candidate;
        break;
      }
    }
  }

  let originalPrice: number | undefined;
  const basisMatch = priceBlock.match(
    /basisPrice[\s\S]{0,400}?class=["']a-offscreen["'][^>]*>([^<]+)</i
  );
  if (basisMatch?.[1]) {
    const parsedBasis = parseEuroPriceText(decodeHtmlEntities(basisMatch[1]));
    if (parsedBasis > priceNum && priceNum > 0) {
      originalPrice = parsedBasis;
    }
  }

  // Image extraction (hi-res desktop landingImage OR mobile main-image)
  const landingHiRes = html.match(/id=["']landingImage["'][^>]*data-old-hires=["']([^"']+)["']/i)?.[1];
  const anyOldHiRes = html.match(/data-old-hires=["'](https:\/\/m\.media-amazon\.com\/images\/I\/[^"']+)["']/i)?.[1];
  const mobileMainHiRes = html.match(/id=["']main-image["'][^>]*data-a-hires=["']([^"']+)["']/i)?.[1];
  const anyDataAHires = html.match(/data-a-hires=["'](https:\/\/m\.media-amazon\.com\/images\/I\/[^"']+)["']/i)?.[1];
  const jsonHiRes = html.match(/"hiRes"\s*:\s*"(https:\/\/m\.media-amazon\.com\/images\/I\/[^"]+)"/i)?.[1];
  const landingSrc = html.match(/id=["'](?:landingImage|main-image)["'][^>]*src=["'](https:\/\/[^"']+)["']/i)?.[1];
  const imageUrl =
    landingHiRes || anyOldHiRes || mobileMainHiRes || anyDataAHires || jsonHiRes || landingSrc;

  // Color & Size extraction (twister dimensions + variationValues JSON)
  const twisterColor = html.match(
    /id=["']inline-twister-expanded-dimension-text-color_name["'][^>]*>([^<]+)</i
  )?.[1];
  const selectedColorName = decodeHtmlEntities(
    twisterColor || overviewMap.get('Colore') || overviewMap.get('Color') || ''
  );

  const twisterSize = html.match(
    /id=["']inline-twister-expanded-dimension-text-size_name["'][^>]*>([^<]+)</i
  )?.[1];
  const titleSizeMatch = rawTitle.match(/\b(\d+\s*(?:GB|TB))\b/i)?.[1];
  const selectedSizeName = decodeHtmlEntities(
    twisterSize ||
      overviewMap.get('Capacità della memoria') ||
      overviewMap.get('Dimensioni') ||
      titleSizeMatch ||
      ''
  );

  let colorOptions: Array<{ id: string; name: string; hex: string }> | undefined;
  let variantList: Array<{
    id: string;
    label: string;
    colorName: string;
    colorHex: string;
    priceDelta: number;
  }> = [];

  const varValuesMatch = html.match(/"variationValues"\s*:\s*(\{[^}]*(?:\{[^}]*\}[^}]*)*\})/);
  if (varValuesMatch?.[1]) {
    try {
      const parsedVars = JSON.parse(varValuesMatch[1]) as {
        color_name?: string[];
        size_name?: string[];
      };
      if (Array.isArray(parsedVars.color_name) && parsedVars.color_name.length > 0) {
        const orderedColors = parsedVars.color_name.map((c) => decodeHtmlEntities(String(c)));
        if (selectedColorName) {
          orderedColors.sort((a, b) =>
            a.toLowerCase() === selectedColorName.toLowerCase()
              ? -1
              : b.toLowerCase() === selectedColorName.toLowerCase()
              ? 1
              : 0
          );
        }
        colorOptions = orderedColors.map((name, i) => ({
          id: `amz-col-${i}`,
          name,
          hex: inferColorHex(name),
        }));
      }
      if (Array.isArray(parsedVars.size_name) && parsedVars.size_name.length > 0) {
        const orderedSizes = parsedVars.size_name.map((s) => decodeHtmlEntities(String(s)));
        if (selectedSizeName) {
          orderedSizes.sort((a, b) =>
            a.toLowerCase() === selectedSizeName.toLowerCase()
              ? -1
              : b.toLowerCase() === selectedSizeName.toLowerCase()
              ? 1
              : 0
          );
        }
        const activeHex = inferColorHex(selectedColorName || 'Originale');
        variantList = orderedSizes.map((label, i) => ({
          id: `amz-sz-${i}`,
          label,
          colorName: selectedColorName || 'Originale',
          colorHex: activeHex,
          priceDelta: 0,
        }));
      }
    } catch {
      // Ignore partial variation JSON
    }
  }

  const finalColorName = selectedColorName || colorOptions?.[0]?.name || 'Originale';
  const finalColorHex = inferColorHex(finalColorName);

  if (variantList.length === 0) {
    variantList = [
      {
        id: 'imported',
        label: selectedSizeName || 'Versione Amazon',
        colorName: finalColorName,
        colorHex: finalColorHex,
        priceDelta: 0,
      },
    ];
  }

  // Rating & Review count (desktop OR mobile)
  const ratingMatch =
    html.match(/id=["']acrPopover["'][^>]*title=["']([0-9.,]+)/i)?.[1] ||
    html.match(/([0-9],[0-9])\s*su\s*5\s*stelle/i)?.[1];
  const rating = ratingMatch
    ? Math.min(5, Math.max(1, Number(ratingMatch.replace(',', '.')) || 4.7))
    : 4.7;
  const revCntMatch =
    html.match(/id=["']acrCustomerReviewText["'][^>]*>\(?([0-9.]+)/i)?.[1] ||
    html.match(/([0-9.]+)\s*(?:voti|recensioni)/i)?.[1];
  const reviewCount = revCntMatch ? Math.max(1, Number(revCntMatch.replace(/\./g, '')) || 1) : 1;

  // Feature bullets (#feature-bullets) or title subtitle fallback
  const bulletsBlock = html.match(/id=["']feature-bullets["'][\s\S]{0,6000}/i)?.[0] || '';
  const bullets: string[] = [];
  for (const li of bulletsBlock.matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)) {
    const text = decodeHtmlEntities(li[1].replace(/<[^>]+>/g, ' '));
    if (
      text.length > 10 &&
      !/vedi altri dettagli prodotto/i.test(text) &&
      !bullets.includes(text)
    ) {
      bullets.push(text);
    }
    if (bullets.length >= 4) break;
  }

  // Split descriptive mobile/long Amazon titles cleanly into concise name + subtitle
  const shortModelName = overviewMap.get('Nome modello');
  const titleSplit = rawTitle.match(/^([^|:]{8,85}?)\s*[|:]\s*(.+)$/);
  if (bullets.length === 0 && titleSplit?.[2]) {
    bullets.push(titleSplit[2].trim());
  }

  const displayName =
    rawTitle.length > 85 && shortModelName
      ? `${brand !== shortModelName.split(' ')[0] ? `${brand} ` : ''}${shortModelName}${
          selectedSizeName && !shortModelName.includes(selectedSizeName) ? ` (${selectedSizeName})` : ''
        }`
      : titleSplit && rawTitle.length > 85
      ? titleSplit[1].trim()
      : rawTitle;

  const specs: Array<{ label: string; value: string }> = [
    { label: 'Marca', value: brand },
    { label: 'ASIN / Codice', value: asin },
  ];
  if (finalColorName !== 'Originale') {
    specs.push({ label: 'Colore selezionato', value: finalColorName });
  }
  if (selectedSizeName) {
    specs.push({ label: 'Memoria / Taglia', value: selectedSizeName });
  }
  for (const [k, v] of overviewMap.entries()) {
    if (!specs.some((s) => s.label.toLowerCase() === k.toLowerCase())) {
      specs.push({ label: k, value: v });
    }
  }
  specs.push({ label: 'Link sorgente', value: parsedUrl.hostname.replace(/^www\./, '') });
  specs.push({ label: 'Collegamento originale', value: parsedUrl.href });

  const shortSummary = bullets[0] || rawTitle;

  return {
    id: `url-${asin.toLowerCase()}-${Date.now()}`,
    sku: asin,
    name: displayName,
    brand,
    category,
    searchPriority: 98,
    price: priceNum,
    originalPrice,
    rating,
    reviewCount,
    availability: 'Disponibilità verificata su Amazon',
    deliveryText: `Importato da ${parsedUrl.hostname.replace(/^www\./, '')}`,
    warranty: 'Garanzia legale 24 mesi Italia',
    imageUrl,
    visualKind,
    shortSummary,
    highlights:
      bullets.length > 0
        ? bullets
        : [rawTitle, `Codice ASIN: ${asin}`, `Importato da ${parsedUrl.hostname.replace(/^www\./, '')}`],
    specs,
    boxContents: [displayName, 'Documentazione originale'],
    ...(colorOptions && colorOptions.length > 0 ? { colorOptions } : {}),
    variants: variantList,
    keywords: [brand.toLowerCase(), displayName.toLowerCase(), asin.toLowerCase(), finalColorName.toLowerCase()],
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.post('/api/catalog/import-url', async (req, res) => {
    const rawUrl = typeof req.body?.url === 'string' ? req.body.url.trim() : '';
    const parsedUrl = isSafeExternalUrl(rawUrl);

    if (!parsedUrl) {
      res.status(400).json({
        error: 'Inserisci un link valido che inizi con https:// o http://.',
      });
      return;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 14000);

    try {
      const isAmazonHost = parsedUrl.hostname.toLowerCase().includes('amazon.');
      const amazonAsin = isAmazonHost ? extractAmazonAsin(parsedUrl) : undefined;
      const mobileAmazonUrl = amazonAsin
        ? `https://${parsedUrl.hostname}/gp/aw/d/${amazonAsin}${parsedUrl.search || '?th=1'}`
        : undefined;

      const fetchTargets: Array<{ targetUrl: string; ua: string; pauseMs: number }> =
        isAmazonHost && mobileAmazonUrl
          ? [
              {
                targetUrl: parsedUrl.href,
                ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
                pauseMs: 0,
              },
              {
                targetUrl: mobileAmazonUrl,
                ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',
                pauseMs: 120,
              },
              {
                targetUrl: mobileAmazonUrl,
                ua: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
                pauseMs: 300,
              },
              {
                targetUrl: parsedUrl.href,
                ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36',
                pauseMs: 350,
              },
            ]
          : [
              {
                targetUrl: parsedUrl.href,
                ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
                pauseMs: 0,
              },
            ];

      let response: Response | null = null;
      let html = '';

      for (const step of fetchTargets) {
        if (step.pauseMs > 0) {
          await new Promise((r) => setTimeout(r, step.pauseMs));
        }
        response = await fetch(step.targetUrl, {
          signal: controller.signal,
          headers: {
            'User-Agent': step.ua,
            Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'it-IT,it;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
          },
        });

        if (response.status === 503) {
          continue;
        }
        if (response.ok) {
          html = (await response.text()).slice(0, 2_500_000);
          if (isAmazonChallengeHtml(html, parsedUrl)) {
            continue;
          }
          break;
        }
        if (!isAmazonHost) break;
      }

      if (!response || !response.ok || isAmazonChallengeHtml(html, parsedUrl)) {
        const fallbackProduct = buildUrlFallbackFromSlug(parsedUrl);
        const enriched = await enrichBlockedUrlWithSearch(parsedUrl, fallbackProduct);
        const finalProduct = enriched ?? fallbackProduct;

        const warningMsg = finalProduct.imageUrl
          ? undefined
          : enriched
          ? `Il sito (${parsedUrl.hostname}) usa una protezione anti-bot che blocca il download della foto, ma abbiamo recuperato descrizione, specifiche${finalProduct.price > 0 ? ' e prezzo' : ''} tramite ricerca web. Puoi incollare il link della foto direttamente nella card.`
          : `Il sito (${parsedUrl.hostname}) blocca la lettura automatica (stato ${response?.status ?? 'bloccato'}): abbiamo salvato i dati ricavati dal link. Puoi inserire prezzo e foto direttamente nella tua pagina.`;

        res.json({
          product: finalProduct,
          partial: !finalProduct.imageUrl || finalProduct.price === 0,
          warning: warningMsg,
        });
        return;
      }

      const amazonProduct = parseAmazonProductHtml(html, parsedUrl);
      if (amazonProduct) {
        res.json({
          product: amazonProduct,
          partial: !amazonProduct.imageUrl || amazonProduct.price === 0,
        });
        return;
      }

      const ldMatches =
        html.match(/<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi) ||
        [];

      const productNodes: Array<Record<string, unknown>> = [];
      for (const block of ldMatches) {
        const inner = block
          .replace(/^<script[^>]*>/i, '')
          .replace(/<\/script>$/i, '')
          .trim();
        try {
          const parsedJson = JSON.parse(inner);
          findProductLdNodes(parsedJson, productNodes);
        } catch {
          // Ignore malformed JSON-LD blocks
        }
      }

      const ld = productNodes[0];
      const ogTitle = extractMetaTag(html, 'property', 'og:title');
      const ogDesc =
        extractMetaTag(html, 'property', 'og:description') ||
        extractMetaTag(html, 'name', 'description');
      const ogImage = extractMetaTag(html, 'property', 'og:image');
      const metaPrice =
        extractMetaTag(html, 'property', 'product:price:amount') ||
        extractMetaTag(html, 'property', 'og:price:amount');
      const htmlTitleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
      const htmlTitle = htmlTitleMatch?.[1] ? decodeHtmlEntities(htmlTitleMatch[1]) : undefined;

      const rawName =
        (typeof ld?.name === 'string' && decodeHtmlEntities(ld.name)) ||
        ogTitle ||
        htmlTitle ||
        buildUrlFallbackFromSlug(parsedUrl).name;

      const ldBrand =
        typeof ld?.brand === 'string'
          ? ld.brand
          : ld?.brand && typeof ld.brand === 'object' && 'name' in ld.brand
          ? String((ld.brand as Record<string, unknown>).name)
          : undefined;

      const brand =
        (ldBrand ? decodeHtmlEntities(ldBrand) : undefined) ||
        inferManufacturerFromText(rawName) ||
        inferBrandFromHost(parsedUrl.hostname);

      let priceNum = 0;
      const offersRaw = ld?.offers;
      const firstOffer = Array.isArray(offersRaw)
        ? (offersRaw[0] as Record<string, unknown> | undefined)
        : (offersRaw as Record<string, unknown> | undefined);

      if (firstOffer) {
        const rawP = firstOffer.price ?? firstOffer.lowPrice;
        if (rawP !== undefined) {
          priceNum = Number(String(rawP).replace(',', '.').replace(/[^0-9.]/g, '')) || 0;
        }
      }
      if (!priceNum && metaPrice) {
        priceNum = Number(metaPrice.replace(',', '.').replace(/[^0-9.]/g, '')) || 0;
      }

      let imageUrl: string | undefined = ogImage;
      const ldImg = ld?.image;
      if (typeof ldImg === 'string') {
        imageUrl = ldImg;
      } else if (Array.isArray(ldImg) && ldImg.length > 0) {
        const firstImg = ldImg[0];
        if (typeof firstImg === 'string') {
          imageUrl = firstImg;
        } else if (firstImg && typeof firstImg === 'object' && 'contentUrl' in firstImg) {
          imageUrl = String((firstImg as Record<string, unknown>).contentUrl);
        } else if (firstImg && typeof firstImg === 'object' && 'url' in firstImg) {
          imageUrl = String((firstImg as Record<string, unknown>).url);
        }
      } else if (ldImg && typeof ldImg === 'object' && 'url' in ldImg) {
        imageUrl = String((ldImg as Record<string, unknown>).url);
      }

      const rawCat = typeof ld?.category === 'string' ? decodeHtmlEntities(ld.category) : '';
      const { category, visualKind } = inferCategoryAndVisual(rawCat, rawName);

      const description =
        (typeof ld?.description === 'string' && decodeHtmlEntities(ld.description)) ||
        ogDesc ||
        `Articolo ${rawName} importato direttamente da ${parsedUrl.hostname}.`;

      const sku =
        (typeof ld?.sku === 'string' && ld.sku) ||
        (typeof ld?.mpn === 'string' && ld.mpn) ||
        (typeof ld?.gtin13 === 'string' && ld.gtin13) ||
        `WEB-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

      const agg = ld?.aggregateRating as Record<string, unknown> | undefined;
      const rating = agg?.ratingValue
        ? Math.min(5, Math.max(1, Number(agg.ratingValue) || 4.8))
        : 4.8;
      const reviewCount = agg?.reviewCount ? Math.max(1, Number(agg.reviewCount) || 1) : 1;

      const availRaw = typeof firstOffer?.availability === 'string' ? firstOffer.availability : '';
      const availability = availRaw.includes('OutOfStock')
        ? 'Attualmente esaurito sul sito'
        : 'Disponibilità immediata (verificata online)';

      const specs: Array<{ label: string; value: string }> = [
        { label: 'Marca', value: brand },
        { label: 'Codice / SKU', value: sku },
      ];
      if (rawCat) specs.push({ label: 'Categoria originale', value: rawCat });
      if (typeof ld?.color === 'string' && ld.color) {
        specs.push({ label: 'Colore', value: decodeHtmlEntities(ld.color) });
      }
      if (typeof ld?.material === 'string' && ld.material) {
        specs.push({ label: 'Materiale', value: decodeHtmlEntities(ld.material) });
      }
      specs.push({ label: 'Link sorgente', value: parsedUrl.hostname.replace(/^www\./, '') });
      specs.push({ label: 'Collegamento originale', value: parsedUrl.href });

      const colorText =
        typeof ld?.color === 'string' && ld.color ? decodeHtmlEntities(ld.color) : 'Originale';
      const colorHex = inferColorHex(colorText);

      const product: NormalizedProduct = {
        id: `url-${sku.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now()}`,
        sku,
        name: rawName,
        brand,
        category,
        searchPriority: 98,
        price: priceNum,
        rating,
        reviewCount,
        availability,
        deliveryText: `Importato da ${parsedUrl.hostname.replace(/^www\./, '')}`,
        warranty: 'Garanzia ufficiale del venditore (24 mesi UE)',
        imageUrl,
        visualKind,
        shortSummary: description,
        highlights: [
          description,
          `Codice articolo rilevato: ${sku}`,
          `Importato direttamente dalla scheda ufficiale su ${parsedUrl.hostname.replace(/^www\./, '')}`,
        ],
        specs,
        boxContents: [rawName, 'Documentazione originale del produttore'],
        variants: [
          {
            id: 'imported',
            label: 'Versione da link',
            colorName: colorText,
            colorHex,
            priceDelta: 0,
          },
        ],
        keywords: [brand.toLowerCase(), rawName.toLowerCase(), sku.toLowerCase()],
      };

      if (!ld && !ogTitle) {
        const fallbackProduct = buildUrlFallbackFromSlug(parsedUrl);
        const enriched = await enrichBlockedUrlWithSearch(parsedUrl, fallbackProduct);
        if (enriched) {
          res.json({
            product: enriched,
            partial: !enriched.imageUrl || enriched.price === 0,
            warning: !enriched.imageUrl
              ? `Il sito (${parsedUrl.hostname}) non espone pubblicamente la foto ai server automatici, ma abbiamo recuperato i dettagli del prodotto.`
              : undefined,
          });
          return;
        }
      }

      res.json({ product, partial: !ld && !ogTitle });
    } catch {
      const fallbackProduct = buildUrlFallbackFromSlug(parsedUrl);
      const enriched = await enrichBlockedUrlWithSearch(parsedUrl, fallbackProduct);
      const finalProduct = enriched ?? fallbackProduct;

      res.json({
        product: finalProduct,
        partial: !finalProduct.imageUrl || finalProduct.price === 0,
        warning: finalProduct.imageUrl
          ? undefined
          : enriched
          ? `Il sito (${parsedUrl.hostname}) blocca il download diretto della foto, ma abbiamo recuperato descrizione e specifiche tramite ricerca web.`
          : 'Il sito ha impedito il download automatico della pagina: abbiamo creato la scheda dai dati del collegamento.',
      });
    } finally {
      clearTimeout(timeout);
    }
  });


  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
