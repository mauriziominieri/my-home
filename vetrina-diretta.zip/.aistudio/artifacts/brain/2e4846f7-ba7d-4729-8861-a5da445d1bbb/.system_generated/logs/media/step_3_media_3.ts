import { useEffect, useState } from 'react';
import { VisualKind } from '../types/product';

interface ProductVisualProps {
  imageUrl?: string;
  visualKind: VisualKind;
  name: string;
  accentHex?: string;
  className?: string;
}

function DeviceIllustration({
  kind,
  accentHex = '#2C4D9E',
}: {
  kind: VisualKind;
  accentHex?: string;
}) {
  switch (kind) {
    case 'appliance':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="34" y="20" width="92" height="120" rx="8" fill="#E8E8E4" stroke="#C8C8C2" strokeWidth="2" />
          <rect x="34" y="20" width="92" height="22" rx="6" fill="#D5D5CF" />
          <rect x="44" y="27" width="24" height="8" rx="2" fill="#2B2C30" />
          <circle cx="108" cy="31" r="5" fill="#2B2C30" />
          <circle cx="80" cy="88" r="32" fill="#232428" stroke="#B6B6B0" strokeWidth="4" />
          <circle cx="80" cy="88" r="22" fill="#465564" />
          <path d="M68 82 Q80 96 92 84" stroke="rgba(255,255,255,0.4)" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );

    case 'furniture':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="28" y="22" width="104" height="116" rx="3" fill="#D8C3A5" stroke="#B09673" strokeWidth="2.5" />
          <rect x="34" y="28" width="92" height="28" fill="#EFECE6" />
          <rect x="34" y="62" width="92" height="28" fill="#EFECE6" />
          <rect x="34" y="96" width="92" height="28" fill="#EFECE6" />
          <line x1="80" y1="28" x2="80" y2="124" stroke="#C5AD8C" strokeWidth="3" />
          <rect x="42" y="38" width="8" height="18" rx="1" fill={accentHex} />
          <rect x="52" y="42" width="7" height="14" rx="1" fill="#5D737E" />
          <rect x="92" y="70" width="22" height="20" rx="2" fill="#B88E65" />
        </svg>
      );

    case 'guitar':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <g transform="rotate(35 80 80)">
            <rect x="75" y="14" width="10" height="62" rx="2" fill="#B89062" />
            <rect x="71" y="6" width="18" height="16" rx="4" fill="#222326" />
            <path
              d="M54 78 C42 84 44 102 52 110 C42 122 48 144 80 144 C112 144 118 122 108 110 C116 102 118 84 106 78 C98 74 92 84 80 84 C68 84 62 74 54 78 Z"
              fill={accentHex}
              stroke="#1E1F23"
              strokeWidth="2.5"
            />
            <rect x="70" y="94" width="20" height="7" rx="1.5" fill="#18181A" />
            <rect x="70" y="114" width="20" height="7" rx="1.5" fill="#18181A" />
            <rect x="68" y="128" width="24" height="5" rx="1.5" fill="#D4D4D0" />
            <line x1="77" y1="16" x2="77" y2="130" stroke="rgba(255,255,255,0.65)" strokeWidth="0.9" />
            <line x1="80" y1="16" x2="80" y2="130" stroke="rgba(255,255,255,0.65)" strokeWidth="0.9" />
            <line x1="83" y1="16" x2="83" y2="130" stroke="rgba(255,255,255,0.65)" strokeWidth="0.9" />
          </g>
        </svg>
      );

    case 'amp':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="62" y="20" width="36" height="8" rx="4" fill="#2D2E32" />
          <rect x="24" y="28" width="112" height="104" rx="7" fill="#1C1D20" />
          <rect x="32" y="36" width="96" height="20" rx="2" fill="#2D2F36" />
          <circle cx="44" cy="46" r="4" fill="#B6B8BE" />
          <circle cx="58" cy="46" r="4" fill="#B6B8BE" />
          <circle cx="72" cy="46" r="4" fill="#B6B8BE" />
          <circle cx="86" cy="46" r="4" fill="#B6B8BE" />
          <circle cx="114" cy="46" r="2.5" fill="#E14D43" />
          <rect x="32" y="62" width="96" height="62" rx="3" fill="#2D2D30" stroke="#45454A" strokeWidth="1.5" />
          <circle cx="80" cy="93" r="22" fill="#1E1F22" opacity="0.65" />
        </svg>
      );

    case 'shoe':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <path
            d="M24 98 C24 88 32 76 44 68 L58 50 L74 62 C88 74 106 78 130 82 C138 84 140 94 136 104 L24 104 Z"
            fill={accentHex}
          />
          <path d="M22 104 H138 C140 112 134 116 126 116 H26 C22 116 20 110 22 104 Z" fill="#FFFFFF" stroke="#D4D4CE" strokeWidth="2" />
          <line x1="62" y1="58" x2="72" y2="66" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="68" y1="64" x2="78" y2="72" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );

    case 'tv':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="14" y="34" width="132" height="76" rx="4" fill="#18191C" />
          <rect x="18" y="38" width="124" height="68" rx="2" fill="url(#tvGrad)" />
          <rect x="34" y="110" width="6" height="14" fill="#2A2B30" />
          <rect x="120" y="110" width="6" height="14" fill="#2A2B30" />
          <rect x="24" y="122" width="26" height="4" rx="2" fill="#2A2B30" />
          <rect x="110" y="122" width="26" height="4" rx="2" fill="#2A2B30" />
          <defs>
            <linearGradient id="tvGrad" x1="18" y1="38" x2="142" y2="106" gradientUnits="userSpaceOnUse">
              <stop stopColor="#2A4668" />
              <stop offset="0.55" stopColor="#172334" />
              <stop offset="1" stopColor="#12141A" />
            </linearGradient>
          </defs>
        </svg>
      );

    case 'sofa':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="24" y="58" width="112" height="36" rx="10" fill={accentHex} />
          <rect x="18" y="76" width="18" height="38" rx="6" fill={accentHex} stroke="rgba(0,0,0,0.12)" strokeWidth="1.5" />
          <rect x="124" y="76" width="18" height="38" rx="6" fill={accentHex} stroke="rgba(0,0,0,0.12)" strokeWidth="1.5" />
          <rect x="34" y="88" width="45" height="22" rx="4" fill={accentHex} stroke="rgba(0,0,0,0.12)" strokeWidth="1.5" />
          <rect x="81" y="88" width="45" height="22" rx="4" fill={accentHex} stroke="rgba(0,0,0,0.12)" strokeWidth="1.5" />
          <rect x="28" y="114" width="6" height="12" rx="1.5" fill="#4E3B2B" />
          <rect x="126" y="114" width="6" height="12" rx="1.5" fill="#4E3B2B" />
        </svg>
      );

    case 'router':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="52" y="34" width="56" height="92" rx="12" fill="#F4F4F1" stroke="#D2D2CC" strokeWidth="2" />
          <rect x="58" y="42" width="44" height="72" rx="8" fill="#FFFFFF" />
          <circle cx="80" cy="64" r="3.5" fill="#10B981" />
          <circle cx="80" cy="78" r="3.5" fill="#F59E0B" />
          <path d="M68 96 Q80 86 92 96" stroke="#18181B" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <path d="M73 103 Q80 96 87 103" stroke="#18181B" strokeWidth="2.5" fill="none" strokeLinecap="round" />
        </svg>
      );

    case 'kitchen':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="20" y="26" width="120" height="36" rx="2" fill="#EAE8E1" stroke="#C5C2B8" strokeWidth="1.5" />
          <line x1="60" y1="26" x2="60" y2="62" stroke="#C5C2B8" strokeWidth="1.5" />
          <line x1="100" y1="26" x2="100" y2="62" stroke="#C5C2B8" strokeWidth="1.5" />
          <rect x="20" y="84" width="120" height="46" rx="2" fill={accentHex} />
          <rect x="18" y="80" width="124" height="6" rx="1.5" fill="#D5D2CA" />
          <rect x="64" y="92" width="32" height="24" rx="2" fill="#232428" />
          <rect x="68" y="96" width="24" height="14" rx="1" fill="#3D424B" />
        </svg>
      );

    case 'smarthome':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="30" y="34" width="100" height="92" rx="10" fill="#EAEAE5" stroke="#C8C8C0" strokeWidth="2" />
          <rect x="44" y="48" width="72" height="64" rx="5" fill={accentHex} stroke="rgba(0,0,0,0.14)" strokeWidth="1.5" />
          <rect x="56" y="60" width="48" height="30" rx="3" fill="#141518" />
          <circle cx="80" cy="100" r="4" fill="#F59E0B" />
        </svg>
      );

    case 'lighting':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="66" y="14" width="28" height="7" rx="2" fill="#232428" />
          <line x1="80" y1="21" x2="80" y2="54" stroke="#232428" strokeWidth="2.5" />
          <path
            d="M44 92 C44 64 58 52 80 52 C102 52 116 64 116 92 Z"
            fill={accentHex}
            stroke="#1E1F23"
            strokeWidth="2.5"
          />
          <ellipse cx="80" cy="92" rx="36" ry="7" fill="#EAE6DC" stroke="#1E1F23" strokeWidth="2" />
          <circle cx="80" cy="96" r="9" fill="#FDE68A" />
          <path d="M56 106 L44 134 M80 108 L80 136 M104 106 L116 134" stroke="#F59E0B" strokeWidth="2" strokeLinecap="round" opacity="0.5" />
        </svg>
      );

    case 'tool':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="34" y="42" width="70" height="30" rx="8" fill={accentHex} />
          <rect x="104" y="48" width="24" height="18" rx="2" fill="#2D2E32" />
          <rect x="128" y="54" width="14" height="6" rx="1" fill="#8C8E94" />
          <path d="M58 72 H78 L72 116 H52 Z" fill="#252629" />
          <rect x="44" y="116" width="44" height="16" rx="4" fill="#1B1C1F" />
        </svg>
      );

    case 'generic-product':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <path d="M80 26 L128 50 L128 110 L80 134 L32 110 L32 50 Z" fill="#E3DFD5" stroke="#B7B2A5" strokeWidth="2" />
          <path d="M80 26 L128 50 L80 74 L32 50 Z" fill="#F0EDE6" stroke="#B7B2A5" strokeWidth="2" />
          <line x1="80" y1="74" x2="80" y2="134" stroke="#B7B2A5" strokeWidth="2" />
          <rect x="64" y="42" width="32" height="12" rx="2" fill={accentHex} opacity="0.85" />
        </svg>
      );

    case 'tablet-air':
    case 'tablet-pro':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="26" y="20" width="108" height="120" rx="10" fill="#1F2024" />
          <rect x="31" y="25" width="98" height="110" rx="6" fill="url(#tabletScreen)" />
          <circle cx="80" cy="22.5" r="1.5" fill="#4B4E56" />
          <rect x="44" y="42" width="46" height="7" rx="3.5" fill="rgba(255,255,255,0.8)" />
          <rect x="44" y="55" width="72" height="4" rx="2" fill="rgba(255,255,255,0.35)" />
          <rect x="44" y="64" width="60" height="4" rx="2" fill="rgba(255,255,255,0.25)" />
          <rect x="44" y="88" width="72" height="32" rx="6" fill="rgba(255,255,255,0.14)" />
          <defs>
            <linearGradient id="tabletScreen" x1="31" y1="25" x2="129" y2="135" gradientUnits="userSpaceOnUse">
              <stop stopColor={accentHex} />
              <stop offset="1" stopColor="#14161D" />
            </linearGradient>
          </defs>
        </svg>
      );

    case 'laptop-pro':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="24" y="34" width="112" height="74" rx="6" fill="#232428" />
          <rect x="28" y="38" width="104" height="65" rx="3" fill="url(#laptopScreen)" />
          <path d="M14 110 H146 L152 120 H8 L14 110 Z" fill="#D4D4D0" />
          <rect x="66" y="110" width="28" height="3" rx="1.5" fill="#9E9E99" />
          <defs>
            <linearGradient id="laptopScreen" x1="28" y1="38" x2="132" y2="103" gradientUnits="userSpaceOnUse">
              <stop stopColor="#3B4254" />
              <stop offset="1" stopColor="#121318" />
            </linearGradient>
          </defs>
        </svg>
      );

    case 'earbuds':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="34" y="40" width="92" height="82" rx="24" fill="#FFFFFF" stroke="#DCDCD8" strokeWidth="2.5" />
          <path d="M34 68 H126" stroke="#E6E6E2" strokeWidth="2" />
          <rect x="66" y="64" width="28" height="5" rx="2.5" fill="#C7C7C2" />
          <circle cx="80" cy="84" r="3" fill="#44B86F" />
          <rect x="54" y="48" width="16" height="14" rx="7" fill="#F2F2EE" stroke="#E0E0DA" />
          <rect x="90" y="48" width="16" height="14" rx="7" fill="#F2F2EE" stroke="#E0E0DA" />
        </svg>
      );

    case 'watch-series':
    case 'watch-ultra':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="64" y="14" width="32" height="34" rx="6" fill={accentHex} />
          <rect x="64" y="112" width="32" height="34" rx="6" fill={accentHex} />
          <rect x="46" y="40" width="68" height="80" rx="20" fill="#232428" />
          <rect x="52" y="46" width="56" height="68" rx="15" fill="#0F1013" />
          <circle cx="80" cy="80" r="18" stroke={accentHex} strokeWidth="3.5" fill="none" />
          <path d="M80 70 V80 L88 85" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        </svg>
      );

    case 'ereader':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="34" y="18" width="92" height="124" rx="9" fill="#232428" />
          <rect x="42" y="28" width="76" height="100" rx="2" fill="#F4F1E8" />
          <rect x="52" y="40" width="56" height="4" rx="2" fill="#3C3B37" />
          <rect x="52" y="52" width="52" height="3" rx="1.5" fill="#7D7B73" />
          <rect x="52" y="60" width="48" height="3" rx="1.5" fill="#7D7B73" />
          <rect x="52" y="68" width="54" height="3" rx="1.5" fill="#7D7B73" />
          <rect x="52" y="76" width="42" height="3" rx="1.5" fill="#7D7B73" />
          <rect x="52" y="90" width="54" height="3" rx="1.5" fill="#7D7B73" />
          <rect x="52" y="98" width="46" height="3" rx="1.5" fill="#7D7B73" />
        </svg>
      );

    case 'vacuum':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="74" y="34" width="12" height="86" rx="4" fill="#9E9EA4" />
          <rect x="54" y="24" width="46" height="26" rx="8" fill="#4C4D52" />
          <rect x="64" y="30" width="24" height="14" rx="4" fill="#D8A828" />
          <rect x="48" y="116" width="64" height="16" rx="5" fill="#2B2C30" />
          <rect x="54" y="128" width="52" height="4" rx="2" fill="#57C679" />
        </svg>
      );

    case 'console':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="18" y="48" width="22" height="64" rx="10" fill="#2A2C32" />
          <rect x="120" y="48" width="22" height="64" rx="10" fill="#2A2C32" />
          <rect x="40" y="48" width="80" height="64" rx="3" fill="#141518" />
          <rect x="45" y="53" width="70" height="54" rx="2" fill="#234878" />
          <circle cx="29" cy="68" r="4.5" fill="#565963" />
          <circle cx="131" cy="84" r="4.5" fill="#565963" />
        </svg>
      );

    case 'mouse':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <path d="M52 64 C52 38 66 28 80 28 C94 28 108 38 108 64 V98 C108 122 94 134 80 134 C66 134 52 122 52 98 Z" fill="#2B2C30" />
          <rect x="77" y="44" width="6" height="18" rx="3" fill="#7D8087" />
          <path d="M52 72 H108" stroke="#3F4147" strokeWidth="2" />
        </svg>
      );

    case 'monitor':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="14" y="34" width="132" height="68" rx="6" fill="#202124" />
          <rect x="19" y="39" width="122" height="58" rx="3" fill="url(#monScreen)" />
          <rect x="74" y="102" width="12" height="22" fill="#B6B9BC" />
          <rect x="52" y="122" width="56" height="6" rx="3" fill="#9A9D9E" />
          <defs>
            <linearGradient id="monScreen" x1="19" y1="39" x2="141" y2="97" gradientUnits="userSpaceOnUse">
              <stop stopColor="#263B59" />
              <stop offset="1" stopColor="#131620" />
            </linearGradient>
          </defs>
        </svg>
      );

    case 'drone':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <path d="M36 46 L68 74 M124 46 L92 74 M36 114 L68 86 M124 114 L92 86" stroke="#A7A7A2" strokeWidth="6" strokeLinecap="round" />
          <ellipse cx="36" cy="46" rx="20" ry="4" fill="#3B3C40" />
          <ellipse cx="124" cy="46" rx="20" ry="4" fill="#3B3C40" />
          <ellipse cx="36" cy="114" rx="20" ry="4" fill="#3B3C40" />
          <ellipse cx="124" cy="114" rx="20" ry="4" fill="#3B3C40" />
          <rect x="64" y="64" width="32" height="32" rx="10" fill="#D6D6D1" stroke="#9B9B95" strokeWidth="2" />
          <circle cx="80" cy="84" r="6" fill="#1D1E22" />
        </svg>
      );

    case 'camera':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="26" y="46" width="108" height="72" rx="10" fill="#1F2024" />
          <rect x="54" y="34" width="52" height="16" rx="4" fill="#2A2B30" />
          <circle cx="80" cy="82" r="26" fill="#111215" stroke="#6E7078" strokeWidth="4" />
          <circle cx="80" cy="82" r="14" fill="#283A4E" />
        </svg>
      );

    case 'headphones':
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <path d="M36 86 C36 48 54 32 80 32 C106 32 124 48 124 86" stroke="#222326" strokeWidth="10" strokeLinecap="round" fill="none" />
          <rect x="24" y="76" width="22" height="44" rx="11" fill="#1A1B1E" />
          <rect x="114" y="76" width="22" height="44" rx="11" fill="#1A1B1E" />
        </svg>
      );

    case 'phone-pro':
    case 'phone-blue':
    case 'phone-teal':
    default:
      return (
        <svg viewBox="0 0 160 160" className="w-full h-full p-4" aria-hidden="true">
          <rect x="48" y="18" width="64" height="124" rx="14" fill="#1E1F23" />
          <rect x="52" y="22" width="56" height="116" rx="11" fill={accentHex} />
          <rect x="56" y="28" width="24" height="24" rx="6" fill="rgba(0,0,0,0.22)" />
          <circle cx="63" cy="35" r="4" fill="#141416" />
          <circle cx="73" cy="44" r="4" fill="#141416" />
        </svg>
      );
  }
}

export function ProductVisual({
  imageUrl,
  visualKind,
  name,
  accentHex,
  className = '',
}: ProductVisualProps) {
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    setImgFailed(false);
  }, [imageUrl]);

  const hasValidImage = Boolean(imageUrl && !imgFailed);

  return (
    <div
      className={`relative overflow-hidden flex items-center justify-center ${
        hasValidImage ? 'bg-white p-2.5' : 'bg-[#F1F1EE]'
      } ${className}`}
    >
      {hasValidImage ? (
        <img
          key={imageUrl}
          src={imageUrl}
          alt={name}
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="max-w-full max-h-full w-full h-full object-contain object-center"
        />
      ) : (
        <DeviceIllustration kind={visualKind} accentHex={accentHex} />
      )}
    </div>
  );
}
