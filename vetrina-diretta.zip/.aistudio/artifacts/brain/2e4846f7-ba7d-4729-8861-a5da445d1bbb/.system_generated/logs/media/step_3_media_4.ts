interface TopBarProps {
  pageItemCount: number;
  onJumpToLinkBar: () => void;
  onOpenManualPanel: () => void;
  onJumpToMyPage: () => void;
}

export function TopBar({
  pageItemCount,
  onJumpToLinkBar,
  onOpenManualPanel,
  onJumpToMyPage,
}: TopBarProps) {
  return (
    <header className="bg-white border-b border-[#E4E4E0]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            onJumpToLinkBar();
          }}
          className="text-lg font-bold tracking-tight text-[#141413] whitespace-nowrap shrink-0"
        >
          Vetrina Diretta
        </a>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#5E5E59]">
          <button
            type="button"
            onClick={onJumpToLinkBar}
            className="hover:text-[#141413] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Incolla link
          </button>
          <button
            type="button"
            onClick={onOpenManualPanel}
            className="hover:text-[#141413] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Inserisci modello
          </button>
          <a
            href="#riepilogo-pagina"
            onClick={(e) => {
              e.preventDefault();
              onJumpToMyPage();
            }}
            className="hover:text-[#141413] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            La mia pagina
          </a>
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onJumpToMyPage}
            className="px-4 py-2 text-xs font-semibold text-[#141413] bg-[#F59E0B] hover:bg-[#D97706] hover:text-white rounded-md transition-colors whitespace-nowrap shrink-0 tabular-nums cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#141413]"
          >
            La mia pagina ({pageItemCount})
          </button>
        </div>
      </div>
    </header>
  );
}
