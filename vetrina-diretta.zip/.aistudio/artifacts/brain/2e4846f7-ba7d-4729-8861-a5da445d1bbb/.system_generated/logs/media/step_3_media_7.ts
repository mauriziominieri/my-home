import { useMemo, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Check,
  ChevronDown,
  ChevronUp,
  Copy,
  Home,
  ImagePlus,
  LayoutGrid,
  List,
  Minus,
  Pencil,
  Plus,
  Search,
  Star,
  Trash2,
  X,
} from 'lucide-react';
import { ProductCategory, SavedPageItem } from '../types/product';
import { formatEuro, inferColorHexClient } from '../utils/search';
import { ProductVisual } from './ProductVisual';

export interface ItemDetailsUpdate {
  name: string;
  brand: string;
  category: ProductCategory;
  sku: string;
  shortSummary: string;
  unitPrice: number;
  variantLabel: string;
  colorName: string;
  colorHex: string;
  room: string;
  imageUrl?: string;
}

interface UserPageSectionProps {
  items: SavedPageItem[];
  rooms: string[];
  onAddRoom: (roomName: string) => void;
  onUpdateQuantity: (entryId: string, delta: number) => void;
  onUpdatePrice: (entryId: string, newUnitPrice: number) => void;
  onUpdateImage: (entryId: string, newImageUrl: string) => void;
  onUpdateRoom: (entryId: string, room: string) => void;
  onUpdateItemDetails: (entryId: string, updates: ItemDetailsUpdate) => void;
  onRemoveItem: (entryId: string) => void;
  onMoveItem: (entryId: string, direction: 'up' | 'down') => void;
  onClearPage: () => void;
  onOpenLinkPanel: () => void;
  onOpenManualPanel: () => void;
}

type PageSortOption = 'saved' | 'price-asc' | 'price-desc' | 'name-asc';

const CATEGORY_OPTIONS: ProductCategory[] = [
  'Arredamento',
  'Elettrodomestici',
  'Domotica & Rete',
  'Casa & Gaming',
  'Smartphone',
  'Tablet',
  'Computer',
  'Audio',
  'Wearable',
  'Fotografia',
  'Strumenti Musicali',
  'Sport & Tempo Libero',
  'Fai da te',
];

export function UserPageSection({
  items,
  rooms,
  onAddRoom,
  onUpdateQuantity,
  onUpdatePrice,
  onUpdateImage,
  onUpdateRoom,
  onUpdateItemDetails,
  onRemoveItem,
  onMoveItem,
  onClearPage,
  onOpenLinkPanel,
  onOpenManualPanel,
}: UserPageSectionProps) {
  const [roomFilter, setRoomFilter] = useState<string>('Tutte');
  const [categoryFilter, setCategoryFilter] = useState<ProductCategory | 'Tutti'>('Tutti');
  const [brandFilter, setBrandFilter] = useState<string>('Tutte');
  const [textFilter, setTextFilter] = useState('');
  const [sortOrder, setSortOrder] = useState<PageSortOption>('saved');

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [confirmClear, setConfirmClear] = useState(false);
  const [confirmRemoveId, setConfirmRemoveId] = useState<string | null>(null);
  const [copiedSummary, setCopiedSummary] = useState(false);
  const [expandedSpecIds, setExpandedSpecIds] = useState<Set<string>>(new Set());

  const [editingPriceId, setEditingPriceId] = useState<string | null>(null);
  const [priceDraft, setPriceDraft] = useState('');

  const [editingImageId, setEditingImageId] = useState<string | null>(null);
  const [imageDraft, setImageDraft] = useState('');

  const [editingDetailsId, setEditingDetailsId] = useState<string | null>(null);
  const [detailsDraft, setDetailsDraft] = useState<ItemDetailsUpdate | null>(null);

  const [isAddingRoom, setIsAddingRoom] = useState(false);
  const [newRoomDraft, setNewRoomDraft] = useState('');

  const totalUnits = items.reduce((sum, item) => sum + item.quantity, 0);
  const totalValue = items.reduce(
    (sum, item) => sum + (item.product.price + item.variant.priceDelta) * item.quantity,
    0
  );

  const presentCategories = useMemo(
    () => Array.from(new Set(items.map((i) => i.product.category))),
    [items]
  );
  const presentBrands = useMemo(
    () => Array.from(new Set(items.map((i) => i.product.brand))).sort((a, b) => a.localeCompare(b)),
    [items]
  );

  const roomCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const item of items) {
      const r = item.room || 'Non assegnata';
      counts.set(r, (counts.get(r) ?? 0) + item.quantity);
    }
    return counts;
  }, [items]);

  const filteredItems = useMemo(() => {
    const cleanText = textFilter.trim().toLowerCase();

    const matched = items.filter((item) => {
      const itemRoom = item.room || 'Non assegnata';
      if (roomFilter !== 'Tutte' && itemRoom !== roomFilter) return false;
      if (categoryFilter !== 'Tutti' && item.product.category !== categoryFilter) return false;
      if (brandFilter !== 'Tutte' && item.product.brand !== brandFilter) return false;
      if (cleanText) {
        const haystack =
          `${item.product.name} ${item.product.brand} ${item.product.category} ${item.product.sku} ${item.variant.label} ${item.variant.colorName} ${itemRoom} ${item.product.shortSummary}`.toLowerCase();
        if (!haystack.includes(cleanText)) return false;
      }
      return true;
    });

    if (sortOrder === 'saved') return matched;

    return matched.slice().sort((a, b) => {
      const priceA = a.product.price + a.variant.priceDelta;
      const priceB = b.product.price + b.variant.priceDelta;
      if (sortOrder === 'price-asc') return priceA - priceB;
      if (sortOrder === 'price-desc') return priceB - priceA;
      return a.product.name.localeCompare(b.product.name, 'it');
    });
  }, [items, roomFilter, categoryFilter, brandFilter, textFilter, sortOrder]);

  const filteredUnits = filteredItems.reduce((sum, item) => sum + item.quantity, 0);
  const filteredValue = filteredItems.reduce(
    (sum, item) => sum + (item.product.price + item.variant.priceDelta) * item.quantity,
    0
  );

  const hasActiveFilters =
    roomFilter !== 'Tutte' ||
    categoryFilter !== 'Tutti' ||
    brandFilter !== 'Tutte' ||
    textFilter.trim().length > 0 ||
    sortOrder !== 'saved';

  function resetAllFilters() {
    setRoomFilter('Tutte');
    setCategoryFilter('Tutti');
    setBrandFilter('Tutte');
    setTextFilter('');
    setSortOrder('saved');
  }

  function toggleSpecs(entryId: string) {
    setExpandedSpecIds((prev) => {
      const next = new Set(prev);
      if (next.has(entryId)) next.delete(entryId);
      else next.add(entryId);
      return next;
    });
  }

  function startEditingPrice(entryId: string, currentUnitPrice: number) {
    setEditingPriceId(entryId);
    setPriceDraft(currentUnitPrice > 0 ? String(currentUnitPrice).replace('.', ',') : '');
  }

  function commitPriceEdit(entryId: string) {
    const parsed = Number(priceDraft.replace(',', '.').replace(/[^0-9.]/g, ''));
    if (Number.isFinite(parsed) && parsed >= 0) {
      onUpdatePrice(entryId, Number(parsed.toFixed(2)));
    }
    setEditingPriceId(null);
    setPriceDraft('');
  }

  function startEditingImage(entryId: string, currentUrl?: string) {
    setEditingImageId(entryId);
    setImageDraft(currentUrl || '');
  }

  function commitImageEdit(entryId: string) {
    const clean = imageDraft.trim();
    if (!clean || /^https?:\/\/\S+$/i.test(clean)) {
      onUpdateImage(entryId, clean);
    }
    setEditingImageId(null);
    setImageDraft('');
  }

  function startEditingDetails(item: SavedPageItem) {
    if (editingDetailsId === item.entryId) {
      setEditingDetailsId(null);
      setDetailsDraft(null);
      return;
    }
    const unitPrice = item.product.price + item.variant.priceDelta;
    setEditingDetailsId(item.entryId);
    setDetailsDraft({
      name: item.product.name,
      brand: item.product.brand,
      category: item.product.category,
      sku: item.product.sku,
      shortSummary: item.product.shortSummary,
      unitPrice,
      variantLabel: item.variant.label,
      colorName: item.variant.colorName,
      colorHex: item.variant.colorHex,
      room: item.room || 'Non assegnata',
      imageUrl: item.product.imageUrl || '',
    });
  }

  function commitDetailsEdit(entryId: string) {
    if (!detailsDraft) return;
    if (!detailsDraft.name.trim()) return;
    onUpdateItemDetails(entryId, {
      ...detailsDraft,
      name: detailsDraft.name.trim(),
      brand: detailsDraft.brand.trim() || 'Personale',
      sku: detailsDraft.sku.trim() || 'CUSTOM',
      shortSummary: detailsDraft.shortSummary.trim(),
      variantLabel: detailsDraft.variantLabel.trim() || 'Standard',
      colorName: detailsDraft.colorName.trim() || 'Originale',
      imageUrl: detailsDraft.imageUrl?.trim() || undefined,
    });
    setEditingDetailsId(null);
    setDetailsDraft(null);
  }

  function handleCreateRoom(e: React.FormEvent) {
    e.preventDefault();
    const clean = newRoomDraft.trim();
    if (clean.length >= 2) {
      onAddRoom(clean);
      setRoomFilter(clean);
    }
    setNewRoomDraft('');
    setIsAddingRoom(false);
  }

  async function handleCopySummary() {
    const lines = [
      'LA MIA PAGINA ARTICOLI — Vetrina Diretta',
      '----------------------------------------',
      ...filteredItems.map((item, idx) => {
        const unitPrice = item.product.price + item.variant.priceDelta;
        const roomLabel = item.room || 'Non assegnata';
        const priceText = unitPrice > 0 ? formatEuro(unitPrice * item.quantity) : 'Prezzo da inserire';
        return `${idx + 1}. [${roomLabel}] ${item.product.name} (${item.variant.label} · ${item.variant.colorName}) × ${item.quantity} — ${priceText}`;
      }),
      '----------------------------------------',
      `Articoli in elenco: ${filteredUnits}`,
      `Valore complessivo: ${formatEuro(filteredValue)}`,
    ];

    try {
      await navigator.clipboard.writeText(lines.join('\n'));
      setCopiedSummary(true);
      window.setTimeout(() => setCopiedSummary(false), 2000);
    } catch {
      setCopiedSummary(false);
    }
  }

  function renderDetailsEditor(item: SavedPageItem) {
    if (editingDetailsId !== item.entryId || !detailsDraft) return null;

    return (
      <form
        onSubmit={(e) => {
          e.preventDefault();
          commitDetailsEdit(item.entryId);
        }}
        className="mt-4 p-4 bg-[#FAFAF8] border border-[#D4D4CE] rounded-md space-y-3 text-xs"
      >
        <div className="flex items-center justify-between border-b border-[#E4E4E0] pb-2">
          <span className="font-bold text-[#141413]">Modifica dettagli articolo</span>
          <button
            type="button"
            onClick={() => {
              setEditingDetailsId(null);
              setDetailsDraft(null);
            }}
            aria-label="Chiudi modifica"
            className="p-0.5 text-[#5E5E59] hover:text-[#141413] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <label className="block sm:col-span-2">
            <span className="block font-medium text-[#5E5E59] mb-1">Nome articolo *</span>
            <input
              type="text"
              required
              value={detailsDraft.name}
              onChange={(e) => setDetailsDraft({ ...detailsDraft, name: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-white border border-[#D4D4CE] rounded focus:outline-none focus:border-[#141413]"
            />
          </label>

          <label className="block">
            <span className="block font-medium text-[#5E5E59] mb-1">Marca</span>
            <input
              type="text"
              value={detailsDraft.brand}
              onChange={(e) => setDetailsDraft({ ...detailsDraft, brand: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-white border border-[#D4D4CE] rounded focus:outline-none focus:border-[#141413]"
            />
          </label>

          <label className="block">
            <span className="block font-medium text-[#5E5E59] mb-1">Stanza</span>
            <select
              value={detailsDraft.room}
              onChange={(e) => setDetailsDraft({ ...detailsDraft, room: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-white border border-[#D4D4CE] rounded focus:outline-none focus:border-[#141413]"
            >
              {rooms.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="block font-medium text-[#5E5E59] mb-1">Categoria</span>
            <select
              value={detailsDraft.category}
              onChange={(e) =>
                setDetailsDraft({ ...detailsDraft, category: e.target.value as ProductCategory })
              }
              className="w-full px-2.5 py-1.5 bg-white border border-[#D4D4CE] rounded focus:outline-none focus:border-[#141413]"
            >
              {!CATEGORY_OPTIONS.includes(detailsDraft.category) && (
                <option value={detailsDraft.category}>{detailsDraft.category}</option>
              )}
              {CATEGORY_OPTIONS.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="block font-medium text-[#5E5E59] mb-1">Prezzo unitario (€)</span>
            <input
              type="text"
              inputMode="decimal"
              value={String(detailsDraft.unitPrice).replace('.', ',')}
              onChange={(e) => {
                const n = Number(e.target.value.replace(',', '.').replace(/[^0-9.]/g, ''));
                setDetailsDraft({
                  ...detailsDraft,
                  unitPrice: Number.isFinite(n) ? n : 0,
                });
              }}
              className="w-full px-2.5 py-1.5 bg-white border border-[#D4D4CE] rounded tabular-nums focus:outline-none focus:border-[#141413]"
            />
          </label>

          {/* Quick variant / memory selector when product defines variants */}
          <div className="sm:col-span-2">
            <span className="block font-medium text-[#5E5E59] mb-1">
              Memoria / Configurazione / Taglia
            </span>
            {item.product.variants.length > 1 && (
              <div className="flex flex-wrap gap-1.5 mb-1.5">
                {item.product.variants.map((v) => (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() =>
                      setDetailsDraft({
                        ...detailsDraft,
                        variantLabel: v.label,
                        unitPrice: Number((item.product.price + v.priceDelta).toFixed(2)),
                      })
                    }
                    className={`px-2 py-1 rounded border text-[11px] font-medium cursor-pointer ${
                      detailsDraft.variantLabel === v.label
                        ? 'bg-[#141413] text-white border-[#141413]'
                        : 'bg-white text-[#141413] border-[#D4D4CE] hover:bg-[#F3F3F0]'
                    }`}
                  >
                    {v.label}
                  </button>
                ))}
              </div>
            )}
            <input
              type="text"
              value={detailsDraft.variantLabel}
              onChange={(e) => setDetailsDraft({ ...detailsDraft, variantLabel: e.target.value })}
              placeholder="es. 512 GB, 1 TB, 2 TB o Standard"
              className="w-full px-2.5 py-1.5 bg-white border border-[#D4D4CE] rounded focus:outline-none focus:border-[#141413]"
            />
          </div>

          {/* Quick color selector */}
          <div className="sm:col-span-2">
            <span className="block font-medium text-[#5E5E59] mb-1">Colore / Finitura</span>
            {item.product.colorOptions && item.product.colorOptions.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-1.5">
                {item.product.colorOptions.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() =>
                      setDetailsDraft({
                        ...detailsDraft,
                        colorName: c.name,
                        colorHex: c.hex,
                      })
                    }
                    className={`px-2 py-1 rounded border text-[11px] font-medium flex items-center gap-1.5 cursor-pointer ${
                      detailsDraft.colorName === c.name
                        ? 'bg-[#141413] text-white border-[#141413]'
                        : 'bg-white text-[#141413] border-[#D4D4CE] hover:bg-[#F3F3F0]'
                    }`}
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full border border-black/15"
                      style={{ backgroundColor: c.hex }}
                      aria-hidden="true"
                    />
                    {c.name}
                  </button>
                ))}
              </div>
            )}
            <div className="flex items-center gap-2">
              <input
                type="color"
                aria-label="Scegli tinta colore"
                value={/^#[0-9A-Fa-f]{6}$/.test(detailsDraft.colorHex) ? detailsDraft.colorHex : '#2B2C30'}
                onChange={(e) => setDetailsDraft({ ...detailsDraft, colorHex: e.target.value })}
                className="w-8 h-7 p-0.5 bg-white border border-[#D4D4CE] rounded cursor-pointer shrink-0"
              />
              <input
                type="text"
                value={detailsDraft.colorName}
                onChange={(e) => {
                  const val = e.target.value;
                  const inferredHex = inferColorHexClient(val);
                  setDetailsDraft({
                    ...detailsDraft,
                    colorName: val,
                    colorHex: inferredHex !== '#2B2C30' ? inferredHex : detailsDraft.colorHex,
                  });
                }}
                placeholder="Nome colore o finitura"
                className="flex-1 min-w-0 px-2.5 py-1.5 bg-white border border-[#D4D4CE] rounded focus:outline-none focus:border-[#141413]"
              />
            </div>
          </div>

          <label className="block">
            <span className="block font-medium text-[#5E5E59] mb-1">Codice / SKU</span>
            <input
              type="text"
              value={detailsDraft.sku}
              onChange={(e) => setDetailsDraft({ ...detailsDraft, sku: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-white border border-[#D4D4CE] rounded font-mono focus:outline-none focus:border-[#141413]"
            />
          </label>

          <label className="block">
            <span className="block font-medium text-[#5E5E59] mb-1">Link foto (opzionale)</span>
            <input
              type="url"
              value={detailsDraft.imageUrl || ''}
              onChange={(e) => setDetailsDraft({ ...detailsDraft, imageUrl: e.target.value })}
              placeholder="https://..."
              className="w-full px-2.5 py-1.5 bg-white border border-[#D4D4CE] rounded focus:outline-none focus:border-[#141413]"
            />
          </label>

          <label className="block sm:col-span-2">
            <span className="block font-medium text-[#5E5E59] mb-1">Descrizione / Note personali</span>
            <textarea
              rows={2}
              value={detailsDraft.shortSummary}
              onChange={(e) => setDetailsDraft({ ...detailsDraft, shortSummary: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-white border border-[#D4D4CE] rounded focus:outline-none focus:border-[#141413]"
            />
          </label>
        </div>

        <div className="flex items-center justify-end gap-2 pt-1">
          <button
            type="button"
            onClick={() => {
              setEditingDetailsId(null);
              setDetailsDraft(null);
            }}
            className="px-3 py-1.5 font-medium text-[#5E5E59] hover:text-[#141413] bg-white border border-[#D4D4CE] rounded cursor-pointer"
          >
            Annulla
          </button>
          <button
            type="submit"
            className="px-3.5 py-1.5 font-semibold bg-[#141413] text-white rounded hover:bg-[#2B2C30] cursor-pointer"
          >
            Salva modifiche
          </button>
        </div>
      </form>
    );
  }

  return (
    <section
      id="riepilogo-pagina"
      aria-label="La mia pagina personale"
      className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-8"
    >
      {/* Header & Summary Strip */}
      <div className="bg-white border border-[#E4E4E0] rounded-lg p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-[#5E5E59]">
              <span>Spazio personale</span>
              <span aria-hidden="true">·</span>
              <span className="tabular-nums">
                {totalUnits} {totalUnits === 1 ? 'articolo aggiunto' : 'articoli aggiunti'}
              </span>
            </div>
            <h2 className="text-2xl font-bold text-[#141413] mt-0.5">La mia pagina</h2>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="pr-4 border-r border-[#E4E4E0]">
              <p className="text-xs text-[#5E5E59]">
                {hasActiveFilters ? 'Subtotale selezione' : 'Valore totale pagina'}
              </p>
              <p className="text-2xl font-bold text-[#141413] tabular-nums">
                {formatEuro(hasActiveFilters ? filteredValue : totalValue)}
              </p>
              {hasActiveFilters && (
                <p className="text-[11px] text-[#5E5E59] tabular-nums">
                  Totale intera pagina: {formatEuro(totalValue)}
                </p>
              )}
            </div>

            {items.length > 0 && (
              <div className="flex flex-wrap items-center gap-2">
                {/* View Toggle */}
                <div className="flex items-center p-1 bg-[#F3F3F0] rounded-md border border-[#E4E4E0]">
                  <button
                    type="button"
                    onClick={() => setViewMode('grid')}
                    aria-label="Vista a griglia"
                    className={`px-2.5 py-1 text-xs font-medium rounded flex items-center gap-1.5 transition-colors cursor-pointer ${
                      viewMode === 'grid'
                        ? 'bg-white text-[#141413] shadow-xs'
                        : 'text-[#5E5E59] hover:text-[#141413]'
                    }`}
                  >
                    <LayoutGrid className="w-3.5 h-3.5" aria-hidden="true" />
                    Griglia
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode('list')}
                    aria-label="Vista elenco dettagliato"
                    className={`px-2.5 py-1 text-xs font-medium rounded flex items-center gap-1.5 transition-colors cursor-pointer ${
                      viewMode === 'list'
                        ? 'bg-white text-[#141413] shadow-xs'
                        : 'text-[#5E5E59] hover:text-[#141413]'
                    }`}
                  >
                    <List className="w-3.5 h-3.5" aria-hidden="true" />
                    Elenco
                  </button>
                </div>

                {/* Copy Summary */}
                <button
                  type="button"
                  onClick={handleCopySummary}
                  className="px-3 py-2 text-xs font-medium text-[#141413] bg-white border border-[#D4D4CE] hover:bg-[#F7F6F1] rounded-md flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
                >
                  {copiedSummary ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#141413]" aria-hidden="true" />
                      Riepilogo copiato
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                      Copia lista
                    </>
                  )}
                </button>

                {/* Clear Page with Inline Confirmation */}
                {!confirmClear ? (
                  <button
                    type="button"
                    onClick={() => setConfirmClear(true)}
                    className="px-3 py-2 text-xs font-medium text-[#5E5E59] hover:text-[#B91C1C] bg-white border border-[#E4E4E0] rounded-md flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                    Svuota
                  </button>
                ) : (
                  <div className="flex items-center gap-1.5 bg-[#FEF2F2] border border-[#FECACA] px-2.5 py-1 rounded-md">
                    <span className="text-xs text-[#991B1B] font-medium">Svuotare tutta la pagina?</span>
                    <button
                      type="button"
                      onClick={() => {
                        onClearPage();
                        setConfirmClear(false);
                        resetAllFilters();
                      }}
                      className="px-2 py-1 text-xs font-semibold text-white bg-[#B91C1C] hover:bg-[#991B1B] rounded cursor-pointer"
                    >
                      Sì, svuota
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmClear(false)}
                      className="px-2 py-1 text-xs font-medium text-[#141413] bg-white border border-[#E4E4E0] rounded cursor-pointer"
                    >
                      Annulla
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Rooms & Multi-Filter Bar when items exist */}
        {items.length > 0 && (
          <div className="mt-4 pt-4 border-t border-[#F0F0EC] space-y-3">
            {/* Room Tabs + Add Room */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-medium text-[#5E5E59] inline-flex items-center gap-1 mr-1">
                <Home className="w-3.5 h-3.5" aria-hidden="true" />
                Stanze:
              </span>
              <button
                type="button"
                onClick={() => setRoomFilter('Tutte')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  roomFilter === 'Tutte'
                    ? 'bg-[#141413] text-white'
                    : 'bg-[#F3F3F0] text-[#5E5E59] hover:text-[#141413]'
                }`}
              >
                Tutte ({totalUnits})
              </button>
              {rooms.map((r) => {
                const count = roomCounts.get(r) ?? 0;
                const isSelected = roomFilter === r;
                if (count === 0 && !isSelected && r === 'Non assegnata') return null;
                return (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRoomFilter(r)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer tabular-nums ${
                      isSelected
                        ? 'bg-[#141413] text-white'
                        : count > 0
                        ? 'bg-[#F3F3F0] text-[#141413] hover:bg-[#EAEAE5]'
                        : 'bg-[#FAFAF8] text-[#787872] border border-[#E4E4E0] hover:text-[#141413]'
                    }`}
                  >
                    {r}
                    {count > 0 ? ` (${count})` : ''}
                  </button>
                );
              })}

              {!isAddingRoom ? (
                <button
                  type="button"
                  onClick={() => setIsAddingRoom(true)}
                  className="px-2.5 py-1.5 text-xs font-medium text-[#141413] bg-white border border-dashed border-[#B8B8B2] hover:border-[#141413] rounded-md flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3 h-3" aria-hidden="true" />
                  Nuova stanza
                </button>
              ) : (
                <form onSubmit={handleCreateRoom} className="inline-flex items-center gap-1">
                  <input
                    type="text"
                    autoFocus
                    value={newRoomDraft}
                    onChange={(e) => setNewRoomDraft(e.target.value)}
                    placeholder="es. Mansarda"
                    className="w-28 px-2.5 py-1 text-xs bg-white border border-[#141413] rounded focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="px-2.5 py-1 text-xs font-semibold bg-[#141413] text-white rounded cursor-pointer"
                  >
                    Aggiungi
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddingRoom(false);
                      setNewRoomDraft('');
                    }}
                    aria-label="Annulla nuova stanza"
                    className="p-1 text-[#5E5E59] hover:text-[#141413] cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
            </div>

            {/* Secondary Filters: Search within page, Category, Brand, Sort */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2.5 items-center">
              <div className="lg:col-span-5 relative flex items-center bg-[#FAFAF8] border border-[#D4D4CE] rounded-md focus-within:bg-white focus-within:border-[#141413]">
                <Search className="w-3.5 h-3.5 text-[#5E5E59] ml-3 shrink-0" aria-hidden="true" />
                <input
                  type="text"
                  value={textFilter}
                  onChange={(e) => setTextFilter(e.target.value)}
                  placeholder="Filtra tra i tuoi articoli (nome, marca, stanza, SKU)..."
                  className="w-full px-2.5 py-1.5 text-xs text-[#141413] bg-transparent focus:outline-none"
                />
                {textFilter && (
                  <button
                    type="button"
                    onClick={() => setTextFilter('')}
                    aria-label="Cancella filtro testo"
                    className="p-1.5 text-[#5E5E59] hover:text-[#141413] cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="lg:col-span-2">
                <select
                  aria-label="Filtra per categoria"
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value as ProductCategory | 'Tutti')}
                  className="w-full px-2.5 py-1.5 text-xs font-medium text-[#141413] bg-[#FAFAF8] border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413] cursor-pointer"
                >
                  <option value="Tutti">Tutte le categorie ({items.length})</option>
                  {presentCategories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat} ({items.filter((i) => i.product.category === cat).length})
                    </option>
                  ))}
                </select>
              </div>

              <div className="lg:col-span-2">
                <select
                  aria-label="Filtra per marca"
                  value={brandFilter}
                  onChange={(e) => setBrandFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs font-medium text-[#141413] bg-[#FAFAF8] border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413] cursor-pointer"
                >
                  <option value="Tutte">Tutte le marche</option>
                  {presentBrands.map((brand) => (
                    <option key={brand} value={brand}>
                      {brand} ({items.filter((i) => i.product.brand === brand).length})
                    </option>
                  ))}
                </select>
              </div>

              <div className="lg:col-span-3 flex items-center gap-2">
                <select
                  aria-label="Ordina articoli nella pagina"
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value as PageSortOption)}
                  className="flex-1 px-2.5 py-1.5 text-xs font-medium text-[#141413] bg-[#FAFAF8] border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413] cursor-pointer"
                >
                  <option value="saved">Ordine salvato</option>
                  <option value="price-asc">Prezzo: crescente</option>
                  <option value="price-desc">Prezzo: decrescente</option>
                  <option value="name-asc">Nome: A → Z</option>
                </select>

                {hasActiveFilters && (
                  <button
                    type="button"
                    onClick={resetAllFilters}
                    className="px-2.5 py-1.5 text-xs font-medium text-[#141413] hover:underline underline-offset-4 whitespace-nowrap cursor-pointer"
                  >
                    Azzera filtri
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Empty State OR Saved Items */}
      {items.length === 0 ? (
        <div className="mt-6 bg-white border border-dashed border-[#D4D4CE] rounded-lg px-6 py-14 text-center">
          <h3 className="text-lg font-bold text-[#141413]">
            La tua pagina è pronta per i tuoi articoli
          </h3>
          <p className="text-sm text-[#5E5E59] max-w-xl mx-auto mt-2 leading-relaxed">
            Incolla il link di un negozio (Amazon, IKEA, ecc.) nella barra in alto oppure inserisci
            un modello manuale: il sistema riconosce automaticamente marca, categoria, colore,
            prezzo e immagine, e puoi organizzare tutto per stanza.
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-2.5">
            <button
              type="button"
              onClick={onOpenLinkPanel}
              className="px-4 py-2 text-xs font-semibold text-[#141413] bg-[#F59E0B] hover:bg-[#D97706] hover:text-white rounded-md transition-colors cursor-pointer"
            >
              Incolla link articolo
            </button>
            <button
              type="button"
              onClick={onOpenManualPanel}
              className="px-4 py-2 text-xs font-semibold text-[#141413] bg-[#F3F3F0] hover:bg-[#EAEAE5] border border-[#E4E4E0] rounded-md transition-colors cursor-pointer"
            >
              Inserisci modello manuale
            </button>
          </div>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="mt-6 bg-white border border-[#E4E4E0] rounded-lg px-6 py-12 text-center">
          <p className="text-base font-bold text-[#141413]">
            Nessun articolo corrisponde ai filtri selezionati
          </p>
          <p className="text-xs text-[#5E5E59] mt-1">
            Prova a cambiare stanza, categoria o testo di ricerca.
          </p>
          <button
            type="button"
            onClick={resetAllFilters}
            className="mt-4 px-4 py-2 text-xs font-semibold bg-[#F59E0B] hover:bg-[#D97706] text-[#141413] hover:text-white rounded-md transition-colors cursor-pointer"
          >
            Mostra tutti gli articoli ({items.length})
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, idx) => {
            const unitPrice = item.product.price + item.variant.priceDelta;
            const subtotal = unitPrice * item.quantity;
            const isExpanded = expandedSpecIds.has(item.entryId);
            const itemRoom = item.room || 'Non assegnata';
            const isConfirmingRemove = confirmRemoveId === item.entryId;

            return (
              <article
                key={item.entryId}
                className="bg-white border border-[#E4E4E0] rounded-lg overflow-hidden flex flex-col justify-between transition-transform duration-150 hover:-translate-y-0.5"
              >
                <div>
                  <div className="relative group">
                    <ProductVisual
                      imageUrl={item.product.imageUrl}
                      visualKind={item.product.visualKind}
                      name={item.product.name}
                      accentHex={item.variant.colorHex}
                      className="w-full aspect-[4/3] border-b border-[#EAEAE5]"
                    />
                    <button
                      type="button"
                      onClick={() => startEditingImage(item.entryId, item.product.imageUrl)}
                      className="absolute bottom-2.5 right-2.5 px-2.5 py-1 text-[11px] font-medium bg-white/95 hover:bg-white text-[#141413] border border-[#D4D4CE] rounded shadow-xs flex items-center gap-1 cursor-pointer"
                    >
                      <ImagePlus className="w-3.5 h-3.5" aria-hidden="true" />
                      {item.product.imageUrl ? 'Cambia foto' : 'Incolla link foto'}
                    </button>
                  </div>

                  {editingImageId === item.entryId && (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        commitImageEdit(item.entryId);
                      }}
                      className="px-4 py-2.5 bg-[#FAFAF8] border-b border-[#EAEAE5] flex items-center gap-1.5"
                    >
                      <input
                        type="url"
                        autoFocus
                        value={imageDraft}
                        onChange={(e) => setImageDraft(e.target.value)}
                        placeholder="Incolla indirizzo immagine https://..."
                        aria-label="Indirizzo URL immagine"
                        className="flex-1 min-w-0 px-2.5 py-1 text-xs bg-white border border-[#D4D4CE] rounded focus:outline-none focus:border-[#141413]"
                      />
                      <button
                        type="submit"
                        className="px-2.5 py-1 text-xs font-semibold bg-[#141413] text-white rounded cursor-pointer"
                      >
                        Salva
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingImageId(null)}
                        aria-label="Chiudi modifica foto"
                        className="p-1 text-[#5E5E59] hover:text-[#141413] cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </form>
                  )}

                  <div className="p-5">
                    <div className="flex items-center justify-between gap-2 text-xs text-[#5E5E59]">
                      <div className="flex items-center gap-1.5 min-w-0 truncate">
                        <span className="font-medium text-[#141413]">{item.product.brand}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.product.category}</span>
                      </div>
                      <span className="inline-flex items-center gap-0.5 text-[#141413] tabular-nums shrink-0">
                        <Star className="w-3 h-3 fill-[#F59E0B] text-[#F59E0B]" aria-hidden="true" />
                        {item.product.rating.toFixed(1).replace('.', ',')}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-[#141413] mt-1 leading-snug">
                      {item.product.name}
                    </h3>

                    <p className="text-xs text-[#5E5E59] mt-1 flex items-center gap-1.5">
                      <span
                        className="w-2.5 h-2.5 rounded-full border border-black/15 inline-block shrink-0"
                        style={{ backgroundColor: item.variant.colorHex }}
                        aria-hidden="true"
                      />
                      <span>
                        {item.variant.label} · {item.variant.colorName}
                      </span>
                    </p>

                    {/* Quick Room Selector */}
                    <div className="mt-2.5 flex items-center gap-2 text-xs">
                      <span className="text-[#5E5E59] inline-flex items-center gap-1 shrink-0">
                        <Home className="w-3.5 h-3.5" aria-hidden="true" />
                        Stanza:
                      </span>
                      <select
                        aria-label={`Stanza per ${item.product.name}`}
                        value={itemRoom}
                        onChange={(e) => onUpdateRoom(item.entryId, e.target.value)}
                        className="flex-1 min-w-0 px-2 py-1 text-xs font-medium text-[#141413] bg-[#FAFAF8] border border-[#E4E4E0] rounded focus:outline-none focus:border-[#141413] cursor-pointer"
                      >
                        {!rooms.includes(itemRoom) && <option value={itemRoom}>{itemRoom}</option>}
                        {rooms.map((r) => (
                          <option key={r} value={r}>
                            {r}
                          </option>
                        ))}
                      </select>
                    </div>

                    <p className="text-xs text-[#4A4A46] mt-2.5 leading-relaxed line-clamp-2">
                      {item.product.shortSummary}
                    </p>

                    <div className="mt-3 flex flex-wrap items-center gap-3">
                      <button
                        type="button"
                        onClick={() => toggleSpecs(item.entryId)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-[#141413] hover:underline underline-offset-4 cursor-pointer"
                      >
                        {isExpanded ? (
                          <>
                            <ChevronUp className="w-3.5 h-3.5" aria-hidden="true" />
                            Chiudi dettagli
                          </>
                        ) : (
                          <>
                            <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
                            Dettagli completi
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => startEditingDetails(item)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-[#B45309] hover:underline underline-offset-4 cursor-pointer"
                      >
                        <Pencil className="w-3 h-3" aria-hidden="true" />
                        {editingDetailsId === item.entryId ? 'Chiudi modifica' : 'Modifica dettagli'}
                      </button>
                    </div>

                    {renderDetailsEditor(item)}

                    {isExpanded && (
                      <dl className="mt-3 pt-3 border-t border-[#EAEAE5] space-y-1.5 text-xs">
                        <div className="flex justify-between gap-2">
                          <dt className="text-[#5E5E59] shrink-0">Stanza</dt>
                          <dd className="text-[#141413] font-medium text-right">{itemRoom}</dd>
                        </div>
                        <div className="flex justify-between gap-2">
                          <dt className="text-[#5E5E59] shrink-0">Codice / SKU</dt>
                          <dd className="text-[#141413] font-mono text-right">{item.product.sku}</dd>
                        </div>
                        {item.product.specs.map((spec) => (
                          <div key={spec.label} className="flex justify-between gap-2">
                            <dt className="text-[#5E5E59] shrink-0">{spec.label}</dt>
                            <dd className="text-[#141413] font-medium text-right break-all">
                              {/^https?:\/\//i.test(spec.value) ? (
                                <a
                                  href={spec.value}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="underline underline-offset-2 hover:text-[#B45309]"
                                >
                                  Apri link originale
                                </a>
                              ) : (
                                spec.value
                              )}
                            </dd>
                          </div>
                        ))}
                      </dl>
                    )}
                  </div>
                </div>

                <div className="px-5 py-4 bg-[#FAFAF8] border-t border-[#EAEAE5] space-y-3">
                  <div className="flex items-baseline justify-between gap-2">
                    <div className="min-w-0">
                      {editingPriceId === item.entryId ? (
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            commitPriceEdit(item.entryId);
                          }}
                          className="flex items-center gap-1"
                        >
                          <input
                            type="text"
                            inputMode="decimal"
                            autoFocus
                            value={priceDraft}
                            onChange={(e) => setPriceDraft(e.target.value)}
                            placeholder="0,00"
                            aria-label="Nuovo prezzo unitario in euro"
                            className="w-20 px-2 py-1 text-xs font-semibold bg-white border border-[#141413] rounded tabular-nums focus:outline-none"
                          />
                          <button
                            type="submit"
                            aria-label="Salva prezzo"
                            className="p-1 bg-[#141413] text-white rounded cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingPriceId(null)}
                            aria-label="Annulla modifica prezzo"
                            className="p-1 text-[#5E5E59] hover:text-[#141413] cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </form>
                      ) : unitPrice > 0 ? (
                        <div className="flex items-center gap-1.5">
                          <span className="text-lg font-bold text-[#141413] tabular-nums">
                            {formatEuro(subtotal)}
                          </span>
                          <button
                            type="button"
                            onClick={() => startEditingPrice(item.entryId, unitPrice)}
                            aria-label="Modifica prezzo unitario"
                            title="Modifica prezzo"
                            className="p-1 text-[#787872] hover:text-[#141413] cursor-pointer"
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => startEditingPrice(item.entryId, 0)}
                          className="text-xs font-semibold text-[#B45309] hover:underline underline-offset-2 flex items-center gap-1 cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" aria-hidden="true" />
                          Inserisci prezzo (€)
                        </button>
                      )}
                      {item.quantity > 1 && unitPrice > 0 && editingPriceId !== item.entryId && (
                        <span className="block text-[11px] text-[#5E5E59] tabular-nums">
                          {formatEuro(unitPrice)} cad.
                        </span>
                      )}
                    </div>

                    {/* Quantity Stepper */}
                    <div className="flex items-center border border-[#D4D4CE] bg-white rounded-md">
                      <button
                        type="button"
                        onClick={() => {
                          if (item.quantity <= 1) {
                            setConfirmRemoveId(item.entryId);
                          } else {
                            onUpdateQuantity(item.entryId, -1);
                          }
                        }}
                        aria-label="Diminuisci quantità"
                        className="p-1.5 text-[#5E5E59] hover:text-[#141413] cursor-pointer"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-2.5 text-xs font-semibold text-[#141413] tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.entryId, 1)}
                        aria-label="Aumenta quantità"
                        className="p-1.5 text-[#5E5E59] hover:text-[#141413] cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-[#EAEAE5] text-xs gap-2">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        disabled={idx === 0 || hasActiveFilters}
                        onClick={() => onMoveItem(item.entryId, 'up')}
                        aria-label="Sposta prima"
                        className="p-1 text-[#5E5E59] hover:text-[#141413] disabled:opacity-30 cursor-pointer disabled:cursor-default"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={idx === filteredItems.length - 1 || hasActiveFilters}
                        onClick={() => onMoveItem(item.entryId, 'down')}
                        aria-label="Sposta dopo"
                        className="p-1 text-[#5E5E59] hover:text-[#141413] disabled:opacity-30 cursor-pointer disabled:cursor-default"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {!isConfirmingRemove ? (
                      <button
                        type="button"
                        onClick={() => setConfirmRemoveId(item.entryId)}
                        className="text-xs font-medium text-[#5E5E59] hover:text-[#B91C1C] transition-colors cursor-pointer"
                      >
                        Rimuovi dalla pagina
                      </button>
                    ) : (
                      <div className="flex items-center gap-1.5 bg-[#FEF2F2] border border-[#FECACA] px-2 py-1 rounded">
                        <span className="text-[11px] text-[#991B1B] font-medium">Confermi?</span>
                        <button
                          type="button"
                          onClick={() => {
                            onRemoveItem(item.entryId);
                            setConfirmRemoveId(null);
                          }}
                          className="px-2 py-0.5 text-[11px] font-semibold text-white bg-[#B91C1C] hover:bg-[#991B1B] rounded cursor-pointer"
                        >
                          Sì, rimuovi
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmRemoveId(null)}
                          className="px-2 py-0.5 text-[11px] font-medium text-[#141413] bg-white border border-[#E4E4E0] rounded cursor-pointer"
                        >
                          Annulla
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {filteredItems.map((item) => {
            const unitPrice = item.product.price + item.variant.priceDelta;
            const subtotal = unitPrice * item.quantity;
            const itemRoom = item.room || 'Non assegnata';
            const isConfirmingRemove = confirmRemoveId === item.entryId;

            return (
              <article
                key={item.entryId}
                className="bg-white border border-[#E4E4E0] rounded-lg p-4 sm:p-5 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-4 min-w-0 flex-1">
                    <ProductVisual
                      imageUrl={item.product.imageUrl}
                      visualKind={item.product.visualKind}
                      name={item.product.name}
                      accentHex={item.variant.colorHex}
                      className="w-20 h-20 rounded-md border border-[#EAEAE5] shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs text-[#5E5E59] flex flex-wrap items-center gap-1.5">
                        <span className="font-medium text-[#141413]">{item.product.brand}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.product.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {item.variant.label} ({item.variant.colorName})
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-medium text-[#141413]">{itemRoom}</span>
                      </div>
                      <h3 className="text-base font-bold text-[#141413] mt-0.5">{item.product.name}</h3>
                      <p className="text-xs text-[#4A4A46] mt-1 line-clamp-2">
                        {item.product.shortSummary}
                      </p>

                      <div className="mt-2 flex flex-wrap items-center gap-3 text-xs">
                        <select
                          aria-label={`Stanza per ${item.product.name}`}
                          value={itemRoom}
                          onChange={(e) => onUpdateRoom(item.entryId, e.target.value)}
                          className="px-2 py-1 text-xs font-medium text-[#141413] bg-[#FAFAF8] border border-[#E4E4E0] rounded cursor-pointer"
                        >
                          {!rooms.includes(itemRoom) && <option value={itemRoom}>{itemRoom}</option>}
                          {rooms.map((r) => (
                            <option key={r} value={r}>
                              Stanza: {r}
                            </option>
                          ))}
                        </select>

                        <button
                          type="button"
                          onClick={() => startEditingDetails(item)}
                          className="inline-flex items-center gap-1 font-semibold text-[#B45309] hover:underline underline-offset-4 cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" aria-hidden="true" />
                          {editingDetailsId === item.entryId ? 'Chiudi modifica' : 'Modifica dettagli'}
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end justify-between gap-3 shrink-0">
                    {unitPrice > 0 ? (
                      <span className="text-lg font-bold text-[#141413] tabular-nums">
                        {formatEuro(subtotal)}
                      </span>
                    ) : (
                      <span className="text-xs font-semibold text-[#B45309]">
                        Prezzo da inserire
                      </span>
                    )}

                    <div className="flex items-center gap-3">
                      <div className="flex items-center border border-[#D4D4CE] bg-white rounded-md">
                        <button
                          type="button"
                          onClick={() => {
                            if (item.quantity <= 1) {
                              setConfirmRemoveId(item.entryId);
                            } else {
                              onUpdateQuantity(item.entryId, -1);
                            }
                          }}
                          aria-label="Diminuisci quantità"
                          className="p-1.5 text-[#5E5E59] hover:text-[#141413] cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-2.5 text-xs font-semibold text-[#141413] tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.entryId, 1)}
                          aria-label="Aumenta quantità"
                          className="p-1.5 text-[#5E5E59] hover:text-[#141413] cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {!isConfirmingRemove ? (
                        <button
                          type="button"
                          onClick={() => setConfirmRemoveId(item.entryId)}
                          className="text-xs font-medium text-[#5E5E59] hover:text-[#B91C1C] cursor-pointer"
                        >
                          Rimuovi
                        </button>
                      ) : (
                        <div className="flex items-center gap-1.5 bg-[#FEF2F2] border border-[#FECACA] px-2 py-1 rounded">
                          <span className="text-[11px] text-[#991B1B] font-medium">Rimuovere?</span>
                          <button
                            type="button"
                            onClick={() => {
                              onRemoveItem(item.entryId);
                              setConfirmRemoveId(null);
                            }}
                            className="px-2 py-0.5 text-[11px] font-semibold text-white bg-[#B91C1C] hover:bg-[#991B1B] rounded cursor-pointer"
                          >
                            Sì
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmRemoveId(null)}
                            className="px-2 py-0.5 text-[11px] font-medium text-[#141413] bg-white border border-[#E4E4E0] rounded cursor-pointer"
                          >
                            No
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {renderDetailsEditor(item)}
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
