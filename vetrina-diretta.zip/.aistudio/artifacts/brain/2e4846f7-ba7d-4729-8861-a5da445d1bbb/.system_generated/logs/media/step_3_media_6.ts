import { useState } from 'react';
import {
  Check,
  ChevronDown,
  ChevronUp,
  Plus,
  ShieldCheck,
  Star,
  Truck,
  X,
} from 'lucide-react';
import { Product, ProductColorOption, ProductVariant, SavedPageItem } from '../types/product';
import { formatEuro } from '../utils/search';
import { ProductVisual } from './ProductVisual';

interface SearchResultCardProps {
  product: Product;
  pageItems: SavedPageItem[];
  rooms: string[];
  defaultRoom: string;
  defaultExpandedSpecs?: boolean;
  onAddToPage: (product: Product, variant: ProductVariant, room: string) => void;
}

function SearchResultCard({
  product,
  pageItems,
  rooms,
  defaultRoom,
  defaultExpandedSpecs = false,
  onAddToPage,
}: SearchResultCardProps) {
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant>(product.variants[0]);
  const [selectedColor, setSelectedColor] = useState<ProductColorOption | null>(
    product.colorOptions?.[0] ?? null
  );
  const [selectedRoom, setSelectedRoom] = useState<string>(defaultRoom);
  const [specsOpen, setSpecsOpen] = useState(defaultExpandedSpecs);
  const [justAdded, setJustAdded] = useState(false);

  const effectiveVariant: ProductVariant = selectedColor
    ? {
        ...selectedVariant,
        id: `${selectedVariant.id}-${selectedColor.id}`,
        colorName: selectedColor.name,
        colorHex: selectedColor.hex,
      }
    : selectedVariant;

  const finalPrice = product.price + effectiveVariant.priceDelta;
  const originalFinalPrice = product.originalPrice
    ? product.originalPrice + effectiveVariant.priceDelta
    : undefined;
  const savings = originalFinalPrice ? originalFinalPrice - finalPrice : 0;

  const quantityOnPage = pageItems
    .filter((item) => item.product.id === product.id && item.variant.id === effectiveVariant.id)
    .reduce((sum, item) => sum + item.quantity, 0);

  function handleAdd() {
    onAddToPage(product, effectiveVariant, selectedRoom);
    setJustAdded(true);
    window.setTimeout(() => setJustAdded(false), 1500);
  }

  return (
    <article className="bg-white border border-[#E4E4E0] rounded-lg p-5 sm:p-6 transition-colors">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        {/* Product Image Column */}
        <div className="md:col-span-3">
          <ProductVisual
            imageUrl={product.imageUrl}
            visualKind={product.visualKind}
            name={product.name}
            accentHex={effectiveVariant.colorHex}
            className="w-full aspect-square rounded-md border border-[#EAEAE5]"
          />
        </div>

        {/* Amazon-Style Comprehensive Details Column */}
        <div className="md:col-span-6 min-w-0">
          <div className="flex flex-wrap items-center gap-2 text-xs text-[#5E5E59]">
            <span className="font-medium text-[#141413]">{product.brand}</span>
            <span aria-hidden="true">·</span>
            <span>{product.category}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-[11px]">{product.sku}</span>
          </div>

          <h3 className="text-lg sm:text-xl font-bold text-[#141413] mt-1 leading-snug">
            {product.name}
          </h3>

          <div className="flex items-center gap-2 mt-1.5 text-xs text-[#5E5E59]">
            <div className="inline-flex items-center gap-0.5" aria-label={`Valutazione ${product.rating} su 5`}>
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`w-3.5 h-3.5 ${
                    i < Math.round(product.rating)
                      ? 'fill-[#F59E0B] text-[#F59E0B]'
                      : 'text-[#D4D4CE]'
                  }`}
                  aria-hidden="true"
                />
              ))}
            </div>
            <span className="font-semibold text-[#141413] tabular-nums">
              {product.rating.toFixed(1).replace('.', ',')}
            </span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">
              {product.reviewCount.toLocaleString('it-IT')} recensioni verificate
            </span>
          </div>

          <p className="text-sm text-[#4A4A46] leading-relaxed mt-3">{product.shortSummary}</p>

          {/* Color & Storage / Variant Selectors */}
          <div className="mt-4 space-y-3">
            {product.colorOptions && product.colorOptions.length > 0 && (
              <div>
                <p className="text-xs font-medium text-[#5E5E59] mb-2">
                  Colore:{' '}
                  <span className="text-[#141413] font-semibold">
                    {selectedColor?.name ?? effectiveVariant.colorName}
                  </span>
                </p>
                <div className="flex flex-wrap gap-2">
                  {product.colorOptions.map((color) => {
                    const isColorSelected = selectedColor?.id === color.id;
                    return (
                      <button
                        key={color.id}
                        type="button"
                        onClick={() => setSelectedColor(color)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-md border flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          isColorSelected
                            ? 'border-[#141413] bg-[#F7F6F1] text-[#141413] font-semibold'
                            : 'border-[#E4E4E0] bg-white text-[#5E5E59] hover:border-[#B8B8B2] hover:text-[#141413]'
                        }`}
                      >
                        <span
                          className="w-3 h-3 rounded-full border border-black/15 shrink-0"
                          style={{ backgroundColor: color.hex }}
                          aria-hidden="true"
                        />
                        <span>{color.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div>
              <p className="text-xs font-medium text-[#5E5E59] mb-2">
                {product.colorOptions && product.colorOptions.length > 0
                  ? 'Spazio di memoria / Configurazione:'
                  : 'Configurazione selezionata:'}{' '}
                <span className="text-[#141413] font-semibold">
                  {effectiveVariant.label}
                  {!product.colorOptions?.length ? ` · ${effectiveVariant.colorName}` : ''}
                </span>
              </p>
              <div className="flex flex-wrap gap-2">
                {product.variants.map((variant) => {
                  const isSelected = variant.id === selectedVariant.id;
                  return (
                    <button
                      key={variant.id}
                      type="button"
                      onClick={() => setSelectedVariant(variant)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md border flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        isSelected
                          ? 'border-[#141413] bg-[#F7F6F1] text-[#141413] font-semibold'
                          : 'border-[#E4E4E0] bg-white text-[#5E5E59] hover:border-[#B8B8B2] hover:text-[#141413]'
                      }`}
                    >
                      {!product.colorOptions?.length && (
                        <span
                          className="w-2.5 h-2.5 rounded-full border border-black/15 shrink-0"
                          style={{ backgroundColor: variant.colorHex }}
                          aria-hidden="true"
                        />
                      )}
                      <span>{variant.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Key Feature Bullet Points */}
          <div className="mt-4 pt-4 border-t border-[#F0F0EC]">
            <p className="text-xs font-semibold text-[#141413] mb-2">Informazioni su questo articolo</p>
            <ul className="space-y-1.5 text-xs sm:text-[13px] text-[#3F3F3B] list-disc pl-4 leading-relaxed">
              {product.highlights.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </div>

          {/* Toggle Full Technical Sheet */}
          <div className="mt-4">
            <button
              type="button"
              onClick={() => setSpecsOpen((prev) => !prev)}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#141413] hover:underline underline-offset-4 cursor-pointer"
            >
              {specsOpen ? (
                <>
                  <ChevronUp className="w-4 h-4" aria-hidden="true" />
                  Nascondi scheda tecnica completa
                </>
              ) : (
                <>
                  <ChevronDown className="w-4 h-4" aria-hidden="true" />
                  Mostra scheda tecnica completa e contenuto confezione
                </>
              )}
            </button>

            {specsOpen && (
              <div className="mt-3 p-4 bg-[#FAFAF8] border border-[#E4E4E0] rounded-md space-y-4">
                <div>
                  <h4 className="text-xs font-semibold text-[#141413] mb-2">Specifiche tecniche</h4>
                  <dl className="divide-y divide-[#EAEAE5] text-xs">
                    {product.specs.map((spec) => (
                      <div
                        key={spec.label}
                        className="py-1.5 grid grid-cols-1 sm:grid-cols-12 gap-1 sm:gap-3"
                      >
                        <dt className="sm:col-span-4 text-[#5E5E59]">{spec.label}</dt>
                        <dd className="sm:col-span-8 text-[#141413] font-medium break-all">
                          {/^https?:\/\//i.test(spec.value) ? (
                            <a
                              href={spec.value}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="underline underline-offset-2 hover:text-[#B45309]"
                            >
                              {spec.value}
                            </a>
                          ) : (
                            spec.value
                          )}
                        </dd>
                      </div>
                    ))}
                  </dl>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[#E4E4E0] text-xs">
                  <div>
                    <h4 className="font-semibold text-[#141413] mb-1.5">Contenuto della confezione</h4>
                    <ul className="space-y-1 text-[#4A4A46] list-disc pl-4">
                      {product.boxContents.map((boxItem, i) => (
                        <li key={i}>{boxItem}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#141413] mb-1.5">Garanzia e codice</h4>
                    <p className="text-[#4A4A46]">{product.warranty}</p>
                    <p className="text-[#5E5E59] font-mono mt-1">SKU: {product.sku}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Purchase / Add-to-Page Column */}
        <div className="md:col-span-3 bg-[#FAFAF8] border border-[#E4E4E0] rounded-md p-4 flex flex-col justify-between">
          <div>
            {finalPrice > 0 ? (
              <>
                <div className="text-2xl font-bold text-[#141413] tabular-nums">
                  {formatEuro(finalPrice)}
                </div>

                {originalFinalPrice && savings > 0 && (
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
                    <span className="text-[#787872] line-through tabular-nums">
                      {formatEuro(originalFinalPrice)}
                    </span>
                    <span className="font-semibold text-[#B45309] tabular-nums">
                      Risparmi {formatEuro(savings)}
                    </span>
                  </div>
                )}

                <p className="text-xs text-[#5E5E59] mt-1">IVA inclusa</p>
              </>
            ) : (
              <div>
                <div className="text-base font-bold text-[#141413]">
                  Prezzo da confermare
                </div>
                <p className="text-xs text-[#5E5E59] mt-0.5">
                  Potrai inserirlo o modificarlo nella tua pagina
                </p>
              </div>
            )}

            <div className="mt-4 space-y-2 text-xs text-[#3F3F3B]">
              <div className="flex items-start gap-2">
                <Truck className="w-4 h-4 text-[#141413] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-[#141413]">{product.availability}</p>
                  <p className="text-[#5E5E59]">{product.deliveryText}</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-[#5E5E59] shrink-0 mt-0.5" aria-hidden="true" />
                <p className="text-[#5E5E59]">{product.warranty}</p>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-[#E4E4E0] space-y-2.5">
            <label className="block text-xs">
              <span className="block font-medium text-[#5E5E59] mb-1">Stanza di destinazione</span>
              <select
                value={selectedRoom}
                onChange={(e) => setSelectedRoom(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs font-medium text-[#141413] bg-white border border-[#D4D4CE] rounded-md focus:outline-none focus:border-[#141413] cursor-pointer"
              >
                {rooms.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </label>

            <button
              type="button"
              onClick={handleAdd}
              className={`w-full py-2.5 px-4 text-xs sm:text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer ${
                justAdded
                  ? 'bg-[#141413] text-white'
                  : 'bg-[#F59E0B] hover:bg-[#D97706] text-[#141413] hover:text-white'
              }`}
            >
              {justAdded ? (
                <>
                  <Check className="w-4 h-4" aria-hidden="true" />
                  Aggiunto alla pagina
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" aria-hidden="true" />
                  Aggiungi alla pagina
                </>
              )}
            </button>

            {quantityOnPage > 0 && (
              <p className="text-center text-xs font-medium text-[#141413] tabular-nums">
                Già nella tua pagina ({quantityOnPage})
              </p>
            )}
          </div>
        </div>
      </div>
    </article>
  );
}

interface SearchResultsProps {
  results: Product[];
  pageItems: SavedPageItem[];
  rooms: string[];
  defaultRoom: string;
  onAddToPage: (product: Product, variant: ProductVariant, room: string) => void;
  onCloseResults: () => void;
}

export function SearchResults({
  results,
  pageItems,
  rooms,
  defaultRoom,
  onAddToPage,
  onCloseResults,
}: SearchResultsProps) {
  if (results.length === 0) return null;

  return (
    <section
      aria-label="Anteprima articolo da link"
      className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-8"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E4E4E0]">
        <div>
          <h2 className="text-xl font-bold text-[#141413]">
            Anteprima articolo importato dal link
          </h2>
          <p className="text-xs text-[#5E5E59] mt-0.5">
            Verifica i dati estratti, scegli configurazione e stanza, poi aggiungilo alla tua
            pagina
          </p>
        </div>

        <button
          type="button"
          onClick={onCloseResults}
          className="px-3 py-1.5 text-xs font-medium text-[#5E5E59] hover:text-[#141413] bg-white border border-[#E4E4E0] rounded-md flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer self-start sm:self-auto"
        >
          <X className="w-3.5 h-3.5" aria-hidden="true" />
          Chiudi anteprima
        </button>
      </div>

      <div className="mt-5 space-y-4">
        {results.map((product) => (
          <SearchResultCard
            key={product.id}
            product={product}
            pageItems={pageItems}
            rooms={rooms}
            defaultRoom={defaultRoom}
            defaultExpandedSpecs
            onAddToPage={onAddToPage}
          />
        ))}
      </div>
    </section>
  );
}

